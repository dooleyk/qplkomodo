/* qpl_scrpt.js
 * K. Dooley
 *
 * JavaScript routines for QPL-generated HTML and PHP files.
 */

// Global variables

// Set day in month constants
var dmonth = new Array(12);
dmonth[0]  = 31;    // Jan
dmonth[1]  = 29;    // Feb
dmonth[2]  = 31;    // Mar
dmonth[3]  = 30;    // Apr
dmonth[4]  = 31;    // May
dmonth[5]  = 30;    // Jun
dmonth[6]  = 31;    // Jul
dmonth[7]  = 31;    // Aug
dmonth[8]  = 30;    // Sep
dmonth[9]  = 31;    // Oct
dmonth[10] = 30;    // Nov
dmonth[11] = 31;    // Dec

var showQNumber = true;
var goPrefix = "question_";
var pathInitialized = false;
var ButtonOn = "qpl_button_on.gif";
var ButtonOnStyle = "QMenuRowOn";
var ButtonOff = "qpl_button_off.gif";
var ButtonOffStyle = "QMenuRow";
var MenuRow;
var ProgressBar;
var ProgressBarWidth = 130;
var RequiredFieldBackgroundErrorColor = "lightpink";
var RequiredDefaultFieldBackgroundColor = "white";
var RequiredDefaultBackgroundColor = "#F9F4F4";
var RankErrorFontColor = "red";

// Check browser version
// alert("appName: " + navigator.appName + " appVersion: " + navigator.appVersion);


var ExpirationMsg = "Warning!";
function qpl_set_expiration_warning(Hours)
{
	var MinutesBeforeExpiration = 10;
	var Now = new Date();
	Now.setTime(Now.getTime() + MinutesBeforeExpiration * 60000);
	
	ExpirationMsg = ERTable[256] + "\n\n" + ERTable[257] + "\n\n" + ERTable[258] + " " + Now.toLocaleTimeString();

	// set warning display to occur ten minutes before the page expires...
	setTimeout("qpl_display_expiration_warning()", ((Hours * 60) - MinutesBeforeExpiration) * 60000);
}
	
function qpl_display_expiration_warning()
{
	alert(ExpirationMsg);
}


// suppress Enter key in INPUT fields and screen inappropriate characters
                
function handleKeyPress (field, evt) 
{
	evt = (evt) ? evt : ((window.event) ? window.event : null);
	if (evt)
	{
		var keyCode = (evt.keyCode) ? evt.keyCode : ((evt.which) ? evt.which : evt.charCode);
	}
	else
		return true;

// window.status = "keyCode: " + keyCode;

	if (keyCode == 13 ) // Block Enter key from doing anything inside an INPUT field...
		return false;

	else if ((keyCode > 34 && keyCode < 41) || keyCode == 46)	// let cursor keys through for NetScape
		return true;

	else // check for allowable characters by QPL field type...
	{
		switch(field.qtype)
		{
			case "NUMBERI":		// <ctrl>, -, 0-9
				if ((keyCode < 32) || (keyCode == 45) || (keyCode > 47 && keyCode < 58))
					return true;
				else
					return false;
				break;
	
			case "NUMBERF":		// <ctrl>, -, ., 0-9
				if ((keyCode < 32)  || (keyCode > 44 && keyCode < 47) || (keyCode > 47 && keyCode < 58))
					return true;
				else
					return false;
				break;
				
			case "XDATE":		// <ctrl>, -, 0-9
			case "DATE":
			case "LDATE":
			case "SDATE":
				if ((keyCode < 32) || (keyCode == 45) || (keyCode > 47 && keyCode < 58))
					return true;
				else
					return false;
				break;

			case "TIME":		// <ctrl>, :, 0-9
				if ((keyCode < 32) || (keyCode > 47 && keyCode < 58) || (keyCode == 58))
					return true;
				else
					return false;
				break;
					
			default:		// STRING
				return true;
				break;
		}
	}
	return true;
}

// keep track of last question

var Previous = new Array();   // history stack
Previous[0] = 1;
var qCurrent = 1;       // current question number

function qPop()
{
//alert( "Pop BEFORE Current: " + qCurrent + "  Previous: " + Previous[Previous.length - 1] + "  Length: " + Previous.length);

	if (Previous.length > 0)
	{
		qCurrent = Previous[Previous.length - 1];
		Previous.length--;
	}

//alert( "Pop AFTER Current: " + qCurrent + "  Previous: " + Previous[Previous.length - 1] + "  Length: " + Previous.length);

	if (showQNumber)
	{
		if (Alias[qCurrent - 1] == "&nbsp;")
			window.status = "  ";
		else
			window.status = "Question " + Alias[qCurrent - 1];
		document.QPL.q_atq.value = qCurrent;
	}
}

function qPush(x, eNow)
{
//alert("Push BEFORE  New: " + x + "  Current: " + qCurrent + "  Previous: " + Previous[Previous.length - 1]+ "  Length: " + Previous.length);
	var e;
	var q;
	var FirstElem;
	var Name;
	var target;
	
	if (!pathInitialized)
		InitializePath();
	
//alert ("qPush x: " + x + " Section: " + Section[x - 1] + " q_atsec: " + document.QPL.q_atsec.value);
	
	e = xQues[x - 1];
	if (document.QPL.elements[e].qonpath)
	{
		if (x <= Ttlq && x != qCurrent)
		{
			if (qCurrent != Previous[Previous.length - 1])
			{
				Previous[Previous.length] = qCurrent;
			}
			qCurrent = x;
		}
		
		switch (document.QPL.elements[e].type)
		{
			case "checkbox":
			case "radio":
				if (arguments.length > 1)   // should only be used on GOTOs
					document.QPL.elements[e + eNow].checked = true;
				Name = document.QPL.elements[e].name;
				FirstElem = document.QPL.elements[e];
				q = document.QPL.elements[e].qnext;
				do
				{
					if (document.QPL.elements[e].qgoto > -1)
					{
						if (document.QPL.elements[e].checked)
						{
							q = document.QPL.elements[e].qgoto;
							break;
							
							
						}
					}

				} while (Name == document.QPL.elements[++e].name);
				
				DisplayQBlock(Name);  // update display of conditional blocks
				
				//window.status = "q: " + q + "  qoldnext: " + FirstElem.qoldnext;

				if (q != FirstElem.qoldnext)
				{
					FirstElem.qoldnext = q;
					UpdatePath(qCurrent - 1);
				}
				break;

			default:
				// do nothing;
		}
		if (showQNumber)
		{
			if (Alias[qCurrent - 1] == "&nbsp;")
				window.status = "  ";
			else
				window.status = "Question " + Alias[qCurrent - 1];

			document.QPL.q_atq.value = qCurrent;
		}
		return true;
	}
	else  // IE shouldn't get here...
	{
		Name = document.QPL.elements[e].name;
		switch (document.QPL.elements[e].type)
		{
			case "checkbox":
			case "radio":
				do        // note: this doesn't actually work on these guys...
				{
					document.QPL.elements[e].blur();
				} while (Name == document.QPL.elements[++e].name);
				break;
				
			default:
				document.QPL.elements[e].blur();
		}
	return false;
	}
	
}




function OkToJump(In)
{
	switch (In.qtype)
	{
		case "NUMBERI":
		return validateInt(In)
			break;

		case "NUMBERF":
		return validateFloat(In)
			break;

		case "XDATE":
		case "DATE":
		case "LDATE":
		return validateDate(In)
			break;

		case "SDATE":
		return validateSDate(In)
			break;

		case "TIME":
		return validateTime(In)
			break;

		default:
		return true;
	}
	return true;
}


function GoBack()
{
	var e = xQues[qCurrent - 1];

	if (OkToJump(document.QPL.elements[e]))
	{
		qPop();                 // update qCurrent global variable with last question

		e = xQues[qCurrent - 1];

		GoTo(qCurrent);

		if (document.QPL.elements[e].type != "hidden")
		{
			document.QPL.elements[e].focus();
		}
	}
}

function GoTo(Location)   // also used by menu.htm
{
	 if (!pathInitialized)
		return false;

//alert ("GoTo Location: " + Location + " Section: " + Section[Location - 1] + " q_atsec: " + document.QPL.q_atsec.value);
	if (Section[Location - 1] == document.QPL.q_atsec.value)  // jump is within this section
	{
		// Make top of question visible on the page
		var gotoq = document.getElementById(goPrefix + Location);
		gotoq.scrollIntoView(true);
		// Set keyboard focus on the next input field, or the next page button if there is no input field
		var Elem = document.QPL.elements[xQues[Location - 1]];
//var l = "";
//var i = 0;
//for (i = 0; i<xQues.length; i++) { l += i + ":" + xQues[i] + ":" + document.QPL.elements[xQues[i]].qthis + "\n"; }
//alert(l);
// alert(Location  + " " + Elem.type + " " + Elem.qtype);

		var Skipped = 0;
		while (Elem.type == "hidden" && Location-1 < Endq)
		{
			Elem = document.QPL.elements[xQues[++Location - 1]];
			Skipped++;
		}
		
		if (Skipped < 2)
		{
			if (Elem.type != "hidden" && Location-1 == Elem.qthis)
			{
				try {
					Elem.focus();
				}
				catch(ex)
				{
					// alert("Could not focus on " + Elem.name);
				}
			}
			else if (Elem.qtype == "QUESTIONNAIRE" && (gotoq = document.getElementById(Elem.name + "questionnaire")) )
			{
				gotoq.focus();
			}
			else if (Location-1 < Endq)
			{
				Elem = document.QPL.elements[xQues[++Location - 1]];
				if (Elem.type != "hidden" && Location-1 == Elem.qthis)
					Elem.focus();
			}
			else if ((Elem = document.getElementById("GoNext")))
			{
				try {
					Elem.focus();
				}
				catch(ex)
				{
					// alert("Could not focus on " + Elem.name);
				}
			}
			else if ((Elem = document.getElementById("GoExit")))
			{
				try {
					Elem.focus();
				}
				catch(ex)
				{
					// alert("Could not focus on " + Elem.name);
				}
			}
		} // else no focus if have multiple VOID questions...
		
	}
	else	// load appropriate section
	{
		pathInitialized = false;	// prevent re-entry into this function before new page is loaded
		window.loaded = false;
		CleanSkipPath(true);
		document.QPL.q_atq.value = Location;
		document.QPL.q_atsec.value = Section[Location - 1];
		document.QPL.q_status.value = "GoTo";
//alert("GoTo q_atq: " + document.QPL.q_atq.value + " q_atsec: " + document.QPL.q_atsec.value + " q_submit: " + document.QPL.q_submit.value);
		if (MenuOn && Ttlsec > 1)
		{
			MenuRow = document.getElementById(ButtonOffStyle + document.QPL.q_atsec.value);
			MenuRow.className = ButtonOnStyle;

			if ((ProgressBar = document.getElementById("ProgressBar")))
				ProgressBar.style.width = (Math.floor(Math.floor(document.QPL.q_atsec.value) + 1) / Ttlsec *  ProgressBarWidth) + "px";
//alert("atsec: " + (Math.floor(document.QPL.q_atsec.value) + 1) + " Ttlsec: " + Ttlsec + " width: " + Math.floor(((document.QPL.q_atsec.value + 1) / Ttlsec) * 150));
		}
		document.QPL.submit();
	}
	return false;	// to stop hypertext jump...
}


function GoForward()
{
	var q = 0;
	var e = xQues[qCurrent - 1];
	if (OkToJump(document.QPL.elements[e]))
	{
		q = document.QPL.elements[e].qnext;

		switch (document.QPL.elements[e].type)
		{
			case "checkbox":
			case "radio":
				q = document.QPL.elements[e].qoldnext;
				break;

			default:
				// do nothing;
		}

		if (Section[q] != document.QPL.q_atsec.value && q < Ttlq)
		{
			GoTo(q + 1);
			return false;
		}
		
		if (q < Ttlq)
		{
			qPush(q + 1);    // update qCurrent global variable with next question
			e = xQues[qCurrent - 1];
			GoTo(qCurrent);
			if (document.QPL.elements[e].type != "hidden")
			{
				document.QPL.elements[e].focus();
			}
		}
	}
	return true;
}


// Check for blank response.

function isblank(s)
{
	if (s == null) return true;

	for (var i = 0; i < s.length; i++)
	{
		var c = s.charAt(i);
		if ((c != ' ') && (c != '\n') && (c != '\t'))
			return false;
	}
	return true;
}


function validateFloat(In) {
	var Msg;
	var Number;
	var Left;

	window.status = "";
	
	// 2012-12-17 kbd - Hook to custom function to check groups of ranking questions
	CheckRank(In.name);
	CheckSum(In.name);
	CheckRequired(In);

	if (isblank(In.value))
	{
		In.value = "";
		In.qisok = true;
		if (PageFileType == "PHP")
			sendData(In.name, "NULL");
		return true;
	}

	if (!In.qonpath)
		return false;

	if ((Left = In.value.search(/\./)) == -1)
	{
		Left = In.value.length;
	}

	Number = parseFloat(In.value);

	if (isNaN(Number) || Left > In.qleft)
	{
		if (In.qisok)
		{
			In.qisok = false;
			if (Alias[In.qthis] == "&nbsp;")
				Msg = "";
			else
				Msg = ERTable[262] + " " + Alias[In.qthis] + "\n\n";	// Question #
				
			if (Left > In.qleft)
				Msg += "'" + In.value + "' " + ERTable[259] + "\n\n";	//  is too big.
			else
				Msg += "'" + In.value + "' " +  ERTable[260] + "\n\n";	// is not a valid number.
			Msg += ERTable[261];	// Please enter a valid number or leave the answer blank.
			alert(Msg);
			setTimeout("focusElement('" + In.form.name + "', '" + In.name + "')", 0);
			return false;
		}
		else
		{
			In.value = "";
			In.qisok = true;
			return true;
		}
	}
	else
	{
		In.value = Number;
		In.qisok = true;
		showQNumber = true;

		if (PageFileType == "PHP")
			sendData(In.name, In.value);
	}
	return true;
}


// Check for valid integer.
// Should be called from an onBlur event.

function validateInt(In) {
	var Msg;
	var Number;

	window.status = "";

	// 2012-12-17 kbd - Hook to custom function to check groups of ranking questions
	CheckRank(In.name);
	CheckSum(In.name);
	CheckRequired(In);

	if (isblank(In.value))
	{
		In.value = "";
		In.qisok = true;
		if (PageFileType == "PHP")
			sendData(In.name, "NULL");
		return true;
	}

	if (!In.qonpath)
		return false;

	Number = parseInt(In.value, 10);

	if (isNaN(Number))
	{
		if (In.qisok)
		{
			In.qisok = false;
			if (Alias[In.qthis] == "&nbsp;")
				Msg = "";
			else
				Msg = ERTable[262] + " " + Alias[In.qthis] + "\n\n";	// Question #
			Msg += "'" + In.value + "' " + ERTable[263] + "\n\n";	// is not a valid integer.
			Msg += ERTable[263];	// Please enter a valid integer or leave the answer blank.
			alert(Msg);
			setTimeout("focusElement('" + In.form.name + "', '" + In.name + "')", 0);
			return false;
		}
		else
		{
			In.value = "";
			In.qisok = true;
			return true;
		}
	}
	else
	{
		In.value = Number;
		In.qisok = true;
		showQNumber = true;
		
		if (PageFileType == "PHP")
			sendData(In.name, In.value);
	}
	return true;
}

// validate "Skip to" instruction for MULT and CHECK questions

function validateSkip(In)
{
	var Msg;

	if (In.length == null)		// only one answer in the list
	{
		if (!In.qonpath)
			return false;
		else
			return true;
	}
	
	if (!In[0].qonpath)
		return false;

	if (In[0].qnext != In[0].qoldnext)
	{
		for (var i = 0; i < In.length; i++)
		{
			if (In[i].checked && In[i].qgoto > -1)
			{
				if (Alias[In[0].qthis] == "&nbsp;")
					Msg = "";
				else
					Msg = ERTable[262] + " " + Alias[In[0].qthis] + "\n\n";	// Question #
				Msg += ERTable[265] + " " + Alias[In[i].qgoto] + ".\n\n";	// According to your reponse(s) to this question, you should next go to question:
				Msg += ERTable[266] + " #" + (i+1) + ".";	// Please click on the link at answer
				alert(Msg);
				return false;
			}
		}
	}
	return true;
}



// validate goto for MULT questions

function validateGotoMult(In, e)
{
	var Msg;
	var Checked = 0;

	
	if (!In[0].qonpath)
		return false;

	if (Alias[In[0].qthis] == "&nbsp;")
		Msg = "";
	else
		Msg = ERTable[262] + " " + Alias[In[0].qthis] + "\n\n";	// Question #


	for (var i = 0; i < In.length; i++)
	{
		if (In[i].checked)
		{
			Checked  = In[i].value;
			break;
		}
	}
		
	if (Checked == 0)
		Msg += ERTable[274] + "\n\n";	// "You have not selected an answer yet." 
	else if (Checked != e)
		Msg += ERTable[275] + "\n\n";	// "You did not select the answer for this link."
	else
		return true;
				
	alert(Msg);
	
	return false;
}

// validate "Go to" instruction for CHECK questions

function validateGoto(In, e)
{
	var Msg;
	
	if (In.length == null)		// only one answer in the list
	{
		if (!In.qonpath)
			return false;
		else
			return true;
	}

	if (!In[0].qonpath)
		return false;

	//window.status = "qoldnext: " + In[0].qoldnext + "  qgoto: " + In[e].qgoto;
	if (In[0].qoldnext != In[e].qgoto)
	{
		for (var i = 0; i < In.length; i++)
		{
			if (In[i].checked && In[i].qgoto > -1)
			{
				if (e < i)
					return true;
				if (Alias[In[0].qthis] == "&nbsp;")
					Msg = "";
				else
					Msg = ERTable[262] + " " + Alias[In[0].qthis] + "\n\n";	// Question #

				Msg += ERTable[265] + " " + Alias[In[i].qgoto] + ".\n\n";	// According to your reponse(s) to this question, you should next go to question:

				Msg += ERTable[266] + " #" + Alias[i] + ".";	// Please click on the link at answer
				alert(Msg);
				return false;
			}
		}
		return true;
	}
	else
		return true;
}


// validate TIME question

function validateTime(In) {
	var TimePattern = /^((2[0-3])|([0-1]?[0-9])):[0-5][0-9]:[0-5][0-9]/;
	window.status = "";
	showQNumber = true;

	CheckRequired(In);
	
	if (isblank(In.value))
	{
		In.value = "";
		In.qisok = true;
		if (PageFileType == "PHP")
			sendData(In.name, "NULL");
		return true;
	}
	
	if (!In.qonpath)
		return false;

	if (!TimePattern.test(In.value))
	{
		if (In.qisok)
		{
			In.qisok = false;
			if (Alias[In.qthis] == "&nbsp;")
				Msg = "";
			else
				Msg = ERTable[262] + " " + Alias[In.qthis] + "\n\n";	// Question #

			Msg += "'" + In.value + "' " + ERTable[267] + "\n\n";	//  is not a valid time.
			Msg += ERTable[268];	// Please enter the time in 'hh:mm:ss' format or leave the answer blank.
			alert(Msg);
			setTimeout("focusElement('" + In.form.name + "', '" + In.name + "')", 0);
			return false;
		}
		else
		{
			In.value = "";
			In.qisok = true;
			if (PageFileType == "PHP")
				sendData(In.name, "NULL");
			return true;
		}
	}
	In.qisok = true;

	if (PageFileType == "PHP")
		sendData(In.name, In.value);

	return true;
}

function focusElement(formName, elemName)
{
	var elem = document.forms[formName].elements[elemName];
	elem.focus();
	elem.select();
}


// validate DATE, LDATE, and XDATE questions

function validateDate(In) {
	var Msg;
	var DateIn = new Array(3);
	var Month;
	var Day;
	var Year;
	var TempYear;
	var i;
	var j = 0;
	var ErrorFlag = false;
	var c;

	window.status = "";
	showQNumber = true;

	CheckRequired(In);
	
	if (isblank(In.value))
	{
		In.value = "";
		if (PageFileType == "PHP")
			sendData(In.name, "NULL");
		return true;
	}

	if (!In.qonpath)
		return false;


	// parse numbers
	for (j = 0; j < 3; j++)
	{
		DateIn[j] = "";
	}
	j = 0;

	for (i = 0; i < In.value.length; i++)
	{
		c = In.value.charAt(i);
		if ((c != ' ') && (c != '\n') && (c != '\t'))
		{
			if (c >= '0' && c <= '9')
			{
				DateIn[j] += c;
			}
			else
			{
				if (DateIn[j].length && j < 2)
				{
					j++;
				}
			}
		}
	}

	// put into common order

	switch (DateFormat)
	{
		case 0:   // usa m/d/y
			Month = DateIn[0];
			Day   = DateIn[1];
			Year  = DateIn[2];
			break;

		case 1:   // europe d/m/y
			Day   = DateIn[0];
			Month = DateIn[1];
			Year  = DateIn[2];
			break;

		case 2:   // japan y/m/d
			Year  = DateIn[0];
			Month = DateIn[1];
			Day   = DateIn[2];
			break;

		default:
			// should not get here
	}

	// do an almost perfect date validation

	if (Month.length == 0 || Month < 1 || Month > 12)
	{
		ErrorFlag = true;
	}
	else if (Day.length == 0 || Day < 1 || Day > dmonth[Month - 1])  // doesn't check for leap years...
	{
		ErrorFlag = true;
	}
	if (Year.length == 0 || Year < 0 || Year > 9999)
	{
		ErrorFlag = true;
	}

	if (ErrorFlag)
	{
		if (In.qisok)
		{
			In.qisok = false;
			if (Alias[In.qthis] == "&nbsp;")
				Msg = "";
			else
				Msg = ERTable[262] + " " + Alias[In.qthis] + "\n\n";	// Question #

			Msg += "'" + In.value + "' " + ERTable[269] + "\n\n";	//  is not a valid date.
			Msg += ERTable[270];	// Please enter date in 'yyyy-mm-dd' format shown or leave the answer blank.
			alert(Msg);
			setTimeout("focusElement('" + In.form.name + "', '" + In.name + "')", 0);
			return false;
		}
		else
		{
			In.value = "";
			In.qisok = true;
			if (PageFileType == "PHP")
				sendData(In.name, "NULL");
			return true;
		}
	}
	else    // clean up date...
	{
		In.qisok = true;
		showQNumber = true;

		if (In.qtype == "DATE")
		{
			if (Year.length == 1)
				Year = "0" + Year;
		}
		else
		{
			switch (Year.length)
			{
				case 1:
					Year = "200" + Year;
					break;

				case 2:
					Year = "20" + Year;
					break;

				case 3:
					Year = "2" + Year;
					break;

				default:
					// do nothing;
			}
		}
		if (Month.length == 1)
		{
			Month = "0" + Month;
		}
		if (Day.length == 1)
		{
			Day = "0" + Day;
		}

		switch (DateFormat)
		{
			case 0:   // usa m/d/y
				In.value = Month + DateSep + Day + DateSep + Year;
				break;

			case 1:   // europe d/m/y
				In.value = Day + DateSep + Month + DateSep + Year;
				break;

			case 2:   // japan y/m/d
				In.value = Year + DateSep + Month + DateSep + Day;
				break;

			default:
				// should not get here
		}

		if (PageFileType == "PHP")
			sendData(In.name, In.value);
	
	}
	return true;
}

// validate SDATE

function validateSDate(In) {
	var Msg;
	var DateIn = new Array(3);
	var Month;
	var Day;
	var Year;
	var TempYear;
	var i;
	var j = 0;
	var ErrorFlag = false;
	var c;

	window.status = "";
	showQNumber = true;

	CheckRequired(In);

	if (isblank(In.value))
	{
		In.value = "";
		if (PageFileType == "PHP")
			sendData(In.name, "NULL");
		return true;
	}

	if (!In.qonpath)
		return false;


	// parse numbers
	for (j = 0; j < 2; j++)
	{
		DateIn[j] = "";
	}
	j = 0;

	for (i = 0; i < In.value.length; i++)
	{
		c = In.value.charAt(i);
		if ((c != ' ') && (c != '\n') && (c != '\t'))
		{
			if (c >= '0' && c <= '9')
			{
				DateIn[j] += c;
			}
			else
			{
				if (DateIn[j].length && j < 1)
				{
					j++;
				}
			}
		}
	}

	// put into common order

	switch (DateFormat)
	{
		case 0:   // usa m/d/y
			Month = DateIn[0];
			Year  = DateIn[1];
			break;

		case 1:   // europe d/m/y
			Month = DateIn[0];
			Year  = DateIn[1];
			break;

		case 2:   // japan y/m/d
			Year  = DateIn[0];
			Month = DateIn[1];
			break;

		default:
			// should not get here
	}

	// do an almost perfect date validation

	if (Month.length == 0 || Month < 1 || Month > 12)
	{
		ErrorFlag = true;
	}
	if (Year.length == 0 || Year < 0 || Year > 9999)
	{
		ErrorFlag = true;
	}
//alert("Month: " + Month + " Year: " + Year );
	if (ErrorFlag)
	{
		if (In.qisok)
		{
			In.qisok = false;
			if (Alias[In.qthis] == "&nbsp;")
				Msg = "";
			else
				Msg = ERTable[262] + " " + Alias[In.qthis] + "\n\n";	// Question #

			Msg += "'" + In.value + "' " + ERTable[269] + "\n\n";	//  is not a valid date.
			Msg += ERTable[271];	// Please enter date in 'yyyy-mm' format shown or leave the answer blank.
			alert(Msg);
			setTimeout("focusElement('" + In.form.name + "', '" + In.name + "')", 0);
			return false;
		}
		else
		{
			In.value = "";
			In.qisok = true;
			if (PageFileType == "PHP")
				sendData(In.name, "NULL");
			return true;
		}
	}
	else    // clean up date...
	{
		In.qisok = true;
		showQNumber = true;

		switch (Year.length)
		{
			case 1:
				Year = "200" + Year;
				break;

			case 2:
				Year = "20" + Year;
				break;

			case 3:
				Year = "2" + Year;
				break;

			default:
					// do nothing;
		}
		if (Month.length == 1)
		{
			Month = "0" + Month;
		}

		switch (DateFormat)
		{
			case 0:   // usa m/d/y
				In.value = Month + DateSep + Year;
				break;

			case 1:   // europe d/m/y
				In.value = Month + DateSep + Year;
				break;

			case 2:   // japan y/m/d
				In.value = Year + DateSep + Month;
				break;

			default:
				// should not get here
		}
	}
	if (PageFileType == "PHP")
		sendData(In.name, In.value + "-01");

	return true;
}

// prototyping...
function validateString(In)
{
	if (PageFileType == "PHP")
		sendData(In.name, In.value.length ? In.value : "NULL");
	
	CheckRequired(In);

	return true;
}

function validateList(In)
{
	if (PageFileType == "PHP")
		sendData(In.name, In.options[In.options.selectedIndex].value);

	CheckRequired(In);
	
	return true;
}


// prototyping...
function validateMult(In)
{
	if (In.checked)
	{
		if (PageFileType == "PHP")
			sendData(In.name, In.value);
	}

	CheckRequired(In);
	
	return true;
}


function validateCheck(In)
{
	if (PageFileType == "PHP")
	{
		if (In.checked)
		{
			sendData(In.name.substring(0, In.name.length - 2) + "_" + In.value, 1);
			//alert(In.name.substring(0, In.name.length - 2) + "_" + In.value + " 1");
		}
		else
		{
			sendData(In.name.substring(0, In.name.length - 2) + "_" + In.value, 0);
			//alert(In.name.substring(0, In.name.length - 2) + "_" + In.value + " 0");
		}
	}
	
	CheckRequired(In);

	return true;
}



// get default date for XDATE question

function getXDate(Style, Separator)
{
	var LToday = new Date();
	var Month, Day, Year;
	var SToday;

	Month = LToday.getMonth() + 1;
	Day = LToday.getDate();
	Year = LToday.getFullYear();

	switch (Style)
	{
		case 0:   // usa m/d/y
			SToday = Month + Separator + Day + Separator + Year;
			break;

		case 1:   // europe d/m/y
			SToday = Day + Separator + Month + Separator + Year;
			break;

		case 2:   // japan y/m/d
			SToday = Year + Separator + Month + Separator + Day;
			break;

		default:
			// should not get here
	}
	return SToday;
}

// get time for TIME question

function setTime(In, Style, Separator)
{
	var Now = new Date();
	var Hours = Now.getHours();
	var Minutes = Now.getMinutes();
	var Seconds = Now.getSeconds();
	var AmPm = " a.m.";

	if (Minutes < 10)
	{
		Minutes = "0" + Minutes;
	}

	if (Seconds < 10)
	{
		Seconds = "0" + Seconds;
	}

	if (Style == 0)     // use a.m. and p.m.
	{
		if (Hours > 12)
		{
			Hours -= 12;
			AmPm = " p.m."
		}
		else if (Hours == 12)
		{
			AmPm = " p.m."
		}
		else if (Hours == 0)
		{
			Hours = 12;
		}
		In.value = Hours + Separator + Minutes + Separator + Seconds + AmPm;
	}
	else
	{
		In.value = Hours + Separator + Minutes + Separator + Seconds;
	}
	In.focus();
}


// check skip path goto and next instructions, and erase values for off-path
// questions if DoCleanup is true.

function CleanSkipPath(DoCleanup)               //returns true if it cleans ok
{                                       //if DoCleanUp is false, only check the path
	var Ques = new Array();
	var Msg = "";
	var Name = "";
	var q = Startq;
	var Lastq = q;
	var First;
	var e;

//alert("Starting CleanSkipPath: " + DoCleanup + ", q_atq: " + document.QPL.q_atq.value + " q_atsec: " + document.QPL.q_atsec.value);
	if (MenuOn && Ttlsec > 1)
	{
		MenuRow = document.getElementById(ButtonOffStyle + document.QPL.q_atsec.value);
		MenuRow.className = ButtonOnStyle;
		
		if ((ProgressBar = document.getElementById("ProgressBar") ))
			ProgressBar.style.width = (Math.floor(Math.floor(document.QPL.q_atsec.value) + 1) / Ttlsec *  ProgressBarWidth) + "px";
	}

	if (document.QPL.q_status.value == "Cancel")
		return true;

	// check for file upload... display Please wait message if have a live one...
	for (var i = 0; i < document.QPL.length; i++)
	{
		if (document.QPL.elements[i].type == "file" && document.QPL.elements[i].value.length > 0)
		{
			// alert("Upload: " + document.QPL.elements[i].value + " Length: " + document.QPL.elements[i].value.length);
			ToggleBlock("upload");
			break;
		} 
	}

	
	if (Ttlsec == 1)		// only clean path for single-page forms
	{
		// reset qonpath flags ////////////////////////////////

		for (var i = 0; i < document.QPL.length; i++)
		{
			document.QPL.elements[i].qonpath = false;
			document.QPL.elements[i].disabled = false;
		}

		// walk the skip path ////////////////////////////////////
	
		while (q >= Startq && q <= Endq)
		{
			e = xQues[q];
			if (document.QPL.elements[e].qonpath)
			{
				Msg =  "Error at question " + Alias[Lastq] + ".\n\n";
				Msg += "This question leads to question " + Alias[q] + ", which was already answered.\n\n";
				Msg += "Please check your response to question " + Alias[Lastq] + ".";
				alert(Msg);

				GoTo(Lastq+1);
				return false;
			}
			Lastq = q;
			q = document.QPL.elements[e].qnext;
			First = true;

			switch (document.QPL.elements[e].type)
			{
				case "checkbox":
				case "radio":
					Name = document.QPL.elements[e].name;
					do
					{
						if (document.QPL.elements[e].qgoto > -1 &&
							document.QPL.elements[e].checked &&
							First)
						{
							q = document.QPL.elements[e].qgoto;
							First = false;                            // only the first goto in a CHECK question will be used!
						}
						document.QPL.elements[e++].qonpath = true;

					} while (Name == document.QPL.elements[e].name);
					break;
					
				default:
					document.QPL.elements[e].qonpath = true;
			}
		}
	}

	if (DoCleanup)
	{
		for (var i = 0; i < document.QPL.length; i++)
		{
			var Elem = document.QPL.elements[i];
	
			if (!Elem.qonpath)		// all questions in multi-page forms are on the path...
			{
				switch (Elem.type)
				{
					case "checkbox":
					case "radio":
						// Elem.checked = false;
						Elem.checked = true;	// qpl_catch.php watches specially for NULLs!
						Elem.value = "NULL";
						break;
		
					case "text":
					case "textarea":
					case "password":
					
						// Elem.value = "";
						Elem.value = "NULL";	// qpl_catch.php watches specially for NULLs!
						break;
					
					default:
						// do nothing with hidden fields;
				}
			}
			else	// set any empty numbers or dates to NULL too!
			{
				if (Elem.type == "text" && (
						Elem.qtype ==  "NUMBERF" ||
						Elem.qtype ==  "NUMBERI" ||
						Elem.qtype ==  "XDATE" ||
						Elem.qtype ==  "TIME" ||
						Elem.qtype ==  "SDATE" ||
						Elem.qtype ==  "DATE" ||
						Elem.qtype ==  "LDATE") &&
						isblank(Elem.value))
							Elem.value = "NULL";	// qpl_catch.php watches specially for NULLs!

				else
				{
					if (Elem.qtype ==  "SDATE")	// add day value for MySQL date.
					{
						Elem.maxLength = 10;
						Elem.value = Elem.value + "-01";
					}
				} 
			}
		}
	}
	else
	{
		alert("No errors found in the skip path.");
	}
//alert("Ending CleanSkipPath: " + DoCleanup + ", q_atq: " + document.QPL.q_atq.value + " q_atsec: " + document.QPL.q_atsec.value);

	return true;
}

function InitializePath()
{
	var Msg = "";
	var Name = "";
	var q;
	var First;
	var FirstElem;
	var Elem;
	var e;
	var i;

	if (pathInitialized)
		return true;
		
	if (Ttlsec > 1)		// set all to onpath for now with mult-part forms...
	{
		for (e = 0; e < document.QPL.length; e++)
		{
			document.QPL.elements[e].qonpath = true;
			
			if (document.QPL.elements[e].type == "checkbox" || document.QPL.elements[e].type == "radio")
			{
				DisplayQBlock(document.QPL.elements[e].name);  // update display of conditional blocks
			}
                        else if (document.QPL.elements[e].type == "hidden")
                        {
                                if (document.QPL.elements[e].qblock)
                                {
                                        if (document.QPL.elements[e].qblock[document.QPL.elements[e].value].length)
                                        {
						var target = document.getElementById(document.QPL.elements[e].qblock[document.QPL.elements[e].value]);
						if (target) {
							if (DisplayBlockFade)
							{
								target.style.height = "auto";
								target.style.opacity = 1;
							}
							else
							{
								target.style.display = "block";
							}
						}
                                        }
                                }
                        }
                }
	}
	else
	{
		// set all qonpath flags to false ////////////////////////////////    
		for (e = 0; e < document.QPL.length; e++)
		{
			Elem = document.QPL.elements[e];
			Elem.qonpath = false;

			if ((Elem.type != "hidden" &&
				Elem.type != "button" &&
				Elem.type != "submit"))
			{
				Elem.disabled = true;
				// fix problem in IE where default checks are lost when setting disables
				if (Elem.type == "checkbox" || Elem.type == "radio")
					Elem.checked = Elem.defaultChecked;
			}
		}
		
		// walk the skip path and set those qonpath flags to true //////////////////
		q = 0;
		while (q < Ttlq)
		{
			e = xQues[q];
	
			if (document.QPL.elements[e].qonpath)
				break;
		
			q = document.QPL.elements[e].qnext;
			First = true;

			Name = document.QPL.elements[e].name;
			FirstElem = document.QPL.elements[e];

			switch (document.QPL.elements[e].type)
			{
				case "checkbox":
				case "radio":
					Name = document.QPL.elements[e].name;

					do
					{
						if (document.QPL.elements[e].qgoto > -1 &&
							document.QPL.elements[e].checked &&
							First)
						{
							q = document.QPL.elements[e].qgoto;
							First = false;                            // only the first goto in a CHECK question will be used!
						}
						document.QPL.elements[e].qonpath = true;
						document.QPL.elements[e].disabled = false;

					} while (Name == document.QPL.elements[++e].name);
					
					DisplayQBlock(Name);  // update display of conditional blocks
					
					break;
										
				case "hidden":
					if (FirstElem.qblock)
					{
						if (FirstElem.qblock[FirstElem.value].length)
						{
							var target = document.getElementById(FirstElem.qblock[FirstElem.value]);
							if (target) {
								if (DisplayBlockFade)
								{
									target.style.height = "auto";
									target.style.opacity = 1;
								}
								else
								{
									target.style.display = "block";
								}
							}
						}
					}
					break;
				

				default:
					document.QPL.elements[e].qonpath = true;
					document.QPL.elements[e].disabled = false;

			}
		}
	}

	// set starting qoldnext question number for questions in this section ////////////
	//alert("InitializePath:  Ttlsec: " + Ttlsec + " Startq: " + Startq + " Endq: "+ Endq);
	for (q = Startq; q <= Endq; q++)
	{
		e = xQues[q];
		Elem = document.QPL.elements[e];
		
		switch (Elem.type)
		{
			case "checkbox":
			case "radio":
				Name = Elem.name;
				FirstElem = Elem;
				FirstElem.qoldnext = Elem.qnext;
				do
				{
					if (document.QPL.elements[e].qgoto > -1 &&
						document.QPL.elements[e].checked)
					{
						FirstElem.qoldnext = document.QPL.elements[e].qgoto;
						break;
					}

				} while (Name == document.QPL.elements[++e].name);
				break;

			default:
				// do nothing..
		}
	}
//alert("InitializePath:  q_atq: " + document.QPL.q_atq.value);
	Previous[0] = (document.QPL.q_atq.value * 1.0);
	qCurrent = (document.QPL.q_atq.value * 1.0);       // current question number
	
	// set inital display values
	if (MenuOn && Ttlsec > 1)
	{
//alert(ButtonOffStyle + document.QPL.q_atsec.value);
		MenuRow = document.getElementById(ButtonOffStyle + document.QPL.q_atsec.value);
		MenuRow.className = ButtonOnStyle;

		if ((ProgressBar = document.getElementById("ProgressBar") ))
			ProgressBar.style.width = (Math.floor(Math.floor(document.QPL.q_atsec.value) + 1) / Ttlsec *  ProgressBarWidth) + "px";
	}

	pathInitialized = true;
	
	if (document.QPL.q_atq.value > 0)		// restart at last question in focus
	{
		GoTo(document.QPL.q_atq.value);
		if (Alias[document.QPL.q_atq.value - 1] == "&nbsp;")
			window.status = "  ";
		else
			window.status = "Question " + Alias[document.QPL.q_atq.value - 1];

	}
//alert("InitializePath:  pathInitialized: " + pathInitialized);
	return true;
}

function UpdatePath(q)
{
	var Msg = "";
	var Name = "";
	var First;
	var NewPath = new Array();
	var FirstElem;
	var e;

	if (Ttlsec > 1)
		return true;	// skip this for now with multi-part forms
	
	// start rechecking path at specified q

	// walk the skip path ////////////////////////////////////

	var i = 0;
	NewPath[i++] = q;

	while (q < Ttlq)
	{
		// starting q must be on the path
		
		e = xQues[q];

		if (NewPath[0] != q && document.QPL.elements[e].qonpath)
			break;
		
		q = document.QPL.elements[e].qnext;
		First = true;

		switch (document.QPL.elements[e].type)
		{
			case "checkbox":
			case "radio":
				Name = document.QPL.elements[e].name;

				do
				{
					if (document.QPL.elements[e].qgoto > -1 &&
						document.QPL.elements[e].checked &&
						First)
					{
						q = document.QPL.elements[e].qgoto;
						First = false;                            // only the first goto in a CHECK question will be used!
					}
					document.QPL.elements[e].qonpath = true;
					document.QPL.elements[e].disabled = false;

				} while (Name == document.QPL.elements[++e].name);
				break;

			default:
				document.QPL.elements[e].qonpath = true;
				document.QPL.elements[e].disabled = false;

		}
		NewPath[i++] = q;
	}

	// fix off-path questions //////////////////////////////////

	for (var i = 0; i < NewPath.length - 1; i++)
	{
		for (q = NewPath[i] + 1; q < NewPath[i+1]; q++)
		{
			e = xQues[q];
			switch (document.QPL.elements[e].type)
			{
				case "checkbox":
				case "radio":
					Name = document.QPL.elements[e].name;

					do
					{
						document.QPL.elements[e].qonpath = false;
						document.QPL.elements[e].disabled = true;

					} while (Name == document.QPL.elements[++e].name);
					break;

				default:
					document.QPL.elements[e].qonpath = false;
					document.QPL.elements[e].disabled = true;
			}
		}
	}
	return true;
}

function MovePage(Direction)
{
	// Direction = -1 to move one page back or +1 to move one page forward
	// set section
//alert("Before MovePage q_atq: " + document.QPL.q_atq.value + " q_atsec: " + document.QPL.q_atsec.value);
	var NextPage;

	if (!pathInitialized)
		return false;
	
	NextPage = (document.QPL.q_atsec.value * 1.0) + (Direction * 1.0);
	
	if (NextPage >= 0 && NextPage < Ttlsec)
	{
		if (MenuOn && Ttlsec > 1)
		{
			MenuRow = document.getElementById(ButtonOffStyle + document.QPL.q_atsec.value);
			MenuRow.className = ButtonOffStyle;
			
			if ((ProgressBar = document.getElementById("ProgressBar") ))
				ProgressBar.style.width = (Math.floor(Math.floor(document.QPL.q_atsec.value) + 1) / Ttlsec *  ProgressBarWidth) + "px";
		}
		document.QPL.q_atsec.value = NextPage;
	}
	else
		return false;

	pathInitialized = false;	// prevents re-entry into this function before new page finishes loading...
	
	if (MenuOn && Ttlsec > 1)
	{
		MenuRow = document.getElementById(ButtonOffStyle + document.QPL.q_atsec.value);
		MenuRow.className = ButtonOnStyle;
		
		if ((ProgressBar = document.getElementById("ProgressBar")))
			ProgressBar.style.width = (Math.floor(Math.floor(document.QPL.q_atsec.value) + 1) / Ttlsec *  ProgressBarWidth) + "px";
	}
	
	// set first question on that section
	for (var i = 0; i < Ttlq; i++)
	{
		if (Section[i] == document.QPL.q_atsec.value)
		{
			document.QPL.q_atq.value = i + 1;
			break;
		}
	}
//alert("After MovePage q_atq: " + document.QPL.q_atq.value + " q_atsec: " + document.QPL.q_atsec.value);
	
	// manually submit page if called from the navigation bar...
	if (arguments.length == 2 && arguments[1])  
	{
		CleanSkipPath(true);
		document.QPL.q_status.value = "GoTo";
		document.QPL.submit();
	}
	return true;
}

function PrintPage()
{
	return false;	// doesn't work...
	parent.main.focus();
	window.print();
	return false;
}

function Stop()
{
	CleanSkipPath(true);
	document.QPL.q_status.value = "Finished";
	document.QPL.submit();
}

function GoToEnd()
{
	GoTo(Ttlq);
	return false;
}

function PostForm()
{
	if (window.loaded) 
	{
		document.QPL.q_status.value='Finished'; 
		window.loaded=false; 
		return true;
	} 
	else 
	{
		alert('You have already submitted your responses.'); 
		return false;
	}
}

/////////////////////////////////////////////////////////////////////
// Pop-Up window utility function
// Call from a .pgm file using an anchor tag...
//
// (See \<a href=\"javascript:PopUp('definitions.htm', 400, 300);\"\>definitions\</a\>.)
//
// Also need to escape all special HTML characters! and where the content
// is in a simple HTML file..
//

var popupWindow = null;
function PopUp(targetfile, height, width)
{
	if (popupWindow != null) 
		popupWindow.close();

	popupWindow = window.open(targetfile, 'QPLPOPUPWIN', 
		"width=" + (width < 100 ? 100 : width) + 
		",height=" + (height < 100 ? 100 : height) + 
		",scrollbars,left=10,top=10,screenX=10,screenY=10", true); 
	    
	popupWindow.focus();
}

/////////////////////////////////////////////////////////////////////
// Show personal responses utility function
// Call from a .pg6 file using an anchor tag...
//
// (See \<a href=\"javascript:showPersonalResponses(790, ".en");\" title=\"View response summary\"\>View response summary\</a\>.)
//
// Also need to escape all special HTML characters! and where the content
// is in a simple HTML file..
//

var showPersonalResponsesWindow = null;
function showPersonalResponses(Width, Language)
{
	if (showPersonalResponsesWindow != null) 
		showPersonalResponsesWindow.close();

	if (PageFileType == "HTML")
	{
		alert("A summary of this respondent's answers will be displayed when this\nlink is clicked after it has been deployed on a web server.");
	}
	else
	{
		var Url = "qpl_show_personal_responses.php" + "?q_sess_id=" + document.QPL.q_sess_id.value + "&q_language=" + Language;
		
		showPersonalResponsesWindow = window.open(Url, 'QPLRESPWIN', 
			"width=" + Width + ",height=540,scrollbars,left=10,top=10,screenX=10,screenY=10", true); 
	    
		showPersonalResponsesWindow.focus();
	}
}


//////////////////////////////////////////////////////////////////////
// QUESTIONNAIRE  function to put jump info into hidden fields
// for qpl_catch.php to see.

function Move_To_Questionnaire(In, target_q_id)
{
	In.value = target_q_id;
	document.QPL.q_to_q_id.value = target_q_id;
	document.QPL.q_from_q_varname.value = In.name;
	document.QPL.q_status.value = "To Survey";
	CleanSkipPath(true);
	document.QPL.submit();
	return false;
}



//////////////////////////////////////////////////////////////////////
// used to toggle display of menu links: <A HREF="#" onClick="return ToggleBlock('idname');">lkjlk lkj</A>
function ToggleBlock(id)
{
	if (document.getElementById)
	{
		var target = document.getElementById(id).style;
		
		// if (target.display == "block")
		if (target.opacity == 1)
		{
				target.opacity = 0;
				target.height = "0";
				// target.display = "none";  ... using CSS3 transition instead ...
		}
		else
		{
			target.height = "auto";
			target.opacity = 1;
			// target.display = "block";  ... using CSS3 transition instead ...
		}
	}
	return false;
}


//////////////////////////////////////////////////////////////////////
// Display blocks of questions according to radio or checkbox item selections.
// This rolls through all the answers in the question and displays a block
// of questions if an item has a block defined AND if it is checked for any answer. 
// If it is defined but not checked by any answer, then the block is not displayed.

function DisplayQBlock(qname)
{
	var List = new Array();
	
	if (typeof(document.QPL.elements[qname][0]) != "undefined")
	{
		for (var e = 0; e < document.QPL.elements[qname].length; e++)
		{
			if (document.QPL.elements[qname][e].qblock.length)
			{
				if (document.getElementById(document.QPL.elements[qname][e].qblock) != null)
				{
					if (!(document.QPL.elements[qname][e].qblock in List))
					{
							List[	document.QPL.elements[qname][e].qblock ] = 0;
					}
					List[	document.QPL.elements[qname][e].qblock ] += (document.QPL.elements[qname][e].checked ? 1 : 0);
				}
			}
		}
		for (var i in List)
		{
			var target = document.getElementById(i).style;
					
			if (List[i])	// show questions
			{
				if (DisplayBlockFade)
				{
					target.height = "auto";
					target.opacity = 1;
				}
				else
					target.display = "block";
			}
			else			// hide questions
			{
				if (DisplayBlockFade)
				{
					target.opacity = 0;
					target.height = "0";
				}
				else
					target.display = "none";
			}
		}
	}
	else	// only has one check box!
	{
		if (document.QPL.elements[qname].qblock.length)
		{
			if (document.getElementById(document.QPL.elements[qname].qblock) != null)
			{
				var target = document.getElementById(document.QPL.elements[qname].qblock).style;
				
				if (document.QPL.elements[qname].checked)	// show questions
				{
					if (DisplayBlockFade)
					{
						target.opacity = 1;
						target.height = "auto";
					}
					else
						target.display = "block";
				}
				else			// hide questions
				{
					if (DisplayBlockFade)
					{
						target.opacity = 0;
						target.height = "0";
					}
					else
						target.display = "none";  
				}
			}
		}
	}	
}


//////////////////////////////////////////////////////////////////////
// TEXTAREA text entry limitation functions...
// 


function handleKeyPressTA (In, evt) 
{
	evt = (evt) ? evt : ((window.event) ? window.event : null);
	if (evt)
	{
		var keyCode = (evt.keyCode) ? evt.keyCode : ((evt.which) ? evt.which : evt.charCode);
	}
	else
		return true;
		
	//if (keyCode == 13 ) // Block Enter key from doing anything inside an INPUT In...
	//	return false;

	return true;
		
}

function validateOpenEnd(In, OkToSend) 
{
	var target = document.getElementById(In.name + "charactercount");

	CheckRequired(In);
	
	In.value = In.value.replace(/[\t]/g, " ");
	In.value = In.value.replace(/  /g, " ");
	In.value = In.value.replace(/  /g, " ");
	In.value = In.value.replace(/  /g, " ");
	In.value = In.value.replace(/^[\t\r\n ]+/, "");
	In.value = In.value.replace(/[\t\r\n ]+$/, "");

	if (target) target.innerHTML = In.value.length;
	
	if (In.value.length > In.qmaxtextsize)
	{
		In.value = In.value.substr(0, In.qmaxtextsize);
		if (target) target.innerHTML = In.value.length;
		alert(ERTable[272]);	// Too long!
		In.focus();
		return false;
	}

	if (PageFileType == "PHP" && OkToSend)
		sendData(In.name, In.value.length ? In.value : "NULL");

	return true;	
}

function handleUpdownTA (In) 
{
	var target = document.getElementById(In.name + "charactercount");

	if (target) target.innerHTML = In.value.length;
	
	if (In.value.length > In.qmaxtextsize)
	{
		In.value = In.value.replace(/[\t]/g, " ");
		In.value = In.value.replace(/  /g, " ");
		In.value = In.value.replace(/  /g, " ");
		In.value = In.value.replace(/  /g, " ");
		In.value = In.value.replace(/^[\t\r\n ]+/, "");
		In.value = In.value.replace(/[\t\r\n ]+$/, "");
		In.value = In.value.substr(0, In.qmaxtextsize);
		if (target) target.innerHTML = In.value.length;
		alert(ERTable[272] + "\n\n" + ERTable[273] + " " + In.qmaxtextsize);	// Too long!, Maximum number of characters allowed:
		In.focus();
		return false;
	}
	else
		return true;	
}


/////////////////////////////////////////////////////////////////////
// Ajax functions that...
// - - update the field db for a question on Blur
// - - check required fields
// - - update computed questions
// - - check high and low allowable values
//

var qplRequest;
var qplDataString;

function httpRequest(reqType, url, asynch)
{
	/* from "Ajax Hacks," Bruce W. Perry, O'Reilly 2006
	
		reqType: The HHTP request type, such as GET or POST
		url: The URL of the server program.
		asynch: Whether to send the request asynchronously or not: true|false */

	// Mozilla...	
	if (window.XMLHttpRequest)
	{
		qplRequest = new XMLHttpRequest();
	}
	else
	{
		if (window.ActiveXObject)
		{
			qplRequest = new ActiveXObject("Msxml2.XMLHTTP");
			if (! qplRequest)
			{
				qplRequest = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}
	}

	// the request could still be null if neither ActiveXObject initialization succeeded
	if(qplRequest)
	{
		initReq(reqType, url, asynch);
	}
	else
	{
		// alert("Your browser does not permit use of Ajax...");
	}
}

// Initialize a qplRequest that is already constructed

function initReq(reqType, url, bool)
{
	qplRequest.onreadystatechange = handlesendDataResponse;
	qplRequest.open(reqType, url, bool);
	qplRequest.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
	qplRequest.send(qplDataString);
}


function sendData(Name, Value)
{
	if (HomeLocation.match(/^http/))
	{
		var url = HomeLocation + "qpl_catch_ajax.php";

		qplDataString = "q_task=updateq" + 
				"&q_sess_id=" + document.QPL.q_sess_id.value +
				"&q_var_name=" + Name + 
				"&q_var_value=" + encodeURIComponent(Value) +
				"&q_language=" + document.QPL.q_language.value;
	
		httpRequest("POST", url, true);
	}
}

function handlesendDataResponse()
{
	if (qplRequest.readyState == 4)
	{
		if (qplRequest.status == 200)
		{
			/* retrieve the xml doc, we're expecting the following format
    	  	* <QPL>
      		*  <status></status>
      	 	*  <message></message>
      	 	* </QPL>
      	 	* 
      	 	* Where status contains either 0 (success) or number of problem.
      	 	* And message can contain anything from text, to html or more xml
      	 	*/
        
			var xmldoc = qplRequest.responseXML;
			var status = xmldoc.getElementsByTagName("status");
			var message = xmldoc.getElementsByTagName("message");

			//check the status
			if( status[0].firstChild.nodeValue == "0" )
			{
				document.QPL.q_ajax_ok_count.value = Number(document.QPL.q_ajax_ok_count.value) + 1;
			}
			else
			{
				document.QPL.q_ajax_err_count.value = Number(document.QPL.q_ajax_err_count.value) + 1;
			}
			document.QPL.q_ajax_last_status.value = status[0].firstChild.nodeValue;
			// alert(qplRequest.responseText);
		}
		else
		{
			document.QPL.q_ajax_err_count.value = Number(document.QPL.q_ajax_err_count.value) + 1;
			document.QPL.q_ajax_last_status.value = 99;
			//alert("Problems talking to the server...");
		}
	}
}

// Use this to update the RankList array and then run CheckRank() to 
// initialize the current page view.
function SetRank(GroupName)
{
	var Group = RankList.length;
	
	RankList[Group] = [];
	RankList[Group][0] = GroupName;
	
	for (var i = 1; i < arguments.length; i++)
	{
		RankList[Group][i] = arguments[i].toUpperCase();
	}

	// Initialize view of rank list...	
	CheckRank(RankList[Group][1]);

}

function CheckRank(Name)
{
	var InList = false;
	var i = 0;
	var j = 0;
	var Num;
	var NumWarning;
	var ErrorCount = 0;
	
	for (i = 0; i < RankList.length; i++)
	{
		for (j = 1; j < RankList[i].length; j++)
		{
			if (RankList[i][j] == Name)
			{
				InList = true;
				var Group = i;
				break;
			}
		}
	}

	if (InList)
	{
		var ErrorMessage = document.getElementById(RankList[Group][0]);
		if (ErrorMessage)
		{
			ErrorMessage.innerHTML = "";
		}
		
		var DupeList = [];
		
		for (j = 1; j < RankList[Group].length; j++)
		{
			Num = document.getElementById(RankList[Group][j]);
			NumWarning = document.getElementById("RANK_" + RankList[Group][j]);
			
			if (DupeList[parseInt(Num.value)] == null)
				DupeList[parseInt(Num.value)] = 1;
			else
				DupeList[parseInt(Num.value)]++;
				
			Num.style.color = "black";
			Num.style.fontWeight = "normal";
			NumWarning.innerHTML = "";
			CheckRequired(Num);
			
			if ( !isNaN(parseInt(Num.value)) )
			{
				if (parseInt(Num.value) < 1 || parseInt(Num.value) > RankList[Group].length - 1)
				{
					Num.style.color = RankErrorFontColor;
					Num.style.fontWeight = "bold";
					NumWarning.innerHTML = ERTable[276]; // "Value out of range!";
					ErrorCount++;
				}
			}
		}

		for (i = 0; i < DupeList.length; i++)
		{
			if (!(DupeList[i] === undefined))
			{
				if (DupeList[i] > 1)
				{
					for (j = 1; j < RankList[Group].length; j++)
					{
						Num = document.getElementById(RankList[Group][j]);
						NumWarning = document.getElementById("RANK_" + RankList[Group][j]);
						
						if (parseInt(Num.value) == i)
						{
							Num.style.color = RankErrorFontColor;
							Num.style.fontWeight = "bold";
							NumWarning.innerHTML = ERTable[277]; // "Duplicate value!";
							ErrorCount++;
						}
					}
				}
			}
		}
		
		if (ErrorCount && ErrorMessage)
		{
			ErrorMessage.innerHTML = ERTable[278];		// Please correct ranking error.
		}
	}
	return;
}
				

// Use this to update the SumList array and then run CheckSum() to 
// initialize the current page view.
function SetSum(GroupName)
{
	var Group = SumList.length;
	
	SumList[Group] = [];
	SumList[Group][0] = GroupName;
	
	for (var i = 1; i < arguments.length; i++)
	{
		SumList[Group][i] = arguments[i].toUpperCase();
	}
	
	// Initialize view of rank list...	
	CheckSum(SumList[Group][1]);

}


function CheckSum(Name)
{
	var InList = false;
	var i = 0;
	var j = 0;
	var Num;
	var Total = parseFloat(0);
	var ItemCount = 0;
	
	for (i = 0; i < SumList.length; i++)
	{
		for (j = 1; j < SumList[i].length; j++)
		{
			if (SumList[i][j] == Name)
			{
				InList = true;
				var Group = i;
				break;
			}
		}
	}

	if (InList)
	{
		var ErrorMessage = document.getElementById(SumList[Group][0]);
		if (ErrorMessage)
		{
			ErrorMessage.innerHTML = "";
		}
		
		for (j = 1; j < SumList[Group].length; j++)
		{
			Num = document.getElementById(SumList[Group][j]);
			
			if ( !isNaN(parseFloat(Num.value)) )
			{
				Total += parseFloat(Num.value);
				ItemCount++;				
			}
		}

		if (ItemCount && ErrorMessage)
		{
			var First = document.getElementById(SumList[Group][1]);
			
			if (First.qtype == "NUMBERF")
				ErrorMessage.innerHTML = Total.toFixed(First.maxLength - First.qleft - 1);
			else
				ErrorMessage.innerHTML = Total.toFixed(0);
		}
	}
	return;
}


function CheckRequired(Elem)
{
	
	switch (Elem.type)
	{
		case "checkbox":
		case "radio":
			var CheckCount = 0;
			var Required = 0;
			
			var CheckName = document.getElementsByName(Elem.name);
			
			if(CheckName[0].qrequired)
			{
				for (var i = 0; i < CheckName.length; i++)
				{
					if (CheckName[i].checked)
						CheckCount++;
				}
	
				for (var i = 0; i < CheckName.length; i++)
				{
					if (CheckCount == 0)
					{
						CheckName[i].parentNode.style.backgroundColor = RequiredFieldBackgroundErrorColor;
					}						
					else
					{
						CheckName[i].parentNode.style.backgroundColor = CheckName[i].qOldBackgroundColor;						
					}
				}
			}
		
			break;
		
		case "select-one":
			if (Elem.qrequired && (Elem.value.length == 0 || parseInt(Elem.value) == 0 ) )
			{	
				Elem.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				
				var QSum = document.getElementById("SELECT_" + Elem.name);
				if (QSum)
				{
					QSum.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				}				
			} 
			else
			{
				Elem.style.backgroundColor = "white";
			}
			break;
		
		
		case "hidden":
			if (Elem.qrequired && ( (Elem.qtype == 'UPLOAD' && Elem.value.length == 0) || (Elem.qtype == 'QUESTIONNAIRE' && parseInt(Elem.value) == 0 )) )
			{	
				var QSum = document.getElementById("QSUM_" + Elem.name);
				if (QSum)
				{
					QSum.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				}
				else
				{
					Elem.parentNode.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				}				
			} 
			break;
	
		case 'textarea':
			if (Elem.qrequired && Elem.value.length == 0 )
			{	
				Elem.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				
				var QSum = document.getElementById("QSUM_" + Elem.name);
				if (QSum)
				{
					if(QSum.innerHTML == '&nbsp;' || QSum.innerHTML.length == 0)
						QSum.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				}				
			} 
			else
			{
				Elem.style.backgroundColor = "white";
			}
			break;
			
						
		default:
			if (Elem.qrequired && Elem.value.length == 0 )
			{	
				Elem.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				
				var QSum = document.getElementById("QSUM_" + Elem.name);
				if (QSum)
				{
					QSum.style.backgroundColor=RequiredFieldBackgroundErrorColor;
				}				
			} 
			else
			{
				Elem.style.backgroundColor = "white";
			}
			break;
	}
	return;
}

function SetRequired()
{
		for (var q=Startq; q <= Endq; q++)
		{
			var e = xQues[q];
			var Elem = document.QPL.elements[e];
			
			if (Elem.qrequired)
			{
				switch (Elem.type)
				{
					case "checkbox":
					case "radio":
						var CheckCount = 0;
						var Required = 0;
						
						var CheckName = document.getElementsByName(Elem.name);
						
						for (var i = 0; i < CheckName.length; i++)
						{
							if(typeof window.getComputedStyle == 'function') 
							{
								CheckName[i].qOldBackgroundColor = window.getComputedStyle(CheckName[i].parentNode, null).getPropertyValue("background-color");
							}
							else	// this is IE8 or older... just set to default backgound color...
							
							{
								CheckName[i].qOldBackgroundColor = RequiredDefaultBackgroundColor;
							}
						}
					
						break;
					
									
					default:
						// Elem.qOldBackgroundColor = window.getComputedStyle(Elem, null).getPropertyValue("background-color");
						Elem.qOldBackgroundColor = RequiredDefaultFieldBackgroundColor;		// INPUT field default background should always be white!
						break;
				}							
				CheckRequired(Elem);
			}
		}
		return;
}