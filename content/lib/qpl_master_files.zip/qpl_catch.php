<?php
// qpl_catch.php
// K. Dooley
//
// General purpose program to receive data from a QPL form and put it into its database.
//

// Set the QPL_DEBUG constrant to 'true' to display questionnaire form POST results and SQL statement.
define ("QPL_DEBUG", false);

$header = "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
<HTML>
<HEAD>
<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=iso-8859-1\">
<TITLE>QPL Catch</TITLE>
<LINK REL=stylesheet TYPE='text/css' HREF='qpl_style.css'>
</HEAD>
<BODY>
<H1>QPL Catch</H1>
\n";
if (QPL_DEBUG) echo $header;

include_once 'qpl_config.inc';

$q_language = "";
if (isset($_POST['q_language']))
{
	if (preg_match('/^\.[a-z]{2}(-[A-Za-z]+)?(-[A-Za-z]+)?$/', $_POST['q_language']))
	{
		$q_language = $_POST['q_language'];
	}
	elseif (mb_strlen($_POST['q_language']) > 0)
	{
		$q_comment .= "<BR>A system error has occured.";
		include(QPL_ERROR_FORM);
		exit;
	}
}
include_once QPL_JOB . $q_language;
include_once QPL_DB_FUNCS;

qpl_db_connect($q_job)
	or qpl_db_log($qpl_error_message);

$info = qpl_db_get_info()
	or qpl_db_log($qpl_error_message);

$q_url = isset($info['q_url']) ? $info['q_url'] : ($_SERVER['SERVER_PORT'] == 80 ? 'http://' : 'https://') . $_SERVER['SERVER_NAME'] . rtrim(dirname($_SERVER['PHP_SELF']), '/\\') . '/' ;
 
isset($_POST['q_sess_id']) 
	or qpl_db_log("Session information missing.");

if (($session = qpl_db_get_sess($_POST["q_sess_id"])) <= 0)  // kill this session (will make a new one if needed for next section)
	qpl_db_log($qpl_error_message);

$q_uname = qpl_addslashes($session['q_uname']);
$q_javascript = $session['q_javascript'];
$q_id = $session['q_id'];

// Don't check screen sizes after login from qpl_login_form.inc page so log entries will always be zero after login
$q_width = 0;
$q_height = 0;
$q_colorDepth = 0;
$q_pixelDepth = 0;
$q_availWidth = 0;
$q_availHeight = 0;

isset($_POST['q_atq']) 
	or qpl_db_log("Question information missing.");
	
if (!preg_match("/^[0-9]+$/", $_POST['q_atq']))
{
	qpl_set_error("Invalid question information."); 
}

$q_atq = $_POST['q_atq'];

isset($_POST['q_atsec']) 
	or qpl_db_log("Page information missing.");
	
if (!preg_match("/^[0-9]+$/", $_POST['q_atsec']))
{
	qpl_db_log("Invalid page information."); 
}
	
$q_atsec = $_POST['q_atsec'];

$user = qpl_db_get_user($q_uname)
	or qpl_db_log($qpl_error_message);

$q_group = $user['q_group'];
$q_user_status = $user['q_user_status'];

if (QPL_DEBUG) {
	echo "<pre>";
	echo "\$_FILES Count: " . count($_FILES) . "\n\n";
	foreach ($_FILES as $key => $val) { echo "$key = $val\n"; }	
	echo "\n\$_FILES[]\n";
	print_r($_FILES);
	echo "\n\n\$_POST[]\n";
	print_r($_POST);
	echo "</pre>\n";
}

if ($_POST['q_status'] == FRM_CANCEL)
{
	$sql = "UPDATE data SET q_available=" . DATA_AVAILABLE . " WHERE q_id=" . $q_id;
	$result = qpl_db_query($sql)
		or qpl_db_log($qpl_error_message . "<BR><BR>Query: " . $sql);
	qpl_db_log("Record update cancelled", LOGIN_OK);
	
	
	if( $user['q_from_q_id'] > 0 )
	{
		//we've come from another survey.  create a valid session here and move back to the previous survey
		
		$q_sess_id = qpl_db_put_sess(SESS_JUMP, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], 0, $q_atq, $q_atsec)
			or qpl_db_log($qpl_error_message);

		//using the url and GET variables go to the survey
			
		$q_from_db = $q_job;					// d
		$q_from_url = $q_url;				// l
		$q_from_sess_id = $q_sess_id;		// s
		
		$q_to_url = $user['q_from_url'];		// to_url
		$q_to_q_id = $user['q_from_q_id'];	// i
 		$q_to_db = $user['q_from_db'];	// don't need to put put target db in GET args - the local site will pull it from qpl_projects.inc
 		
		$sql = "UPDATE user SET q_from_q_id=0, q_from_url=NULL, q_from_db=NULL, q_from_q_varname=NULL WHERE q_uname='$q_uname'";
		$result = qpl_db_query($sql)
			or qpl_db_log($qpl_error_message);
		
		qpl_db_log("Returning to: url=$q_to_url, db=$q_to_db, id=$q_to_q_id", LOGIN_OK);		
		
		if (!QPL_DEBUG) echo "<script type=\"text/javascript\">\n";
		echo "window.top.location=\"$q_to_url" . "qpl_login.php?d=$q_from_db&l=$q_from_url&s=$q_from_sess_id&i=$q_to_q_id\";\n"; 	
		if (!QPL_DEBUG) echo "</script>\n<P>Please wait...</P>\n";
		exit;
	}
	else
	{	
		$comment = $ERTable[387];

		if ($info['q_entry_type'] == EDIT_MULT)
		{
			$list = qpl_db_lookup_mult_rec($q_uname, $q_group, $info, $q_user_status);
			if ( !$list )
				qpl_db_log($qpl_error_message);

			if (qpl_db_num_rows($list) > 1 || $info['q_create_type'] == CREATE_MULT)
			{
				qpl_db_log("Select from multiple cases", LOGIN_OK);
				$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_SELECT, $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
					or qpl_db_log($qpl_error_message);
				$comment .= "<BR><BR>" . $ERTable[388];
				include (QPL_SELECT_FORM);  // uses: comment, q_uname (read-only), q_sess_id, list
				exit;
			}
			else
			{
				if (!QPL_DEBUG)
				{
					qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged out");
					include(QPL_DONE_FORM);
					exit;
				}
			}
		}
		else
		{
			if (!QPL_DEBUG)
			{
				qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged out");
				include(QPL_DONE_FORM);
				exit;
			}
		}
	}
}

$result =  qpl_db_validate_select_rec($q_uname, $q_group, $q_id, $old_q_atq, $old_q_atsec, $q_user_status);
if ($result <= 0 || $result == 2)	// data base error or case not found or being edited by another user
	qpl_db_log($qpl_error_message);

// check for uploaded files...

$up_error_msg = array (
	0 => 'There is no error, the file uploaded with success.',
	1 => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
	2 => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.',
	3 => 'The uploaded file was only partially uploaded.',
	4 => 'No file was uploaded.',
	5 => 'Not defined.',
	6 => 'Missing a temporary folder.',
	7 => 'Failed to write file to disk.',
	8 => 'File upload stopped by extension.' );

$up_error_count = 0;


if (count($_FILES))
{
	$qpl_q_up_file_max_size = $info['q_up_file_max_size'] * 1000;	// when job.sql is run, this number will be reduced to the MySQL max_allowed_packet size if needed, otherwise is same as HTML hidden field MAX_FILE_SIZE
	$php_upload_max_filesize = ConvertToBytes(ini_get('upload_max_filesize'));
	$php_post_max_size = ConvertToBytes(ini_get('post_max_size'));
	$apache_content_length = ConvertToBytes($_SERVER['CONTENT_LENGTH']);

	foreach ($_FILES as $key => $val) 
	{
		$this_file_name = qpl_addslashes($_FILES[$key]['name']);
		$this_file_size = $_FILES[$key]['size'];

		if (QPL_DEBUG)
		{ 
			echo "<P>Question: $key<BR>
				This file name: $this_file_name<BR>
				This file size: $this_file_size<BR>
				Uploaded: " . (is_uploaded_file($_FILES[$key]['tmp_name']) ? "Yes" : "No" ) . "<BR>
				Readable: " . (is_readable($_FILES[$key]['tmp_name']) ? "Yes" : "No" ) . "<BR>
				QPL/MySQL q_up_file_max_size: $qpl_q_up_file_max_size (MySQL max_allowed_packet limits size set in QPL program.)<BR>
				PHP upload_max_filesize: $php_upload_max_filesize<BR>
				PHP post_max_size: $php_post_max_size<BR>
				Apache content_length: $apache_content_length</P>";
		}

		if ($this_file_size > $qpl_q_up_file_max_size)
		{
			$_FILES[$key]['error'] = UPLOAD_ERR_FORM_SIZE;
			$up_error_msg[UPLOAD_ERR_FORM_SIZE] = "Upload error for $key on file '$this_file_name': Uploaded file size ($this_file_size) exceeds MySQL max_allowed_packet size ($qpl_q_up_file_max_size)";
		}
		
		if ($this_file_size > $php_upload_max_filesize)
		{
			$_FILES[$key]['error'] = UPLOAD_ERR_FORM_SIZE;
			$up_error_msg[UPLOAD_ERR_FORM_SIZE] = "Upload error for $key on file '$this_file_name': Uploaded file size ($this_file_size) exceeds PHP upload_max_filesize ($qpl_q_up_file_max_size)";
		}
		
		if ($_FILES[$key]['error'] == UPLOAD_ERR_OK && is_uploaded_file($_FILES[$key]['tmp_name']) )
		{
 
			if (QPL_OS == QPL_LINUX)
				chmod($_FILES[$key]['tmp_name'], 0644);	// user: read/write, group and other: read
			
			$f_new_name = $info['q_project'] . '-' . $q_uname . '-'. $q_id . '-' . $key . '-' . date('Y-m-d-H-i-s') . mb_strrchr($this_file_name, '.');
			
			$sql = "INSERT INTO fdata SET
				q_id = $q_id,
				q_uname = '$q_uname',
				q_group = '$q_group',
				q_varname = '$key',
				f_name = '$this_file_name',
				f_new_name = '$f_new_name',
				f_type = '" . $_FILES[$key]['type'] . "',
				f_tmp_name = '" . $_FILES[$key]['tmp_name'] . "',
				f_size = '" . $_FILES[$key]['size'] . "',
				f_error =  '" . $_FILES[$key]['error'] . "',";
				
			if ($info['q_up_file_to_db'] == '1')
			{
				$sql .= "q_up_file_to_db = '1',
				f_file = LOAD_FILE('" . $_FILES[$key]['tmp_name'] . "')";
			}
			else
			{
				$sql .= "q_up_file_to_db = '0'";
				
				if (move_uploaded_file($_FILES[$key]['tmp_name'], UPLOADED_FILE_PATH . $f_new_name))
				{
					qpl_db_log("Copied $key uploaded file $this_file_name ($this_file_size bytes) to " . UPLOADED_FILE_PATH . $f_new_name, LOGIN_OK);
					if (QPL_OS == QPL_LINUX)
						chmod(UPLOADED_FILE_PATH . $f_new_name, 0664);	// user & group: read/write, other: read
				}
				else
					qpl_db_log("Could not copy $key uploaded file $this_file_name ($this_file_size bytes) to " . UPLOADED_FILE_PATH . $f_new_name, LOGIN_OK);
			}

			$result = qpl_db_query($sql);
			if ($result)
			{
				if ($info['q_up_file_to_db'] == '1')
					qpl_db_log("Copied $key uploaded file $this_file_name ($this_file_size bytes) to fdata table.", LOGIN_OK);		
			
				$sql = "UPDATE data SET $key=CONCAT('$this_file_name ($this_file_size bytes, ', NOW(), ')') WHERE q_id=$q_id";
				$result = qpl_db_query($sql)
					or qpl_db_log($qpl_error_message);
			}
			else	
				qpl_db_log($qpl_error_message);
			
		}
		else if ($_FILES[$key]['error'] != UPLOAD_ERR_NO_FILE)
		{
			$up_error_count++;
			// Note: the '*' in the first column of the answer field is used as a flag later that an error occured!
			$sql = "UPDATE data SET $key='*** Error uploading: $this_file_name (" . ($_FILES[$key]['error'] <= 2 ? '>' . $info['q_up_file_max_size'] . 'Kb' : $_FILES[$key]['error']) . ")' WHERE q_id=$q_id";
			$result = qpl_db_query($sql)
				or qpl_db_log($qpl_error_message);		
	
			$sql = "INSERT INTO fdata SET
				q_id = $q_id,
				q_uname = '$q_uname',
				q_group = '$q_group',
				q_varname = '$key',
				f_name = '$this_file_name',
				f_type = '" . $_FILES[$key]['type'] . "',
				f_tmp_name = '" . $_FILES[$key]['tmp_name'] . "',
				f_size = '$this_file_size',
				f_error =  '" . $_FILES[$key]['error'] . "'";
				
			$result = qpl_db_query($sql)
				or qpl_db_log($qpl_error_message);
		
			qpl_db_log("Upload error for $key on file '$this_file_name': " . $up_error_msg[$_FILES[$key]['error']], LOGIN_OK);
		}
	}
}
// Stay on the current page if had upload errors... reset to last question and page numbers... probably will need to reset jump to other questionnaire if needed...
if ($up_error_count)
{
	$q_atq = $session['q_atq'];
	$q_atsec = $session['q_atsec'];
} 

$chk_count = 0;
$vars = array();
$v_index = 0;

$sql = "UPDATE data SET ";

$sql .= "q_available=?,";
$vars[$v_index++] = ($_POST['q_status'] == FRM_DONE ? DATA_AVAILABLE : DATA_BEING_EDITED);

$sql .= "q_javascript=?,";
$vars[$v_index++] = $q_javascript;

$sql .= "q_remote_addr=?,";
$vars[$v_index++] = getenv('REMOTE_ADDR');

$sql .= "q_http_user_agent=?,";
$vars[$v_index++] = getenv('HTTP_USER_AGENT');

$sql .= "q_from=?,";
$vars[$v_index++] = getenv('FROM');

$sql .= "q_atq=?,";
$vars[$v_index++] = $q_atq;

$sql .= "q_atsec=?,";
$vars[$v_index++] = $q_atsec;

$sql .= "q_ajax_ok_count=?,";
$vars[$v_index++] = (isset($_POST['q_ajax_ok_count']) && is_numeric($_POST['q_ajax_ok_count']) ? $_POST['q_ajax_ok_count'] : 0);

$sql .= "q_ajax_err_count=?,";
$vars[$v_index++] = (isset($_POST['q_ajax_err_count']) && is_numeric($_POST['q_ajax_err_count']) ? $_POST['q_ajax_err_count'] : 0);

$sql .= "q_ajax_last_status=?,";
$vars[$v_index++] = (isset($_POST['q_ajax_last_status']) && is_numeric($_POST['q_ajax_last_status']) ? $_POST['q_ajax_last_status'] : 0);

$sql .= "q_language=?";
$vars[$v_index++] = $q_language;

if (QPL_DEBUG) echo "<p>Rolling Through POST Table</P><TABLE>\n<TR><TH>Question</TH><TH>Value</TH></TR>\n";

reset($_POST);
while (list($key, $val) = each($_POST))
{
	//if( in_array($key,$struct_array) )		// only keep if question name is in the struct.q_varname list
	//{
		if (QPL_DEBUG) echo "<TR><td>$key</TD><TD>$val</TD></TR>\n";
		
		if (preg_match("~^q_~", $key))		// skip system variables -- explictly inserted above...
			continue;
		
		if (preg_match("~^v_~", $key))		// skip VOID variables
			continue;

		if (preg_match("~^MAX_FILE_SIZE~", $key))		// skip PHP file upload max number
			continue;
			
		if (preg_match("~^chk_~", $key))		// use a hidden input field to indicate total number of checkboxes in group
		{
			$chk_count = $val;
			$chk_name = mb_substr($key, 4);
			
			if (qpl_valid_q_name($chk_name))
			{
				for ($i = 0; $i < $chk_count ; $i++)	// default all boxes to zeros 
				{
					$chk[$i] = "0";
					$sql .= ", " . $chk_name . "_" . ($i+1) . "=?";
				}
				
				if (!isset($_POST[$chk_name])) // no checkboxes checked, updated with all zeros
				{
					for ($i = 0; $i < $chk_count ; $i++)	// default all boxes to zeros 
					{
						$vars[$v_index++] = 0;
					}
				}
				else
				{
					while (list($key2, $val2) = each($_POST[$chk_name]))   // only checked boxes are sent
					{
						if (QPL_DEBUG) echo "<TR><TH>In: $chk_name $key2</Th><TD>$val2</TD></TR>\n";
						if ($val2 == "NULL") 
							$chk[$val2 - 1] = null;
						else
							$chk[$val2 - 1] = "1";			  // now have completely updated set of boxes!
					}
	
					for ($i = 0; $i < $chk_count; $i++) 
					{
						if (QPL_DEBUG) echo "<TR><TH>Out: $chk_name $i</Th><TD>$chk[$i]</TD></TR>\n";
						$vars[$v_index++] = $chk[$i];
					}
				}
			}
			$chk_count = 0;
			unset($chk_name);
			unset($chk);
			continue;
		}

		if (!is_array($_POST[$key]) && qpl_valid_q_name($key) ) {	// add non-check boxes to the query 
			if ($val == "NULL")
			{
				$sql .= ", " . $key . "=?";
				$vars[$v_index++] = null;
			}
			else 
			{
				$sql .= ", " . $key . "=?";
				
				if (get_magic_quotes_gpc() )
					$vars[$v_index++] = stripslashes(trim($val)) ;
				else
					$vars[$v_index++] = trim($val);
			}
		}
}
if (QPL_DEBUG) echo "</TABLE>\n";

$sql .= " WHERE q_id=$q_id";
if (QPL_DEBUG) 
{
	echo "<P>$sql</P>\n";
	echo "<PRE>\n";
	print_r($vars);
	echo "</PRE>\n";
}

/* Create a prepared Statement */
$stmt = qpl_db_prepare($sql, $vars);

if (QPL_DEBUG) echo "</BODY>\n</HTML>";

$result = qpl_db_query($stmt)
	or qpl_db_log($qpl_error_message);
	
qpl_db_log("Record updated", LOGIN_OK);

/////////////////////////////////////////////////////////////////////////////////////
// Record has been updated. Now figure out what to do next!
/////////////////////////////////////////////////////////////////////////////////////

// Check that system is enabled (setting from qpl_config.inc)
if ($DisableSystem)
{
	qpl_db_log($DisableSystemComment);
}

if ($_POST['q_status'] == FRM_DONE && $up_error_count == 0)
{
	if( $user['q_from_q_id'] > 0 )
	{
		//We've come from another survey.  Create a valid session for this current survey before moving on for target survey to check on log in 
		$q_sess_id = qpl_db_put_sess(SESS_JUMP, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], 0, $q_atq, $q_atsec)
			or qpl_db_log($qpl_error_message);

		//using the url and GET variables go to the survey
		$q_from_db = $q_job;					// d
		$q_from_url = $q_url;				// l
		$q_from_sess_id = $q_sess_id;		// s
		
		$q_to_url = $user['q_from_url'];		// to_url
		$q_to_q_id = $user['q_from_q_id'];	// i
 		$q_to_db = $user['q_from_db'];	// don't need to put put target db in GET args - the local site will pull it from qpl_projects.inc
 		$q_from_q_varname = $user['q_from_q_varname'];

		$sql = "UPDATE user SET q_from_q_id=0, q_from_url=NULL, q_from_db=NULL, q_from_q_varname=NULL WHERE q_uname='$q_uname'";
		$result = qpl_db_query($sql)
			or qpl_db_log($qpl_error_message);

		qpl_db_log("Returning to: url=$q_to_url, db=$q_to_db, id=$q_to_q_id", LOGIN_OK);		
		
		if (!QPL_DEBUG) echo "<script type=\"text/javascript\">\n";
		echo "window.top.location=\"$q_to_url" . "qpl_login.php?d=$q_from_db&l=$q_from_url&s=$q_from_sess_id&i=$q_to_q_id&o=$q_id&v=$q_from_q_varname\";\n"; 	
		if (!QPL_DEBUG) echo "</script>\n<P>Please wait...</P>\n";
		exit;
	}
	else
	{
		$comment = $ERTable[389];
		if ($info['q_entry_type'] == EDIT_MULT || $q_user_status == USER_SUPER)
		{
			$list = qpl_db_lookup_mult_rec($q_uname, $q_group, $info, $q_user_status);
			if ( !$list )
				qpl_db_log($qpl_error_message);
			
			if (qpl_db_num_rows($list) > 1 || $info['q_select_case_required'] || $info['q_create_type'] == CREATE_MULT)
			{
				qpl_db_log("Select from multiple cases", LOGIN_OK);
				$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_SELECT, $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
					or qpl_db_log($qpl_error_message);
				$comment .= "<BR><BR>" . $ERTable[388];
				include (QPL_SELECT_FORM);  // uses: comment, q_uname (read-only), q_sess_id, list
				exit;
			}
			else
			{
				if (!QPL_DEBUG)
				{
					qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged out");
					include(QPL_DONE_FORM);
					exit;
				}
			}
		}
		else
		{
			if (!QPL_DEBUG)
			{
				qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged out");
				include(QPL_DONE_FORM);
				exit;
			}
		}
	}
}
elseif($_POST['q_status'] == FRM_TO_SURVEY && $up_error_count == 0)
{
			
	//using the url and GET variables go to the target survey
	$q_from_q_varname = $_POST['q_from_q_varname']; 	// v
	$q_from_db = $q_job;					// d
	$q_from_url = $q_url;				// l

	if (array_key_exists($q_from_q_varname, $q_jump_to_db ))
	{
		$q_to_db = $q_jump_to_db[$q_from_q_varname];
		$q_to_url = $q_jump_to_url[$q_from_q_varname];
	}
	else
		qpl_db_log("Unable to go to sub-questionnaire.");

	if (mb_substr($q_to_url, 0, 4) != "http")
	{
		$q_to_url = ($_SERVER["SERVER_PORT"] == 80 ? "http://" : "https://") . $_SERVER["SERVER_NAME"] . "/" . $q_to_url . (mb_substr($q_to_url, -1, 1) == "/" ? "" : "/");
 	}

	$q_to_q_id = $_POST['q_to_q_id'];	// i

	$err = "";
	
	if (qpl_db_validate_target_case_before_jump($q_to_db, $q_uname, $q_to_q_id, $err))
	{
		//create a valid session for this current survey before moving on for target survey to check on log in 
		$q_from_sess_id = qpl_db_put_sess(SESS_JUMP, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
			or qpl_db_log($qpl_error_message);
		
		qpl_db_log("Jumping to: url=$q_to_url, db=$q_to_db, id=$q_to_q_id", LOGIN_OK);		

		if (!QPL_DEBUG) echo "<script type=\"text/javascript\">\n";
			echo "window.top.location=\"$q_to_url" . "qpl_login.php?v=$q_from_q_varname&d=$q_from_db&l=$q_from_url&s=$q_from_sess_id&i=$q_to_q_id&o=$q_id&\";\n"; 	
		if (!QPL_DEBUG) echo "</script>\n<P>Please wait...</P>\n";
		exit;
	}
	else // some problem occurred so cannot go there... relaunch same section...
	{
		$q_atq = $session['q_atq'];
		$q_atsec = $session['q_atsec'];
		qpl_db_log("Jumping problem: $err", LOGIN_OK);		
	}		
}

qpl_db_log("Launch section " . $q_atsec, LOGIN_OK, DATA_BEING_EDITED);	
$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
	or qpl_db_log($qpl_error_message);
include $q_questionnaire;

?>
