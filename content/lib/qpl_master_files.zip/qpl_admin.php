<?php
// qpl_admin.php
// K. Dooley
//
// Central point for all project administration activities. 
//

include_once 'qpl_config.inc';

/*create local variables out of the POST array*/	
$keys = array_keys($_POST);
foreach($keys as $key) {
	${$key} = $_POST[$key];
}

$q_language = "";
if (isset($_POST['q_language']))
{
	if (preg_match('/^\.[a-z]{2}(-[A-Za-z]+)?(-[A-Za-z]+)?$/', $_POST['q_language']))
	{
		$q_language = $_POST['q_language'];
	}
	elseif (mb_strlen($_POST['q_language']) > 0)
	{
		$q_comment .= "<BR>A system error has occured.";
		include(QPL_ERROR_FORM);
		exit;
	}
}
include_once QPL_JOB . $q_language;
include_once QPL_DB_FUNCS;
include_once QPL_ADMIN_FUNCS;


isset($_POST["q_sess_id"]) or
	qpl_db_log("Cannot identify your session.  Please launch questionnaire from the project home page.");


if (!isset($info))
{
	qpl_db_connect($q_job)
		or qpl_db_log($qpl_error_message);
}
// qpl_db_log("To Main Page: $q_language", LOGIN_OK);

$info = qpl_db_get_info(false)	// don't check http_referer
	or qpl_db_log($qpl_error_message);

if (!isset($q_action))
	$q_action = 0;
	
$q_delete=SESS_DELETE;
if ($q_form == FORM_EXPORT_FIXED_DATA || 
	$q_form == FORM_CA_EXPORT  || 
	$q_form == FORM_EXPORT_TAB_DATA ||
	$q_form == FORM_CA_EXPORT_ASKSAM ||
	$q_form == FORM_ADMIN_USER_VIEW_UPLOADS)
	$q_delete=SESS_KEEP;

if (($session = qpl_db_get_sess($q_sess_id, $q_delete)) <= 0)
{
	if (QPL_OS == "WinNT")
		qpl_delete($info['q_project'] . EXPORT_EXT);
	else
	{
		qpl_delete(DATA_PATH . $info['q_project'] . ".dat");
		qpl_delete(DATA_PATH . $info['q_project'] . ".prn");
		qpl_delete(DATA_PATH . $info['q_project'] . "_ca.prn");
		qpl_delete(DATA_PATH . $info['q_project'] . ".txt");
	}
	qpl_db_log($qpl_error_message);
}

$q_uname = qpl_addslashes($session['q_uname']);
$q_javascript = $session['q_javascript'];

if ($q_delete==SESS_DELETE)
	$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_ADMIN, $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
		or qpl_db_log($qpl_error_message);

$user = qpl_db_get_user($q_uname)
	or qpl_db_log($qpl_error_message);


if ($user['q_user_status'] < USER_MANAGER)
	qpl_db_log("Invalid access.");
	

// check incoming form type
if (!isset($q_form))
{
	if (isset($info['q_http_referer']))
	{
		header("Location: " . $info['q_http_referer']);	// launch correct starting page
		exit;
	}
	else 
		qpl_db_log("Cannot identify your project. Please launch questionnaire from the project home page.");
}
if (!isset($q_submit))
	$q_submit = "";

$Start = microtime(true);

// process each form
switch ($q_form)
{
	case FORM_ADMIN_MAIN:
		if ($q_action == 0)	// launching form from qpl_login
		{
			$comment = "Use this page to view and update project settings.";
		}
		else
		{
			if ($q_submit == FRM_CANCEL)
			{
				// close session
				if (($session = qpl_db_get_sess($q_sess_id)) <= 0)
					qpl_db_log($qpl_error_message);
				$q_uname = $session['q_uname'];
				$q_javascript = $session['q_javascript'];

				if (QPL_OS == "WinNT")
					qpl_delete($info['q_project'] . EXPORT_EXT);
				else
				{
					qpl_delete(DATA_PATH . $info['q_project'] . ".dat");
					qpl_delete(DATA_PATH . $info['q_project'] . ".prn");
					qpl_delete(DATA_PATH . $info['q_project'] . "_ca.prn");
					qpl_delete(DATA_PATH . $info['q_project'] . ".txt");
				}
				qpl_db_log("Administrator: Logging out", LOGIN_OK);
				qpl_db_syslog($info['q_project'], $q_uname, "Administrator logged out.");
				include(QPL_RESET_PAGE);
				exit;
			}
	
			// else process action request
			
			qpl_db_log("Administrator: $q_action_name", LOGIN_OK);
			
			switch($q_action)
			{
				case 1:		// default project settings
					if ($list = qpl_db_get_varnames())
						$comment = "Use this form to change project-level settings.";
					else
						$comment = $qpl_error_message;
						
					$version = qpl_db_get_mysql_info();
					$char = qpl_db_get_mysql_char_info($info['q_project']);
					
					include (QPL_ADMIN_FORM);  
					exit;
					break;
				
				case 2:  // edit user list
					$find = qpl_find_user_query($q_uname);
					
					if (!$find)
					{
						$sql = "INSERT INTO find SET q_uname='$q_uname'";
						qpl_db_query($sql) or
							qpl_db_log($qpl_error_message);
						$find = qpl_find_user_query($q_uname) or
							qpl_db_log($qpl_error_message);
					}
					$comment = "Enter user account search criteria.";
					include (QPL_ADMIN_USER_FIND_FORM);
					exit;
					break;
	
				case 3: // response list
					$list = qpl_db_list_case_count();
					if ($list)
					{
						$comment = "";
						include (QPL_ADMIN_RESPONSE_FORM);
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;
	
				case 4: // active session list
					$list = qpl_db_list_sessions();
					if ($list)
					{
						$comment = "End times in bold indicate expired sessions.";
						include (QPL_ADMIN_SESSION_FORM);
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;
	
				case 5: // history log
					$list = qpl_db_list_history_log("");
					if ($list)
					{
						$comment = "List includes the last 100 log entries.";
						$q_form = FORM_ADMIN_LOG;
						include (QPL_ADMIN_LOG_FORM);
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;

				// case 16: // dropped Custom Log Report since now have new custom reports
	
				case 6:		// optimize tables
					qpl_db_optimize()
						or qpl_db_log($qpl_error_message);
						
					$comment = "Project tables have been optimized.";
					break;
	
				case 7:		// purge expired session
					if (($rows = qpl_db_purge_expired_sessions()) < 0)
						qpl_db_log($qpl_error_message);
						
					$comment = $rows . " Expired sessions have been purged.";
					break;

				case 8:		// purge activity log
					if ($info['q_log_file'] == LOG_OFF)
					{
						if (($rows = qpl_db_purge_log_entries()) < 0)
							qpl_db_log($qpl_error_message);
							
						$comment = "Log entries have been purged.";
					}
					else
						$comment = "The log file must be turned off before it may be purged. (See &quot;Set project defaults.&quot;)";

					break;
				
					
				case 9:		// purge export data files
					if (QPL_OS == "WinNT")
						qpl_delete($info['q_project'] . EXPORT_EXT);
					else
					{
						qpl_delete(DATA_PATH . $info['q_project'] . ".dat");
						qpl_delete(DATA_PATH . $info['q_project'] . ".prn");
						qpl_delete(DATA_PATH . $info['q_project'] . ".txt");
					}
					$comment = "Export data files have been purged.";
					break;

				case 10:	// export fixed format data file
					$comment = "Select fixed format export option.";
					include (QPL_EXPORT_FIXED_DATA_FORM);  
					exit;
					break;

					
				case 11:	// export tab file
					$sql = "SELECT q_varname, q_qtype FROM struct WHERE q_qtype!='VOID' ORDER BY q_inputnum;";	
					if ($list = qpl_db_query($sql))
					{
						$comment = "Select system variables and questions for tab-delimited file.";
						include (QPL_EXPORT_TAB_DATA_FORM);  
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;

					
				case 13:	// questionnaire summary statistics using generated job.inc file - use raw data
				case 32:	// use Clean data
				case 33:	// use Dirty data
				
					if ($q_action == 32)
					{
						$q_where = str_replace("data.", "cdata.", $info['q_where']);
						$q_action = "cdata";
						$comment = "Using clean data set.<BR>Data cleaned at: " . $info['q_cdata_created'] . "<BR>";
					}
					else if ($q_action == 33)
					{
						$q_where = str_replace("data.", "ddata.", $info['q_where']);
						$q_action = "ddata";
						$comment = "Using dirty data set.<BR>Data cleaned at: " . $info['q_cdata_created'] . "<BR>";
					}
					else
					{
						$q_where = $info['q_where'];
						$q_action = "data";
						$comment = "Using raw data set.<BR>";
					}
				
				
					$list = qpl_db_list_data($q_where, $q_action, $q_summary_stats_vars);
					if ($list)
					{
						if ($q_where)
							$comment .= "Including cases where $q_where";
						else
							$comment .= "Including all cases.";
						
						$q_form = FORM_ADMIN_STATS;
						include $q_summary_stats;
						qpl_db_log("Summary Statistics Report: " . $comment . " (" . (microtime(true) - $Start) . " sec.)", LOGIN_OK);
						exit;
					}
					else
						$comment = $qpl_error_message;

					break;

				case 14:		// release unavailable (being edited) cases
					if (($rows = qpl_db_release_not_available_cases($info['q_expire_sess_hrs'])) < 0)
						qpl_db_log($qpl_error_message);
						
					$comment = $rows . " Being edited cases have been released.";
					break;

				case 15:		// change normal user expiration date
					qpl_db_log("To Expire: $q_language", LOGIN_OK);

					$comment = "Enter a new date. (Will never expire if blank.)";
					include (QPL_ADMIN_EXPIRE_FORM);  
					exit;
					break;

				case 17:		// show email list
					$comment = "Edit, copy, or create a new email message.";
					$list = qpl_db_list_messages();
					include (QPL_MAIL_SELECT_FORM);  
					exit;
					break;

				case 18:		// view mail queue
					$comment = qpl_db_view_mail_queue($info['q_project']);
					include (QPL_MAIL_VIEW_LOG_FORM);  
					exit;
					break;

				case 19:		// mail account information to managers and administrators
					$sql = "SELECT q_uname, IF(LENGTH(IFNULL(q_name, '')), q_name, '[none]') as `q_name`, IF(LENGTH(IFNULL(q_email, '')), q_email, '[none]') as `q_email`,
							ELT(q_user_status + 1, 'Closed', 'Normal user', 'Super user', 'Manager', 'Administrator', 'Data administrator', 'System administrator', 'Master administrator') as `Status`,
							q_user_status
							FROM user 
							WHERE q_user_status > " . USER_SUPER . " ORDER BY q_uname;";	
							
					if ($list = qpl_db_query($sql))
					{
						if (qpl_db_num_rows($list) > 0)
						{
							$comment = "Select administrators that will receive account information email messages...";
							include (QPL_MAIL_ADMINISTRATORS_FORM);  
							exit;
						}
						else
							$comment = "No manager or administrative accounts have been created for this project.";
					}
					else
					{
						$comment = $qpl_error_message;
					}
					break;
					
				// case 19 and 20: old custom short and long report removed with new custom reports added in v6
				
				case 21:		// content analysis - display tag definitions
					$comment = "";
					if ($list = qpl_ca_get_tag_list($info['q_max_ca_tags'], $num_tags))
					{
						$list2 = qpl_ca_get_question_list($info['q_max_ca_tags'], $num_ques);
						include (QPL_CA_ADD_EDIT_TAG_LIST_FORM);  
						exit;
					}
					else
						$comment = $qpl_error_message;
					
					break;

				case 22:		// content analysis - assign tags
				case 26:		// content analysis - reconciliation report
				case 27:		// content analysis - summary report
					switch($q_action)
					{
						case 22:		// content analysis - assign tags
							$comment = "Select a question for content analysis.";
							$q_form = FORM_CA_ASSIGN_LIST_QUESTION;
							break;
							
						case 26:		// content analysis - reconciliation report
							$comment = "Select a question for reconciliation report.";
							$q_form = FORM_CA_RECONCILE_REPORT_LIST_QUESTION;
							break;
							
						case 27:		// content analysis - summary report
							$comment = "Select a question for summary report.";
							$q_form = FORM_CA_SUMMARY_REPORT_LIST_QUESTION;
							break;
					}	
					if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num))
					{
						include (QPL_CA_ASSIGN_LIST_QUESTION_FORM);
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;

				case 12:		// create askSamfile
				case 23:		// content analysis - reports
				case 24:		// export ca data
				case 29:		// compute cohen's kappa
					$q_count = qpl_ca_get_question_n($info['q_max_ca_tags']);
					$universe_n = ca_get_universe_n($info['q_where']);
					switch($q_action)
					{
						case 12:	// create askSamfile
							$q_sourcefile = $info['q_project'] . ".txt";
							$comment = "Select content analysis options for askSam import file.";
							$q_form = FORM_CA_EXPORT_ASKSAM;
							break;

						case 23:	// content analysis - assign tags
							$comment = "Select content analysis report tabulation options.";
							$q_form = FORM_CA_REPORT_TABULATION;
							break;
							
						case 24:	//export ca data
							$comment = "Export content analysis data.";
							$q_form = FORM_CA_EXPORT;
							break;
							
						case 29:	// compute cohen's kappa
							$comment = "Select two reviewers for reliability calculations.";
							$q_form = FORM_CA_COHENS_KAPPA;
							break;
					}
						
					$list = qpl_ca_get_reviewers();
					if ($list || $q_form == FORM_CA_EXPORT_ASKSAM)
					{
						include (QPL_CA_REPORT_TABULATION_FORM);  // this form does double-duty for tabulation and export!
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;
					
				case 25:		// content analysis - word count
					$comment = "Select one or more questions for word count analysis.";
					if ($list = qpl_ca_get_question_list_for_word_count($info['q_max_ca_tags'], $num))
					{
						if ($num)
						{
							include (QPL_CA_WORDCOUNT_LIST_QUESTION_FORM);
							exit;
						}
						else
							$comment = $qpl_error_message;
					}
					else
						$comment = $qpl_error_message;
					break;

				case 28:		// content analysis - delegate tasks
					$comment = "Delegate topic definition and reconciliation tasks.";
					if ($list = qpl_ca_get_admin_permission_list())
					{
						include (QPL_CA_DELEGATE_ADMIN_PERMISSIONS);
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;
					
				case 30:		// create reports
					$comment = "Create a new report or edit an existing report.";
					if ($list = qpl_report_get_list())
					{
						include (QPL_REPORT_LIST_FORM);
						exit;
					}
					else
						$comment = $qpl_error_message;
					break;
									
				
				case 31: 	// build clean data set in cdata table...
					include_once QPL_PROJECT_LOCAL_SKIP;
					$comment = qpl_project_local_skip_check();	
					qpl_db_log($comment . " (" . (microtime(true) - $Start) . " sec.)", LOGIN_OK);
					break;
				
				
				default:
				
					if ($q_action > 100) // its a custom report
					{
						$r_id = $q_action - 100;
						
						$report = qpl_report_get_report($r_id)
							or qpl_db_log($qpl_error_message);
							
						$comment = $report['r_title'];
						$layout = ($report['r_layout'] == 0 ? 1 : 2); // horizontal or vertical  ... 1=Short report, 2 = Long report
						$special = $report['r_html'];
						$nl = $report['r_nl2br'];
						$small= $report['r_font'];
						$sql = "SELECT " . $report['r_sql'];
						if (mb_strlen($report['r_set']))
						{
							$setsql = "SET " . $report['r_set'];
							if (!qpl_db_query($setsql))
							{
								$comment = "Report option failed: $setsql";
								break;
							}
						}

						if ($list = qpl_db_query($sql))
						{
							if ($rows = qpl_db_num_rows($list))
							{
								if($report['r_stat'])
								{
									if ($rows == 1)
									{
										$q_form = FORM_ADMIN_STATS;
										if ($info['q_show_personal_response_method'] == 1)
										{
											$response = qpl_db_fetch_array($list);
											$q_uname = $response['q_uname'];
											$q_id = $response['q_id'];
											$comment = "<B>{$report['r_title']}</B><BR>User: $q_uname<BR>Record: $q_id<BR>Date: " . date("l, F j, Y g:i a T");
											include $q_personal_summary_stats;
										}
										else
										{
											include $q_summary_stats;
										}
									}
									else 
									{
										$q_form = FORM_ADMIN_STATS;
										include $q_summary_stats;
									}
								}
								else
								{
									include (QPL_CUSTOM_REPORT_FORM);  
								}
								exit;
							}
							else
								$comment = "The <B>{$data['r_title']}</B>report contains <b>no</b> cases.";
						}
						else
							$comment = $qpl_error_message;
					}
					else				
						$comment = "You selected action number " . $q_action . ".";
			}
			break;
		}
		break;
		
	case FORM_ADMIN:
		$comment = "";
		if ($q_submit == FRM_CANCEL)
			$comment = "The project settings have <B>not</B> been updated.";
		else
		{
			$sql = "UPDATE info SET ";
			$sql .= "q_author='" . qpl_addslashes($q_author) . "', ";
			
			$q_archive = trim($q_archive);
			if (empty($q_archive))
				$sql .= "q_archive=NULL, ";
			elseif (preg_match("~[1-2][0-9]{3}-[0-1]?[0-9]-[0-3]?[0-9]~", $q_archive))
				$sql .= "q_archive='" . $q_archive . "', ";

			if ($q_entry_type == EDIT_MULT && $q_login_type == LOGIN_NAME_NONE)
			{
				$comment .= "You may not use the anonymous log in setting (i.e., 'No account required') with the multiple case data-entry setting (i.e., 'User may edit multiple cases'). ";
				$comment .= "The log in setting has been reset to require a user name and password.<BR><BR>";
				$q_login_type = LOGIN_NAME_REQ;
			}
			$sql .= "q_login_type=" . $q_login_type . ", ";
			
			if (isset($q_get_allowed) && $q_auth_type != AUTH_NORMAL)
			{
				$comment .= "Warning! Only Normal authentication will be used for users who login directly from a URL.<br><br>";
			} 
			
			$sql .= "q_get_allowed=" . (isset($q_get_allowed) ? "1" : "0") . ", ";
			$sql .= "q_login_jump_allowed=" . (isset($q_login_jump_allowed) ? "1" : "0") . ", ";
			$sql .= "q_login_pswd_chng_req=" . (isset($q_login_pswd_chng_req) ? "1" : "0") . ", ";
			$sql .= "q_login_email_req=" . (isset($q_login_email_req) ? "1" : "0") . ", ";
			$sql .= "q_entry_type=" . $q_entry_type . ", ";

			if ($q_entry_type == EDIT_SINGLE && $q_create_type == CREATE_MULT)
			{
				$comment .= "The user can not create multiple new cases unless they are allowed to edit
							multiple cases. The new case setting has been reset to allow only one new
							case to be created.<BR><BR>";
				$q_create_type = CREATE_SINGLE;
			}

			$sql .= "q_create_type=" . $q_create_type . ", ";
			$sql .= "q_auth_type=" . $q_auth_type . ", ";
			$sql .= "q_select_case='" . $q_select_case . "', ";
			$sql .= "q_select_case_alt='" . qpl_addslashes($q_select_case_alt) . "', ";
			$sql .= "q_select_case_label='" . qpl_addslashes($q_select_case_label) . "', ";
			$sql .= "q_select_case_format=" . (isset($q_select_case_format) ? "1" : "0") . ", ";
			$sql .= "q_select_case_required=" . (isset($q_select_case_required) ? "1" : "0") . ", ";
			$sql .= "q_log_file=" . $q_log_file . ", ";

			$q_max_bad_logins += 0;
			if ($q_max_bad_logins >=0 && $q_max_bad_logins <= 255)
				$sql .= "q_max_bad_logins=" . $q_max_bad_logins . ", ";

			$q_expire = trim($q_expire);
			if (empty($q_expire))
				$sql .= "q_expire=NULL, ";
			elseif (preg_match("~[1-2][0-9]{3}-[0-1]?[0-9]-[0-3]?[0-9]~", $q_expire))
				$sql .= "q_expire='" . $q_expire . "', ";
				
			$q_expire_sess_hrs += 0;
			if ($q_expire_sess_hrs >=0 && $q_expire_sess_hrs <= 65535)
				$sql .= "q_expire_sess_hrs=" . $q_expire_sess_hrs . ", ";

			$sql .= "q_min_uname_chars=" . $q_min_uname_chars . ", ";
			$sql .= "q_min_pswd_chars=" . $q_min_pswd_chars . ", ";

			$q_http_referer = trim($q_http_referer);
			if (empty($q_http_referer))
				$sql .= "q_http_referer=NULL, ";
			else
				$sql .= "q_http_referer='" . qpl_addslashes($q_http_referer) . "', ";

			$sql .= "q_where='" . qpl_addslashes($q_where) . "', ";
			$sql .= "q_from_name='" . qpl_addslashes($q_from_name) . "', ";
			$sql .= "q_from_address='" . qpl_addslashes($q_from_address) . "', ";
			$sql .= "q_reply_to='" . qpl_addslashes($q_reply_to) . "', ";
			$sql .= "q_return_path='" . qpl_addslashes($q_return_path) . "', ";

			$sql .= "q_cdata_delegated=" . (isset($q_cdata_delegated) ? "1" : "0") . ", ";
			$sql .= "q_show_personal_response_method=" . $q_show_personal_response_method . " ";

			qpl_db_query($sql)
				or qpl_db_log($qpl_error_message);

			qpl_db_log("Project settings updated", LOGIN_OK);
			$comment .= "The project settings have been updated.";
		}
		break;


	case FORM_ADMIN_USER_FIND:
		if ($q_submit == FRM_CANCEL)
			$comment = "";
		else
		{
			$where = "";
			$Count = 0;
			$sql = "UPDATE find SET ";

			$uf_uname = qpl_addslashes($uf_uname);
			$sql .= "uf_uname='$uf_uname', ";
			if (!empty($uf_uname))
				$where .=  ($Count++ ? " AND " : "") . "user.q_uname LIKE '$uf_uname%' "; 
				
			$uf_pswd = qpl_addslashes($uf_pswd);
			$sql .= "uf_pswd='$uf_pswd', ";
			if (!empty($uf_pswd))
			{
				if (mb_strtoupper($uf_name) == GROUP_NONE)
					$where .=  ($Count++ ? " AND " : "") . "(LENGTH(q_pswd)=0 OR q_pswd IS NULL) "; 
				else
					$where .=  ($Count++ ? " AND " : "") . "q_pswd LIKE '%$uf_pswd%' "; 
			}

			$uf_name = qpl_addslashes($uf_name);
			$sql .= "uf_name='$uf_name', ";
			if (!empty($uf_name))
			{
				if (mb_strtoupper($uf_name) == GROUP_NONE)
					$where .=  ($Count++ ? " AND " : "") . "(LENGTH(q_name)=0 OR q_name IS NULL) "; 
				else
					$where .=  ($Count++ ? " AND " : "") . "q_name LIKE '%$uf_name%' "; 
			}
		
			$uf_email = qpl_addslashes($uf_email);
			$sql .= "uf_email='$uf_email', ";
			if (!empty($uf_email))
			{
				if (mb_strtoupper($uf_email) == GROUP_NONE)
					$where .=  ($Count++ ? " AND " : "") . "(LENGTH(q_email)=0 OR q_email IS NULL) "; 
				else
					$where .=  ($Count++ ? " AND " : "") . "q_email LIKE '%$uf_email%' "; 
			}

			$uf_badaddress 	= (isset($uf_badaddress) ? 1 : 0);
			$sql .= "uf_badaddress='$uf_badaddress', ";
			if ($uf_badaddress)
					$where .=  ($Count++ ? " AND " : "") . " (q_email IS NULL OR q_email NOT REGEXP '^[!-?A-~]+@[!-?A-~]+$') "; 

			$uf_phone = qpl_addslashes($uf_phone);
			$sql .= "uf_phone='$uf_phone', ";
			if (!empty($uf_phone))
			{
				if (mb_strtoupper($uf_phone) == GROUP_NONE)
					$where .=  ($Count++ ? " AND " : "") . "(LENGTH(q_phone)=0 OR q_phone IS NULL) "; 
				else
					$where .=  ($Count++ ? " AND " : "") . "q_phone LIKE '%$uf_phone%' "; 
			}
		
			$uf_other = qpl_addslashes($uf_other);
			$sql .= "uf_other='$uf_other', ";
			if (!empty($uf_other))
			{
				$uf_other_list = preg_split("/[[:space:]]/", $uf_other, 10);
				for ($i = 0; $i < count($uf_other_list); $i++)
					$where .=  ($Count++ ? " AND " : "") . "q_other LIKE '%" . $uf_other_list[$i] . "%' "; 
			}
		
			$uf_group = qpl_addslashes($uf_group);
			$sql .= "uf_group='$uf_group', ";
			if (!empty($uf_group) && mb_strtoupper($uf_group) != GROUP_NONE)
				$where .=  ($Count++ ? " AND " : "") . "q_group LIKE '%$uf_group%' "; 
		
			$uf_closed 		= (isset($uf_closed) ? 1 : 0);
			$uf_normal 		= (isset($uf_normal) ? 1 : 0);
			$uf_super 		= (isset($uf_super) ? 1 : 0);
			$uf_manager 	= (isset($uf_manager) ? 1 : 0);
			$uf_admin 		= (isset($uf_admin) ? 1 : 0);
			$uf_dataadmin 	= (isset($uf_dataadmin) ? 1 : 0);
			$uf_sysadmin 	= (isset($uf_sysadmin) ? 1 : 0);
			
			$sql .= "uf_closed='$uf_closed', ";
			$sql .= "uf_normal='$uf_normal', ";
			$sql .= "uf_super='$uf_super', ";
			$sql .= "uf_manager='$uf_manager', ";
			$sql .= "uf_admin='$uf_admin', ";
			$sql .= "uf_dataadmin='$uf_dataadmin', ";
			$sql .= "uf_sysadmin='$uf_sysadmin', ";
		
			if ($uf_closed || $uf_normal ||	$uf_super || $uf_manager || $uf_admin || $uf_dataadmin || $uf_sysadmin)
			{
				$Count2 = 0;
				
				$where .=  ($Count++ ? " AND " : "") ."(" . 
					($uf_closed ? ($Count2++ ? " OR " : "") . "q_user_status=" . USER_CLOSED : "") .
					($uf_normal ? ($Count2++ ? " OR " : "") . "q_user_status=" . USER_NORMAL : "") .
					($uf_super ? ($Count2++ ? " OR " : "") . "q_user_status=" . USER_SUPER  : "") .
					($uf_manager ? ($Count2++ ? " OR " : "") . "q_user_status=" . USER_MANAGER  : "") .
					($uf_admin ? ($Count2++ ? " OR " : "") . "q_user_status=" . USER_ADMIN  : "") .
					($uf_dataadmin ? ($Count2++ ? " OR " : "") . "q_user_status=" . USER_DATA_ADMIN : "") .
					($uf_sysadmin ? ($Count2++ ? " OR " : "") . "q_user_status=" . USER_SYS_ADMIN  : "") . ")";
			}
			else
				$where .=  ($Count++ ? " AND " : "") ."q_user_status<" . $user['q_user_status'] . " ";

			$uf_num_bad_logins = qpl_addslashes($uf_num_bad_logins) + 0;
			$sql .= "uf_num_bad_logins='$uf_num_bad_logins', ";
			if ($uf_num_bad_logins > 0)
				$where .=  ($Count++ ? " AND " : "") . "q_num_bad_logins >= $uf_num_bad_logins "; 

			$uf_uploaded_files = qpl_addslashes($uf_uploaded_files) + 0;
			$sql .= "uf_uploaded_files='$uf_uploaded_files', ";
			if ($uf_uploaded_files > 0)
	 			$where .=  ($Count++ ? " AND " : "") . "q_uploads >= $uf_uploaded_files "; 

			if (isset($uf_mid) && preg_match("~^[0-9]+$~", $uf_mid) && $uf_mid > 0)
			{
				$sql .= "uf_mid='$uf_mid', ";
				$where .=  ($Count++ ? " AND " : "") . "q_mid = $uf_mid "; 
			}
			else
				$sql .= "uf_mid=NULL, ";


			if (isset($uf_message_count) && preg_match("~^[0-9]+$~", $uf_message_count))
			{
				$sql .= "uf_message_count='$uf_message_count', ";
				if ($uf_message_count > 0)
					$where .=  ($Count++ ? " AND " : "") . "q_submitted_count >= $uf_message_count "; 
				else
					$where .=  ($Count++ ? " AND " : "") . "q_submitted_count = 0 "; 
			}
			else
				$sql .= "uf_message_count=NULL, ";

			$uf_expire = qpl_addslashes($uf_expire);
			if (empty($uf_expire))
				$sql .= "uf_expire=NULL, ";
			elseif (preg_match("~[1-2][0-9]{3}-[0-1]?[0-9]-[0-3]?[0-9]~", $uf_expire))
			{
				$sql .= "uf_expire='$uf_expire', ";
				$where .=  ($Count++ ? " AND " : "") . "q_expire >= '$uf_expire' "; 
			}
			else
				$sql .= "uf_expire=NULL, ";

			$uf_limit = $uf_limit + 0;
			if ($uf_limit < 1)
				$uf_limit = 1;
			$sql .= "uf_limit=$uf_limit, ";

			if ($where)
				$where = " WHERE " . $where . "  AND user.q_uname NOT LIKE '" . USER_NONE . "' ";

			$sql .= "uf_sql=\"" . qpl_addslashes($where) . "\" ";
			$sql .= "WHERE q_uname='$q_uname'";
			qpl_db_query($sql) or
					qpl_db_log($qpl_error_message);

			$list = qpl_db_list_users($where, "LIMIT $uf_limit ", $num_users, $info['q_auth_type']);
			if ($list)
			{
				$comment = "Add a new user or change settings for an existing user.<br><br>User accounts found: $num_users";
				include (QPL_ADMIN_USER_FORM);
				exit;
			}
			else
				$comment = "No matching user accounts found.<br><br>Query: <STRONG>" . htmlspecialchars($where) . "</STRONG>";
				$find = qpl_find_user_query($q_uname)
					or 	qpl_db_log($qpl_error_message);
				include (QPL_ADMIN_USER_FIND_FORM);
				exit;
			break;
		}
		break;

	case FORM_ADMIN_USER:
		if ($q_submit == FRM_CANCEL)
		{
			$find = qpl_find_user_query($q_uname)
				or 	qpl_db_log($qpl_error_message);

			$comment = "Enter user account search criteria.";
			include (QPL_ADMIN_USER_FIND_FORM);
			exit;
			break;
		}
		else
		{
			if ($q_select == USER_NEW)
			{
				qpl_db_update_account(USER_NEW, "new user", "changeme")
					or qpl_db_log($qpl_error_message);
				$comment = "Add new account.";
			}
			else
				$comment = "Edit existing account.";

			$admin_user_status = $user['q_user_status'];
			$user = qpl_db_get_user($q_select)
					or qpl_db_log($qpl_error_message);
			if (isset($user['q_mid']))
			{
				if( !($mail = qpl_db_get_message($user['q_mid'])) )
				{
					qpl_db_log($qpl_error_message, LOGIN_OK);
					unset($user['q_mid']);
				}
			}
			
			$messages_sent = qpl_db_get_messages_sent_to($info['q_project'], $user['q_uname']);
			
			include (QPL_ADMIN_USER_EDIT_FORM);
			exit;
		}
		break;

	case FORM_ADMIN_USER_EDIT:
		if ($q_submit == FRM_CANCEL)
		{
			if ($q_select == USER_NEW)
			{
				$sql = "DELETE FROM user WHERE q_uname='" . USER_NEW . "'";
				qpl_db_query($sql)
					or qpl_db_log($qpl_error_message);
			}
			$comment = "No changes made to user accounts.";
		}
		else	// check field entries
		{
			$comment = "";
			$sql = "UPDATE user SET ";
			$i = 1;
			$q_uname2 = mb_strtolower(qpl_addslashes($q_uname2));  // need to use name of target user, not the admin account!
			
			if ($q_select == USER_NEW)
			{
				$sql .= "q_uname='" . $q_uname2 . "', ";

				if (($user2 = qpl_db_get_user($q_uname2)) != 0)
					$comment .= $i++ . ". The user name you entered has already been used. Please enter a different name.<BR>";
				if (mb_strlen($q_uname2) < $info['q_min_uname_chars'])
					$comment .= $i++ . ". The user name must be at least " . $info['q_min_uname_chars'] . " characters long.<BR>";
				if (preg_match("~[^_.a-z0-9]~", $q_uname2))
					$comment .= $i++ . ". The user name may only contain letters, numbers, periods, or underscore (_) characters. No other punctuation characters may be used.<BR>";
			}

			$q_pswd = mb_strtolower($q_pswd);
			if (preg_match("~[^_.a-z0-9]~", $q_pswd))
				$comment .= $i++ . ". The password may only contain letters, numbers, periods, or underscore (_) characters. No other punctuation characters may be used.<BR>";
			
			
			$sql .= "q_pswd='" . $q_pswd . "', ";
			if (mb_strlen($q_pswd) > 0 && mb_strlen($q_pswd) < $info['q_min_pswd_chars'])
			{
				$comment .= $i++ . ". The password must be at least " . $info['q_min_pswd_chars'] . " characters long.<BR>";
				$comment .= "(Leave the password blank if you are using LDAP authentication for this user.)<BR>";
			}

			$q_name = qpl_addslashes($q_name);
			$sql .= "q_name='" . $q_name . "', ";

			$q_email = qpl_addslashes($q_email);
			$sql .= "q_email='" . $q_email . "', ";

			$q_phone = qpl_addslashes($q_phone);
			$sql .= "q_phone='" . $q_phone . "', ";

			$q_other = qpl_addslashes($q_other);
			$sql .= "q_other='" . $q_other . "', ";

			$q_group = qpl_addslashes($q_group);
			if (mb_strlen($q_group) == 0)
				$q_group = GROUP_NONE;
			$sql .= "q_group='" . $q_group . "', ";

			// $q_user_status -- form only allows changes to non-admin users...
			
			$q_user_status += 0;
			$sql .= "q_user_status='" . $q_user_status . "', ";

			if (isset($q_admin_ip_low) && isset($q_admin_ip_high)) 
			{ 	
				$q_admin_ip_low = qpl_addslashes($q_admin_ip_low);
				if($q_admin_ip_low)
				{
					if (filter_var($q_admin_ip_low, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false)
						$sql .= "q_admin_ip_low='". sprintf("%u", ip2long(long2ip(ip2long($q_admin_ip_low)))) . "', ";	// needed to handle PHP on 32 bit systems
					else
						$comment .= $i++ . ". Invalid low IP address ($q_admin_ip_low). Use <I>n.n.n.n</I> format or leave it blank to not set a range limit.<BR>";
				}
				else 
				{
					$qpl_admin_low = 0;
					$sql .= "q_admin_ip_low='0',";
				}
				
				$q_admin_ip_high = qpl_addslashes($q_admin_ip_high);
				if ($q_admin_ip_high)
				{
					if (filter_var($q_admin_ip_high, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false)
						$sql .= "q_admin_ip_high='". sprintf("%u", ip2long(long2ip(ip2long($q_admin_ip_high)))) . "', ";
					else
						$comment .= $i++ . ". Invalid high IP address ($q_admin_ip_high). Use <I>n.n.n.n</I> format or leave it blank to not set a range limit.<BR>";
				}
				else 
				{
					$qpl_admin_high = 0;
					$sql .= "q_admin_ip_high='0',";
				}
					
				if (ip2long($q_admin_ip_low) > ip2long($q_admin_ip_high))
					$comment .= $i++ . ". Low IP address is greater than the high IP address.";
			}


			$q_num_bad_logins += 0;
			$sql .= "q_num_bad_logins='" . $q_num_bad_logins . "', ";
			
			$q_expire = trim($q_expire);
			if (empty($q_expire))
				$sql .= "q_expire=NULL ";
			elseif (preg_match("~[1-2][0-9]{3}-[0-1]?[0-9]-[0-3]?[0-9]~", $q_expire))
				$sql .= "q_expire='" . $q_expire . "' ";
			else
			{
				$comment .= $i++ . ". Invalid expiration date format. Use <I>yyyy-mm-dd</I> format or leave it blank so account never expires.<BR>";
			}
				
			$sql .= "WHERE q_uname='" . ($q_select == USER_NEW ? USER_NEW : $q_uname2) . "'";

			if (mb_strlen($comment) > 0)
			{
				if ($q_select == USER_NEW)
				{
					$sql = "DELETE FROM user WHERE q_uname='" . USER_NEW . "'";
					qpl_db_query($sql)
						or qpl_db_log($qpl_error_message);
					$comment .= "<BR>New account was <B>not</B> created.";
				}
				else
					$comment .= "<BR>The account for <B>" . htmlspecialchars(stripslashes($q_uname2)) . "</B> has <B>not</B> been updated.";
			}
			else
			{
				qpl_db_query($sql)
					or qpl_db_log($qpl_error_message);
			
				if ($q_select == USER_NEW)
				{
					qpl_db_log(  "New user added: " . $q_uname2, LOGIN_OK);
					$comment = "New account for <B>" . htmlspecialchars(stripslashes($q_uname2)) . "</B> has been added.";
				}
				else
				{
					qpl_db_log(  "User updated: " . $q_uname2, LOGIN_OK);
					$comment = "The account for <B>" . htmlspecialchars(stripslashes($q_uname2)) . "</B> has been updated.";
				}
			}
		}

		if ($q_submit == FRM_VIEW && $q_select != USER_NEW)
		{	// show summary stats for this existing user
		
			$q_user_id = $info['q_select_case'];
			if ($info['q_select_case'] == PROJECT_ID && mb_strlen($info['q_select_case_alt']))
			{
				$q_user_id = $info['q_select_case_alt'];
			}

			$sql = "SELECT $q_user_id AS 'q_user_id', data.* FROM data WHERE q_uname='$q_uname2'" . ($q_group == GROUP_NONE ? "" : " OR q_group='$q_group'") . " ORDER BY q_user_id";
			
			$list = qpl_db_query($sql)
				or qpl_db_log($qpl_error_message);

			$num = qpl_db_num_rows($list);
			if ($num > 0)
			{
				if ($num == 1)
				{
					$comment = "<B>Summary of responses for $q_uname2</B>.<BR>" . date("l, F j, Y g:i a T");
					$q_form = FORM_ADMIN_USER_VIEW_STATS;
					if ($info['q_show_personal_response_method'] == 1)
					{
						$response = qpl_db_fetch_array($list);
						$q_uname = $response['q_uname'];
						$q_id = $response['q_id'];
						include $q_personal_summary_stats;
					}
					else
					{
						include $q_summary_stats;
					}
					exit;
				}	// This user has a number of forms...
				else
				{
					$comment .= "Select from <b>$q_uname2's</b> cases.";
					$q_form = FORM_ADMIN_USER_VIEW_CASE_SELECTION;
					include (QPL_ADMIN_USER_VIEW_CASE_SELECTION);
					exit;
				}
			}
			else
				$comment = "User $q_uname2 has not entered any responses.<BR>";
		}
		else if ($q_submit == FRM_VIEWLOG && $q_select != USER_NEW)
		{	// show log history for this existing user
		
			if ( ($list = qpl_db_list_history_log("q_uname='$q_uname2'")) )
			{
				$comment = "<B>View Log</B><br>";
				$comment .= "For user: " . stripslashes($q_name) . " ($q_uname2)<br>";
				$comment .= "List includes the last 100 log entries.";
				$q_form = FORM_ADMIN_USER_VIEW_STATS;
				include (QPL_ADMIN_LOG_FORM);
				exit;
			}
			else
			{
				$comment = "User $q_uname2 has never logged in.";
			}
		}	
		else if ($q_submit == FRM_VIEWUPLOAD && $q_select != USER_NEW)
		{	// show list of uploaded files
			if ( ($list = qpl_get_uploaded_file_list($q_uname2, $q_group, $info['q_project'])) )
			{
				$comment = "Files uploaded by: <B>$q_uname2</B>" . ($q_group == GROUP_NONE ? "." : " (Group: $q_group).");
				//$q_form = FORM_ADMIN_USER_VIEW_STATS;
				$q_form = FORM_ADMIN_USER_VIEW_UPLOADS;
				include (QPL_ADMIN_USER_VIEW_UPLOADS);
				exit;
			}
			else
			{
				$comment = "User $q_uname has not uploaded any files.";
			}
		}
		
		// fall into the next case statement if have not launched another page...
		
	case FORM_ADMIN_USER_VIEW_STATS:
		// restart user list page
		$find = qpl_find_user_query($q_uname)
			or qpl_db_log($qpl_error_message);
		$list = qpl_db_list_users($find['uf_sql'], "LIMIT " . $find['uf_limit'] . " ", $num_users);
		if ($list)
		{
			$comment .= "<BR>Total user accounts: $num_users";
			include (QPL_ADMIN_USER_FORM);
			exit;
		}
		else
		{
			$comment .= "<BR>No matching user accounts found.";
			include (QPL_ADMIN_USER_FIND_FORM);
			exit;
		}
		break;

	case FORM_ADMIN_USER_VIEW_STATS2:		// this is used when one respondent has multiple cases...
		$user = qpl_db_get_user($q_uname2)
				or qpl_db_log($qpl_error_message);

		$q_group = $user['q_group'];

		$q_user_id = $info['q_select_case'];
		if ($info['q_select_case'] == PROJECT_ID && mb_strlen($info['q_select_case_alt']))
		{
			$q_user_id = $info['q_select_case_alt'];
		}

		$sql = "SELECT $q_user_id AS 'q_user_id', data.* FROM data WHERE q_uname='$q_uname2'" . ($q_group == GROUP_NONE ? "" : " OR q_group='$q_group'") . " ORDER BY q_user_id";
			
		$list = qpl_db_query($sql)
			or qpl_db_log($qpl_error_message);
			
		$num = qpl_db_num_rows($list);

		$comment .= "<br><br>Select from <b>$q_uname2's</b> cases.";
		$q_form = FORM_ADMIN_USER_VIEW_CASE_SELECTION;
		include (QPL_ADMIN_USER_VIEW_CASE_SELECTION);
		exit;

	case FORM_ADMIN_USER_VIEW_CASE_SELECTION:
		if ($q_select > 0)
		{
			$sql = "SELECT * FROM data WHERE q_id=$q_select";
			
			$list = qpl_db_query($sql)
				or qpl_db_log($qpl_error_message);

			$num = qpl_db_num_rows($list);
			if ($num > 0)
			{
				$comment = "<B>Summary of responses for $q_uname2.</B><BR>Record: $q_select<BR>Date: " . date("l, F j, Y g:i a T");
				$q_form = FORM_ADMIN_USER_VIEW_STATS2;
				if ($info['q_show_personal_response_method'] == 1)
				{
					$response = qpl_db_fetch_array($list);
					$q_uname = $response['q_uname'];
					$q_id = $response['q_id'];
					include $q_personal_summary_stats;
				}
				else
				{
					include $q_summary_stats;
				}
				exit;
			}	
		}
		else
		{
			// restart user list page
			$find = qpl_find_user_query($q_uname)
				or qpl_db_log($qpl_error_message);
			$list = qpl_db_list_users($find['uf_sql'], "LIMIT " . $find['uf_limit'] . " ", $num_users);
			if ($list)
			{
				$comment .= "<br><br>Total user accounts: $num_users";
				include (QPL_ADMIN_USER_FORM);
				exit;
			}
			else
			{
				$comment .= "<BR><BR>No matching user accounts found.";
				include (QPL_ADMIN_USER_FIND_FORM);
				exit;
			}
		}
		break;
	
	case FORM_ADMIN_RESPONSE:
	case FORM_ADMIN_SESSION:
	case FORM_ADMIN_LOG:
	case FORM_ADMIN_STATS:
	case FORM_MAIL_SEND:
	case FORM_MAIL_LOG:
	case FORM_CUSTOM_REPORT:
		$comment = "";
		break;


	case FORM_ADMIN_RESET_EXPIRATION:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Normal user expiration dates not changed.";
		}
		else
		{
			$sql = "";
			$q_expire = trim($q_expire);
			if (empty($q_expire))
			{
				$sql = "q_expire=NULL ";
				$comment = "All normal user accounts have been set so they never expire.";
			}
			elseif (preg_match("~[1-2][0-9]{3}-[0-1]?[0-9]-[0-3]?[0-9]~", $q_expire))
			{
				$sql = "q_expire='" . $q_expire . "' ";
				$comment = "All normal user accounts have been set to expire on $q_expire.";
			}

			if ($sql)
			{
				$sql = "UPDATE user SET " . $sql . "WHERE q_user_status=" . USER_NORMAL;
				qpl_db_query($sql)
					or qpl_db_log($qpl_error_message);
				qpl_db_log($comment, LOGIN_OK);
			}
			else
				$comment = "Date entered, $q_expire, is not valid. User accounts were not changed.";
		}
		break;

	case FORM_MAIL_SELECT:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Email messages not changed.";
		}
		else
		{
			if ($q_mid == 0)
			{
				$q_mid = qpl_db_add_new_message($q_uname)
					or qpl_db_log($qpl_error_message);
			}
			$mail = qpl_db_get_message($q_mid)
				or qpl_db_log($qpl_error_message);
			include (QPL_MAIL_EDIT_FORM);
			exit;
		}
		break;
			
	case FORM_MAIL_EDIT:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Message #$q_mid not changed.";
		}
		elseif ($q_submit == FRM_SAVE)
		{
			$sql = "UPDATE mail SET ";
			$sql .= "q_select='" . qpl_addslashes($q_select) . "', ";
			$sql .= "q_join='$q_join', ";
			$sql .= "q_where='" . qpl_addslashes($q_where) . "', ";
			$sql .= "q_comment='" . qpl_addslashes($q_comment) . "', ";
			$sql .= "q_from_name='" . qpl_addslashes($q_from_name) . "', ";
			$sql .= "q_from='" . qpl_addslashes($q_from) . "', ";
			$sql .= "q_replyto='" . qpl_addslashes($q_replyto) . "', ";
			$sql .= "q_returnpath='" . qpl_addslashes($q_returnpath) . "', ";
			$sql .= "q_subject='" . qpl_addslashes($q_subject) . "', ";
			$sql .= "q_message_attachment=" . ($q_message_attachment ? "'" . qpl_addslashes($q_message_attachment) . "', " : "NULL, ");
			$sql .= "q_message='" . qpl_addslashes($q_message) . "', ";
			$sql .= "q_message_html='" . qpl_addslashes($q_message_html) . "', ";
			$sql .= "q_submitted_delay=" . $q_submitted_delay . " ";
			$sql .= "WHERE q_mid=$q_mid";

			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
		
			$comment = "Saved message #$q_mid as <B>" . htmlspecialchars(stripslashes($q_subject)) . "</B>";

		}
		elseif  ($q_submit == FRM_TEST)
		{
			$sql = "UPDATE mail SET ";
			$sql .= "q_select='" . qpl_addslashes($q_select) . "', ";
			$sql .= "q_join='$q_join', ";
			$sql .= "q_where='" . qpl_addslashes($q_where) . "', ";
			$sql .= "q_comment='" . qpl_addslashes($q_comment) . "', ";
			$sql .= "q_from_name='" . qpl_addslashes($q_from_name) . "', ";
			$sql .= "q_from='" . qpl_addslashes($q_from) . "', ";
			$sql .= "q_replyto='" . qpl_addslashes($q_replyto) . "', ";
			$sql .= "q_returnpath='" . qpl_addslashes($q_returnpath) . "', ";
			$sql .= "q_subject='" . qpl_addslashes($q_subject) . "', ";
			$sql .= "q_message='" . qpl_addslashes($q_message) . "', ";
			$sql .= "q_message_html='" . qpl_addslashes($q_message_html) . "', ";
			$sql .= "q_message_attachment=" . ($q_message_attachment ? "'" . qpl_addslashes($q_message_attachment) . "', " : "NULL, ");
			$sql .= "q_submitted_delay=" . $q_submitted_delay . " ";
			$sql .= "WHERE q_mid=$q_mid";

			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);

			if ( !($list = qpl_db_list_respondents($info['q_project'], $q_mid, $message_count, $field, $field_count, $sql)) )
			{
				$comment = $qpl_error_message;
				$mail = qpl_db_get_message($q_mid)
					or qpl_db_log($qpl_error_message);
				include (QPL_MAIL_EDIT_FORM);
				exit;
			}
			else
			{
				$perl_field_count = preg_match_all('/[{]\$(\w+)[}]/', $q_message . $q_message_html , $perl_field);

				$comment = "These settings will generate $message_count messages using the &quot;$q_subject&quot; template.";

				// Reconcile data fields and template fields
				for ($j = 0; $j < $field_count; $j++)
				{
					$no_match[$j] = $field[$j];
				}

				for	 ($i = 0; $i < $perl_field_count; $i++)
				{
					$match_field[$i] = "";
					for ($j = 0; $j < $field_count; $j++)
					{
						if ($perl_field[1][$i] == $field[$j])
						{
							$match_field[$i] = $field[$j];
							$no_match[$j] = "";
							break;
						}
					}
				}
				include (QPL_MAIL_TEST_FORM);
				exit;
			}

		}
		elseif  ($q_submit == FRM_COPY)
		{
			$q_old_subject = $q_subject = qpl_addslashes($q_subject);
			$q_subject = preg_replace("~ \([0-9]+\)$~", "", $q_subject);
			if (($q_subject_count = qpl_db_count_messages($q_subject)) > 0)
				$q_subject .= " ($q_subject_count)";
				
			$sql = "INSERT INTO mail SET ";
			$sql .= "q_select='" . qpl_addslashes($q_select) . "', ";
			$sql .= "q_join='$q_join', ";
			$sql .= "q_where='" . qpl_addslashes($q_where) . "', ";
			$sql .= "q_comment='" . qpl_addslashes($q_comment) . "', ";
			$sql .= "q_from_name='" . qpl_addslashes($q_from_name) . "', ";
			$sql .= "q_from='" . qpl_addslashes($q_from) . "', ";
			$sql .= "q_replyto='" . qpl_addslashes($q_replyto) . "', ";
			$sql .= "q_returnpath='" . qpl_addslashes($q_returnpath) . "', ";
			$sql .= "q_subject='$q_subject', ";
			$sql .= "q_message='" . qpl_addslashes($q_message) . "', ";
			$sql .= "q_message_html='" . qpl_addslashes($q_message_html) . "', ";
			$sql .= "q_message_attachment=" . ($q_message_attachment ? "'" . qpl_addslashes($q_message_attachment) . "', " : "NULL, ");
			$sql .= "q_submitted_delay=" . $q_submitted_delay . ", ";
			$sql .= "q_uname='$q_uname'";

			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
			$q_mid = qpl_db_find_message($q_subject)
				or qpl_db_log($qpl_error_message);
			$comment = "This is new copy of <b>$q_old_subject.</b>";
			$mail = qpl_db_get_message($q_mid)
				or qpl_db_log($qpl_error_message);
			include (QPL_MAIL_EDIT_FORM);
			exit;
		}

		elseif  ($q_submit == FRM_RECALL)
		{
			$result = qpl_db_recall_messages($info['q_project'], $q_mid, $comment)
				or qpl_db_log($qpl_error_message);

			if ($result == 1)
			{
				$mail = qpl_db_get_message($q_mid)
					or qpl_db_log($qpl_error_message);
				include (QPL_MAIL_EDIT_FORM);
				exit;
			}
		}
		
		elseif  ($q_submit == FRM_VIEWLOG)
		{
			$list = qpl_db_list_message_log($info['q_project'], $q_mid, $num, $comment)
				or qpl_db_log($qpl_error_message);
			include (QPL_MAIL_VIEW_LOG_DETAIL_FORM);
			exit;
		}

		$list = qpl_db_list_messages();
		include (QPL_MAIL_SELECT_FORM);  
		exit;
		break;
		
	case FORM_MAIL_TEST:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Email messages not sent.";
			$mail = qpl_db_get_message($q_mid)
				or qpl_db_log($qpl_error_message);
			include (QPL_MAIL_EDIT_FORM);
			exit;
		}
		elseif ($q_submit == FRM_SEND)
		{
			$list = qpl_db_list_respondents($info['q_project'], $q_mid, $message_count, $field, $field_count, $sql) 
				or qpl_db_log($qpl_error_message);

			$mail = qpl_db_get_message($q_mid)
				or qpl_db_log($qpl_error_message);
				
			$comment = "Adding <b>" . $mail['q_subject'] . "</b> for project <b>" . $info['q_project'] . "</b> to the mail queue.";
			include (QPL_MAIL_SEND_FORM);
			exit;
		}
		break;

	case FORM_MAIL_LOG_DETAIL:
		$comment = "";
		$mail = qpl_db_get_message($q_mid)
			or qpl_db_log($qpl_error_message);
		include (QPL_MAIL_EDIT_FORM);
		exit;
		
		
	case FORM_CA_ADD_EDIT_LIST:
		if ($q_submit == FRM_CANCEL)
		{
			if ($user['q_user_status'] == USER_SYS_ADMIN || $user['q_user_status'] == USER_DATA_ADMIN)
				$comment = "No content analysis tags were changed.";
			else
				$comment = "";
		}
		else
		{
			$tag_data = qpl_ca_get_tag($q_select, $q_uname)
				or qpl_db_log($qpl_error_message);

			$list = qpl_ca_get_tag_questions($info['q_max_ca_tags'], $tag_data['t_id'], $num)
					or qpl_db_log($qpl_error_message);

			if ($q_select)
				$comment = "Edit topic tag definition.";
			else
				$comment = "Add new topic tag definition.";

			include (QPL_CA_ADD_EDIT_TAG_FORM);
			exit;
		}
		break;

	case FORM_CA_ADD_EDIT:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Tag " . stripslashes($t_tag) . " was not changed.";
		}
		else
		{
			// update tag def info

			
			$t_tag = str_replace(" ", "_", trim($t_tag));
			$t_tag = str_replace("\t", "_", $t_tag);
			$t_tag = str_replace(",", "_", $t_tag);
			if (!mb_strlen($t_tag))
				$t_tag = "NEW";
			
			$sql = "UPDATE ca_tag_def SET t_tag='" . qpl_addslashes($t_tag) . "', t_def='" . qpl_addslashes($t_def) . "', q_uname='$q_uname' WHERE t_id=$t_id";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);

			$log_comment = "Tag #$t_id, $t_tag, definition was updated and assigned to ";
		
			// update question def info
		
			qpl_ca_get_tag_mask($info['q_max_ca_tags'], $t_id, $block, $mask); 
			$sql = "SET @mask = CONV('$mask', 2, 10)";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);

			// clear bit on all questions before applying update...
			
			$sql = "UPDATE ca_ques_def SET $block = $block & ~@mask";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
		
			// now turn on the bit for the selected questions...
			$sql = "UPDATE ca_ques_def SET $block = $block | @mask WHERE ";

			reset($_POST);
			$num_q = 0;
			if (isset($_POST['q_varname']))
			{
				$num_q = count($_POST['q_varname']);
				$for_ques = "";

				if ($num_q)
				{
					for ($i = 0; $i < $num_q; $i++)
					{
						$for_ques .= ($i > 0 ? " OR " : "") . "q_varname = '" . $_POST['q_varname'][$i] . "' ";
						$log_comment .= ($i ? ", " : "") . $_POST['q_varname'][$i];
						
					}
					qpl_db_query($sql . $for_ques) or
						qpl_db_log($qpl_error_message);
				}
			}
			else 
				$log_comment .= "no questions.";
			
			qpl_db_log($log_comment, LOGIN_OK);	// record update in log table
			
			// clear tag from questions it no longer applies to anymore..
			
			if (isset($q_clear))
			{
				$sql = "UPDATE ca_assign SET $block = $block & ~@mask " . ($num_q ? "WHERE NOT($for_ques)" : "");
				qpl_db_query($sql) or
					qpl_db_log($qpl_error_message);
					
				qpl_db_log("Tag #$t_id, $t_tag, was removed from all responses to questions not included in assignment list.", LOGIN_OK);
			}

		}
		$comment = "";
		if ($list = qpl_ca_get_tag_list($info['q_max_ca_tags'], $num_tags))
		{
			$list2 = qpl_ca_get_question_list($info['q_max_ca_tags'], $num_ques);
			include (QPL_CA_ADD_EDIT_TAG_LIST_FORM);  
			exit;
		}
		else
			$comment = $qpl_error_message;

		break;

	case FORM_CA_ASSIGN_LIST_QUESTION:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "No questions were selected for analysis.";
		}
		else
		{
			$comment = "Select a group of responses to question $q_select for analysis.";
			
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_select))
			{
				$q_form = FORM_CA_ASSIGN_SELECT_RESPONSES;
				include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);
				exit;
			}
			else
				$comment = $qpl_error_message;
		}
		break;

	case FORM_CA_ASSIGN_SELECT_RESPONSES:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "No responses were selected for analysis.";
			$q_form = FORM_CA_ASSIGN_LIST_QUESTION;
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num))
			{
				include (QPL_CA_ASSIGN_LIST_QUESTION_FORM);
				exit;
			}
			else
				$comment = $qpl_error_message;
		}
		else
		{
			$comment = "";
			
			$sql = "UPDATE ca_ques_def SET q_comment='" . qpl_addslashes($q_comment) . "' WHERE q_varname='$q_varname'";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);

			$sql = "DELETE FROM ca_cases WHERE q_uname='$q_uname'";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
// echo $sql . "<br><br>";
			$sql = "SET @c_id = 0";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
// echo $sql . "<br><br>";
			
			$sql = "CREATE TEMPORARY TABLE tmp_assign SELECT * FROM ca_assign WHERE q_uname='$q_uname' AND q_varname='$q_varname'";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
// echo $sql . "<br><br>";

			$sql = "INSERT INTO ca_cases (c_id, q_uname, q_varname, q_id) SELECT @c_id := @c_id + 1, '$q_uname', '$q_varname', data.q_id FROM data LEFT JOIN tmp_assign ON data.q_id=tmp_assign.q_id";

			reset($_POST);
			$num = 0;
			$sql_where = "";
			$sql_where2 = "";
			if (isset($_POST['t_tag']))
			{
				$num = count($_POST['t_tag']);
				$for_ques = "";

				if ($num)
				{
					if ($_POST['t_tag'][0] == '[none]')
					{
						$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "(ISNULL(tmp_assign.t0) OR NOT(";
						
						for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
						{
							$sql_where .= ($i ? " + " : "") . "tmp_assign.t$i";
						}
						$sql_where .= "))";
					}
					elseif ($_POST['t_tag'][0] == '[any]')
						/* do nothing */ ;

					else
					{
						$sql_where .=  (mb_strlen($sql_where) ? " AND " : "") . "(";
						for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
						{
							$sql_where2 .= (mb_strlen($sql_where2) ? " OR " : "") . "tmp_assign.t$i & @t$i";
						}
						$sql_where .= $sql_where2 . ")";
					}
					
					if ($sql_where2) // set bit masks
					{
						// initialize sql variables
						$sql2 = "SET ";
						for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
						{
							$sql2 .= ($i ? ", " : "") . "@t$i = 0";
						}
						qpl_db_query($sql2) or
							qpl_db_log($qpl_error_message);

						// set tag bits on sql variables
						for ($i = 0; $i < $num; $i++)
						{
							qpl_ca_get_tag_mask($info['q_max_ca_tags'], $_POST['t_tag'][$i], $block, $mask);
							$sql2 =  "SET @$block = @$block | CONV('$mask', 2, 10)";
							qpl_db_query($sql2) or
								qpl_db_log($qpl_error_message);
//echo $sql2 . "<br><br>";
						}
					}
				}
			}

			if (isset($q_response) && mb_strlen(trim($q_response)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_response, "data.$q_varname");
			}

			if (isset($q_your_comment) && mb_strlen(trim($q_your_comment)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_your_comment, "tmp_assign.a_comment");
			}

			if (isset($r_uname) && mb_strlen(trim($r_uname)))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "data.q_uname = '" . trim($r_uname) . "'";
			}

			if (isset($q_id_low) && preg_match('/^[0-9]+$/', $q_id_low))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "data.q_id >=$q_id_low";
			}

			if (isset($q_id_high) && preg_match('/^[0-9]+$/', $q_id_high))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "data.q_id <=$q_id_high";
			}

			if (isset($q_id_text) && mb_strlen(trim($q_id_text)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_id_text, "data." . $info['q_select_case']);
			}

			if (isset($q_blanks))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "LENGTH(data.$q_varname)";
			}
			
			// Add tabulation report and file export WHERE clause..
			
			if ($info['q_where'])
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "(" . $info['q_where'] . ")";
			}
			
			
			$sql .= " WHERE " . $sql_where;   // need to add the other where and order by stuff...
			$sql .= " ORDER BY " . $q_sort;
			
			if (isset($q_limit) && $q_limit > 0)
				$sql .= " LIMIT $q_limit";
			else 
				$sql .= " LIMIT " . CA_MAX_LIST_RESPONSES;
// echo $sql . "<br><br>";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);

			$comment = "Select the first response to question $q_varname in this group for analysis.";
			
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
			{
				if ($list2 = qpl_ca_get_response_list($info['q_max_ca_tags'], $q_varname, $q_uname, $num, 0, $info['q_select_case']))
				{
					if ($num)
					{
						include (QPL_CA_ASSIGN_LIST_RESPONSES_FORM);
						exit;
					}
					else
					{
						$comment = "No cases were selected.<br><STRONG>($sql_where)</STRONG>";
						if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
						{
							$q_form = FORM_CA_ASSIGN_SELECT_RESPONSES;
							include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);
							exit;
						}
						else
							$comment = $qpl_error_message;
					}
				}
				else
					$comment = $qpl_error_message;
			}
			else
				$comment = $qpl_error_message;
		}
		break;

	case FORM_CA_ASSIGN_LIST_RESPONSES:
		if (!isset($q_show_q))
			$q_show_q = 0;
			
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Select responses to question $q_varname for analysis.";
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
			{
				$q_form = FORM_CA_ASSIGN_SELECT_RESPONSES;
				include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);
				exit;
			}
			else
				$comment = $qpl_error_message;
		}
		else
		{
			$comment = "Assign or edit topic tags, and make a comment about the response.";
			if ($list = qpl_ca_get_response($info['q_max_ca_tags'], $q_uname, $q_varname, $q_select, $info['q_select_case']))
			{
				include (QPL_CA_ASSIGN_TAGS_FORM);
				exit;
			}
			else
				$comment = $qpl_error_message;
		}
		break;
		
	case FORM_CA_ASSIGN_TAGS:
	
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Tag assignments not changed.";
		}
		else
		{
		// update tag assignments
			$comment = "Tag assignments updated.";
			
		// clear all old tag bits
			// initialize sql variables
			$sql = "SET ";
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ($i ? ", " : "") . "@t$i = 0";
			}
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
			// Note: Could just reset all blocks to zero, but this would also clear out tags that could are no longer allowed to be applied...??? 
			$td_list = explode("|", $tag_def_list);
			// set tag bits on sql variables (fixed for MySQL 4.1)
			for ($i = 0; $i < count($td_list); $i++)
			{
				qpl_ca_get_tag_mask($info['q_max_ca_tags'], $td_list[$i], $block, $mask);
				$sql =  "SET @$block = @$block | CONV('$mask', 2, 10)";
				qpl_db_query($sql) or
					qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
			}

			// clear tag bits on this case and update the comment
			$sql = "UPDATE ca_assign SET ";
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ($i ? ", " : "") . "t$i = t$i & ~@t$i";
			}
			$sql .= ", a_comment='" . qpl_addslashes($a_comment) . "' WHERE id=$id";
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
			
		// set new tag bits, if necessary...
		
			reset($_POST);
			$num = 0;
			if (isset($_POST['t']))
			{
				$num = count($_POST['t']);
				
				// reset the sql variables			
				$sql = "SET ";
				for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
				{
					$sql .= ($i ? ", " : "") . "@t$i = 0";
				}
				qpl_db_query($sql) or
					qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
			
				// set tag bits on sql variables (fixed for MySQL 4.1)
				for ($i = 0; $i < $num; $i++)
				{
					qpl_ca_get_tag_mask($info['q_max_ca_tags'], $_POST['t'][$i], $block, $mask);
					$sql =  "SET @$block = @$block | CONV('$mask', 2, 10)";
					qpl_db_query($sql) or
						qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
				}


				// set bits on this case
				$sql = "UPDATE ca_assign SET ";
				for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
				{
					$sql .= ($i ? ", " : "") . "t$i = t$i | @t$i";
				}
				$sql .= " WHERE id=$id";
				qpl_db_query($sql) or
					qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
					
			}
		}
		
		$c_id += ($q_submit==FRM_PREVIOUS ? -1 : 1);
		$q_select = qpl_ca_lookup_q_id($q_uname, $q_varname, $c_id);
		if ($q_select && ($q_submit==FRM_NEXT || $q_submit==FRM_PREVIOUS))
		{
			// goto Next or Previous q_id...
			if ($q_select)
			{
				
				$comment = "Assign topic tags.";
				if ($list = qpl_ca_get_response($info['q_max_ca_tags'], $q_uname, $q_varname, $q_select, $info['q_select_case']))
				{
					include (QPL_CA_ASSIGN_TAGS_FORM);
					exit;
				}
				else
					$comment = $qpl_error_message;
			}
		}
		else
		{
			// go back to current response list from Exit or Cancel
		
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
			{
				if ($list2 = qpl_ca_get_response_list($info['q_max_ca_tags'], $q_varname, $q_uname, $num, 0, $info['q_select_case']))
				{
					if ($num)
					{
						include (QPL_CA_ASSIGN_LIST_RESPONSES_FORM);
						exit;
					}
					else
					{
						$comment = "No cases were selected.";
						if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
						{
							$q_form = FORM_CA_ASSIGN_SELECT_RESPONSES;
							include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);
							exit;
						}
						else
							$comment = $qpl_error_message;
					}
				}
				else
					$comment = $qpl_error_message;
			}
			else
				$comment = $qpl_error_message;
		}	
		break;
	
	case FORM_CA_REPORT_TABULATION:
	case FORM_CA_EXPORT:
	case FORM_CA_EXPORT_ASKSAM:
	
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Action cancelled.";
		}
		else
		{
			if (!isset($qpl_from))
				$qpl_from = 'data';

			$comment = ($q_reconcile ? "Union" : "Intersection");
			reset($_POST);
			$num = 0;
			$num_reviewers = 0;
			$name_reviewer = "";
			$sql_where = "";
			
			$q_universe_n = ca_get_universe_n($info['q_where']);
			
			if (isset($_POST['q_uname']))
			{
				$num = count($_POST['q_uname']);
				$for_ques = "";

				if ($num)
				{
					if ($_POST['q_uname'][0] == '[all]')
						$comment .= " of all reviewer tags." ;
					
					else
					{
						$comment .= " of";
						$sql_where = "(";
						$num_reviewers = $num;
						
						if ($num == 1)
							$name_reviewer = $_POST['q_uname'][0];
						for ($i = 0; $i < $num; $i++)
						{
							$sql_where .= ($i ? " OR " : "") . "q_uname='" . $_POST['q_uname'][$i] . "'";
							$comment .= ($i ? ", " : " ") . $_POST['q_uname'][$i];
						}
						$sql_where .= ")";
						$comment .= " tags.";
					}
				}
			}
			else 
				$comment .= " of all reviewer tags." ;
			
			$sql_where .= ($sql_where ? " AND (" : "(");
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql_where .= ($i ? " OR " : "") . "t$i";
			}
			$sql_where .= ")";
			
			$sql = "CREATE TEMPORARY TABLE tmp_assign SELECT q_id, q_varname" . ($name_reviewer ? ", a_comment" : "") . ",  IF(";
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ($i ? " AND " : "") . "MIN(t$i)=MAX(t$i)";
			}
			$sql .= ", 1, 0) AS 'q_agree', COUNT(*) AS 'q_num_reviewers' ";
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ", " . ($q_reconcile ? "BIT_OR" : "BIT_AND") . "(t$i) AS t$i";
			}
			$sql .= " FROM ca_assign WHERE $sql_where GROUP BY q_id, q_varname";					
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
			
			$sql = "SELECT tmp_assign.q_id, tmp_assign.q_varname, tmp_assign.q_agree, tmp_assign.q_num_reviewers, " . ($name_reviewer ? "tmp_assign.a_comment AS '$name_reviewer', " : "") .
					($q_form==FORM_CA_REPORT_TABULATION || $q_form == FORM_CA_EXPORT_ASKSAM ? 
						qpl_ca_tag_make_set($info['q_max_ca_tags'], "tmp_assign") : 
						qpl_ca_tag_bin_string($info['q_max_ca_tags'], "tmp_assign")) . 
					" FROM tmp_assign, data " .
					" WHERE tmp_assign.q_id=data.q_id". 
					($info['q_where'] ? " AND (" . $info['q_where'] . ")" : "") .
					" AND (";
					
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ($i ? " OR " : "") . "tmp_assign.t$i";
			}
			$sql .= ") ORDER BY tmp_assign.q_id, tmp_assign.q_varname";

//echo $sql . "<br><br>";

			if ($q_form == 	FORM_CA_REPORT_TABULATION)
			{
				if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num))
				{
					if ($list2 = qpl_db_query($sql))
					{
						if ($num)
						{
							$comment .= "<br>$num question" . ($num > 1 ? "s have" : " has") . " been tagged.";
							include (QPL_CA_REPORT_TABULATION_SUMMARY_FORM);
							exit;
						}
						else
							$comment = $qpl_error_message;
					}
					else
						$comment = $qpl_error_message;
				}
				else
					$comment = $qpl_error_message;
			}
			elseif ($q_form == FORM_CA_EXPORT) // export the data...
			{
				$q_sourcefile = $info['q_project'] . "-ca.txt";
				$comment = "";
				$rows = qpl_ca_make_tab_file($q_sourcefile, $name_reviewer, $sql, $info['q_max_ca_tags'], isset($q_include_response), $num);
				if ($rows > 0)
				{
					qpl_db_log("Exported content analysis tags tab-delimited file: $q_sourcefile  ($rows records)", LOGIN_OK);
					if (qpl_direct_download(DATA_PATH, $q_sourcefile))
						exit;
					else 
						$comment = $qpl_error_message;
				}
				else
					$comment = $qpl_error_message;
			}
			else // make askSam file..
			{
				if ($qpl_from == 'data')
				{
					$q_sourcefile = $info['q_project'] . "-asksam-raw.txt";
					$comment .= "\nRaw data.";
					$q_where = $info['q_where'];
				}
				else if ($qpl_from == 'ddata')
				{
					$q_sourcefile = $info['q_project'] . "-asksam-dirty.txt";
					$comment .= "\nDirty data.";
					$q_where = $info['q_where'];
				}
				else
				{
					$q_sourcefile = $info['q_project'] . "-asksam-clean.txt";
					$comment .= "\nClean data.";
					$q_where = str_replace("data.", "cdata.", $info['q_where']);
				}

				$rows = qpl_db_make_asksam_file($comment, $q_sourcefile, $name_reviewer, $sql, $info['q_max_ca_tags'], $num, $q_where, $qpl_from);
				if ($rows > 0)
				{
					qpl_db_log("Exported askSam file: $q_sourcefile ($rows records)", LOGIN_OK);
					if (qpl_direct_download(DATA_PATH, $q_sourcefile))
						exit;
					else 
						$comment = $qpl_error_message;
				}
				else
					$comment = $qpl_error_message;
			}
		}
		break;
	
	case FORM_CA_REPORT_TABULATION_SUMMARY:
		$comment = "Select content analysis tabulation options.";
		$q_count = qpl_ca_get_question_n($info['q_max_ca_tags']);
		$universe_n = ca_get_universe_n($info['q_where']);
		$q_form = FORM_CA_REPORT_TABULATION;
		if ($list = qpl_ca_get_reviewers())
		{
			include (QPL_CA_REPORT_TABULATION_FORM);  
			exit;
		}
		else
			$comment = $qpl_error_message;
		break;

	case FORM_CA_WORDCOUNT_LIST_QUESTION:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Word count report cancelled.";
		}
		else
		{
			$comment = "No questions were selected.";
			reset($_POST);
			$num_ques = count($_POST['q_select']);
			$num = 0;
			$sql_where = "";
			$sql = "SELECT CONCAT(' '";
			$universe_n = ca_get_universe_n($info['q_where']);
			
			if (isset($_POST['q_select']))
			{
				if ($num_ques)
				{
					if ($_POST['q_select'][0] == '[all]')
					{
						$comment = "Words used in response to all STRING and OPENEND questions." ;
						
						if ($list = qpl_ca_get_question_list_for_word_count($info['q_max_ca_tags'], $num))
						{
							if ($num)
							{
								while ($data = qpl_db_fetch_array($list))
								{
									$sql .= ",IFNULL(" . $data['q_varname'] . ",''), ' '";
									$sql_where .= ($sql_where ? " OR " : "") . "LENGTH(" . $data['q_varname'] . ")";
								}
								qpl_db_free_result($list);
							}
							else
							{
								$comment = $qpl_error_message;
								break;
							}
						}
					}
					else
					{
						$comment = "Words used in response to question" . ($num_ques > 1 ? "s " : " ");
						for ($i = 0; $i < $num_ques; $i++)
						{
							$sql .= ",IFNULL(" . $_POST['q_select'][$i] . ",''), ' '";
							$sql_where .= ($i ? " OR " : "") . "LENGTH(" . $_POST['q_select'][$i] . ")";
							$comment .= ($i ? ", " : " ") . $_POST['q_select'][$i];
						}
					}
					
					$sql .= ") AS q_response FROM data WHERE (" . $info['q_where'] . ") AND ($sql_where)";
// echo $sql . "<br><br>";

					if (isset($q_stop_words))
						$q_stop_words = true;
					else
						$q_stop_words = false;
					
					$comment .= "<br>Minimum frequency: $q_min_count occurances<BR>Minimum word size: $q_min_chars characters<BR>Stop word list: " . ($q_stop_words ? "On" : "Off");
					if ($list = qpl_db_query($sql))
					{
							include (QPL_CA_WORDCOUNT_TABULATION_SUMMARY_FORM);
							exit;
					}
					else
						$comment = $qpl_error_message;
				}
			}
		}
		break;
	
	case FORM_CA_WORDCOUNT_TABULATION_SUMMARY:
		$comment = "Select on or more questions for word count analysis.";
		if ($list = qpl_ca_get_question_list_for_word_count($info['q_max_ca_tags'], $num))
		{
			if ($num)
			{
				include (QPL_CA_WORDCOUNT_LIST_QUESTION_FORM);
				exit;
			}
			else
				$comment = $qpl_error_message;
		}
		else
			$comment = $qpl_error_message;
		break;
	

	case FORM_CA_RECONCILE_REPORT_LIST_QUESTION:
	case FORM_CA_SUMMARY_REPORT_LIST_QUESTION:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "No questions were selected for report.";
		}
		else
		{
			$comment = "Select a group of responses to question $q_select for analysis.";
			
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_select))
			{
				if ($list2 = qpl_ca_get_reviewers())
				{
					$q_count = qpl_ca_get_question_n($info['q_max_ca_tags']);
					$universe_n = ca_get_universe_n($info['q_where']);
					
					if ($q_form == FORM_CA_RECONCILE_REPORT_LIST_QUESTION)
						$q_form = FORM_CA_RECONCILE_REPORT_SELECT_RESPONSES;
					else 
						$q_form = FORM_CA_SUMMARY_REPORT_SELECT_RESPONSES;
						
					include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);	// this form does double-duty with assign select responses!
					exit;
				}
				else 
					$comment = $qpl_error_message;
			}
			else
				$comment = $qpl_error_message;
		}
		break;
		
	case FORM_CA_RECONCILE_REPORT_SELECT_RESPONSES:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "No questions were selected for report.";
			$q_form = FORM_CA_RECONCILE_REPORT_LIST_QUESTION;
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num))
			{
				include (QPL_CA_ASSIGN_LIST_QUESTION_FORM);  // this for does double-duty for assign tags!
				exit;
			}
			else 
				$comment = $qpl_error_message;
		}
		else
		{
			// Build where clauses pieces..............................

			// $sql_reviewers_where..........................
			reset($_POST);
			$num = 0;
			$num_reviewers = 0;
			$name_reviewer = "";
			$sql_reviewers_where = "";
			$comment = "Tags: $q_tag_names<BR>";

			if (isset($_POST['q_uname']))
			{
				$comment .= "Reviewers: ";
				$num = count($_POST['q_uname']);
				$for_ques = "";

				if ($num)
				{
					if ($_POST['q_uname'][0] == '[all]' || $_POST['q_uname'][0] == '[none]')
						$comment .= "All<br>" ;
					
					else
					{
						$sql_reviewers_where = "(";
						$num_reviewers = $num;
						
						if ($num == 1)
							$name_reviewer = $_POST['q_uname'][0];
						for ($i = 0; $i < $num; $i++)
						{
							$sql_reviewers_where .= ($i ? " OR " : "") . "ca_assign.q_uname='" . $_POST['q_uname'][$i] . "'";
							$comment .= ($i ? ", " : " ") . $_POST['q_uname'][$i];
						}
						$sql_reviewers_where .= ")";
						$comment .= "<br>";
					}
				}
			}
			
			// $sql_nonblankcases_where...................................... 
			$sql_nonblankcases_where = "(";
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql_nonblankcases_where .= ($i ? " OR " : "") . "ca_assign.t$i";
			}
			$sql_nonblankcases_where .= ")";
			
			
			// $sql_varname_where.................................
			$sql_varname_where = "ca_assign.q_varname='$q_varname'";
			
			
			// 1. get temp table sumarizing agreement satus
			
			$sql = "CREATE TEMPORARY TABLE tmp_assign_agree SELECT q_id, IF(";
			
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ($i ? " AND " : "") . "MIN(t$i)=MAX(t$i)";
			}
			$sql .= ", 1, 0) AS 'q_agree', COUNT(*) AS 'q_num_reviewers' ";
			
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ", BIT_OR(t$i) AS t$i";
			}

			$sql .= " FROM ca_assign WHERE $sql_nonblankcases_where" . 
				($sql_reviewers_where ? " AND $sql_reviewers_where" : "") . 
				($sql_varname_where ? " AND $sql_varname_where" : "") . 
				" GROUP BY q_id" .
				($q_reconcile < 2 ?  " HAVING q_agree=$q_reconcile" : "");
			
			if ($q_reconcile == 0)
				$comment .= "Reconcile: Only disagree<br>";
			elseif ($q_reconcile == 1)	
				$comment .= "Reconcile: Only agree<br>";
			else
				$comment .= "Reconcile: All<br>";
			
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";

			// 2. get temp table selecting responses based on reviewer constraints
			
			
			$sql = "CREATE TEMPORARY TABLE tmp_assign_select
				SELECT DISTINCT 
					ca_assign.q_id,
					tmp_assign_agree.q_agree,
					tmp_assign_agree.q_num_reviewers
				FROM ca_assign, tmp_assign_agree";
			
			$sql_where = " WHERE ca_assign.q_id = tmp_assign_agree.q_id
					AND $sql_varname_where";

			// match_tags_where.........................
			
			$sql_where2 = "";
			reset($_POST);
			$num = 0;
			if (isset($_POST['t_tag']))
			{
				$num = count($_POST['t_tag']);
				$for_ques = "";
				
				if ($num)
				{
					if ($_POST['t_tag'][0] == '[any]' || $_POST['t_tag'][0] == '[none]')
						/* do nothing */;

					else
					{
						$sql_where .=  (mb_strlen($sql_where) ? " AND " : "") . "(";
						for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
						{
							$sql_where2 .= (mb_strlen($sql_where2) ? " OR " : "") . "tmp_assign_agree.t$i & @t$i";
						}
						$sql_where .= $sql_where2 . ")";
					}
					
					if ($sql_where2) // set bit masks
					{
						// initialize sql variables
						$sql2 = "SET ";
						for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
						{
							$sql2 .= ($i ? ", " : "") . "@t$i = 0";
						}
						qpl_db_query($sql2) or
							qpl_db_log($qpl_error_message);

						// set tag bits on sql variables
						
						for ($i = 0; $i < $num; $i++)
						{
							qpl_ca_get_tag_mask($info['q_max_ca_tags'], $_POST['t_tag'][$i], $block, $mask);
							$sql2 =  "SET @$block = @$block | CONV('$mask', 2, 10)";
							qpl_db_query($sql2) or
								qpl_db_log($qpl_error_message);
//echo $sql2 . "<br><br>";
						}
					}
				}
			}
			
			// your_comment_where.......................

			if (isset($q_your_comment) && mb_strlen(trim($q_your_comment)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_your_comment, "ca_assign.a_comment");
				$comment .= "Reviewer comment: " . htmlspecialchars($q_your_comment) . "<BR>";
			}

			// range of id numbers
			if (isset($q_id_low) && preg_match('/^[0-9]+$/', $q_id_low))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "tmp_assign_agree.q_id >=$q_id_low";
					$comment .= "Lowest case id: $q_id_low<br>";
			}

			if (isset($q_id_high) && preg_match('/^[0-9]+$/', $q_id_high))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "tmp_assign_agree.q_id <=$q_id_high";
					$comment .= "Highest case id: $q_id_high<br>";
			}


			$sql .= $sql_where;
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
//echo $sql . "<br><br>";
				
			// 3. merge reviewer tag info and respondent comments...
			
			$sql = "SELECT 
				data.q_id,
				data.q_uname,
				data.$q_varname AS 'q_response',
				data." . $info['q_select_case'] . " AS 'info_q_varname', 
				tmp_assign_select.q_agree,
				tmp_assign_select.q_num_reviewers, 
				ca_assign.q_uname AS r_uname, 
				ca_assign.a_comment," .
				qpl_ca_tag_make_set($info['q_max_ca_tags'], "ca_assign") . "
			FROM data, tmp_assign_select, ca_assign ";
				
			$sql_where = "WHERE 
				data.q_id=tmp_assign_select.q_id  
				AND data.q_id=ca_assign.q_id 
				AND $sql_nonblankcases_where " .
				($sql_reviewers_where ? " AND $sql_reviewers_where" : "") . 
				($sql_varname_where ? " AND $sql_varname_where" : "") . 
				(isset($q_blanks) ? " AND LENGTH(data.$q_varname)" : "");
				
			if (isset($q_response) && mb_strlen(trim($q_response)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_response, "data.$q_varname");
				$comment .= "Words in response: " . htmlspecialchars($q_response) . "<BR>";
			}

			if (isset($r_uname) && mb_strlen(trim($r_uname)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "data.q_uname = '" . trim($r_uname) . "'";
				$comment .= "Respondent user name: " . htmlspecialchars($r_uname) . "<BR>";
			}

			if (isset($q_blanks))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "LENGTH(data.$q_varname)";
					$comment .= "Exclude blank responses<br>";
			}

			if (isset($q_id_text) && mb_strlen(trim($q_id_text)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_id_text, "data." . $info['q_select_case']);
				$comment .= "Case id text includes: $q_id_text<br>";
			}
	
			
			// Add tabulation report and file export WHERE clause..
			
			if ($info['q_where'])
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "(" . $info['q_where'] . ")";
			}
			
			
			$sql .= $sql_where;   // need to add the other where and order by stuff...
			$sql .= " ORDER BY " . $q_sort;
			
			if (isset($q_limit) && $q_limit > 0)
				$sql .= " LIMIT $q_limit";
			else 
				$sql .= " LIMIT " . CA_MAX_LIST_RESPONSES;
				
			$comment .= "Maximum number of cases in report: $q_limit<br>";

// echo $sql . "<br><br>";
 
			
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
			{
				if ($list2 = qpl_db_query($sql))
				{
					if ($num)
					{
						include (QPL_CA_RECONCILE_REPORT_LIST_RESPONSES_FORM);
						exit;
					}
					else
					{
						$comment = "No cases were selected.<br><STRONG>($sql_where)</STRONG>";
						if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
						{
							$q_form = FORM_CA_RECONCILE_REPORT_SELECT_RESPONSES;
							include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);
							exit;
						}
						else
							$comment = $qpl_error_message;
					}
				}
				else
					$comment = $qpl_error_message;
			}
			else
				$comment = $qpl_error_message;
		}
		break;
		
	case FORM_CA_RECONCILE_REPORT_LIST_RESPONSES:
	case FORM_CA_SUMMARY_REPORT_LIST_RESPONSES:
		$comment = "Select a group of responses to question $q_varname for analysis.";
			
		if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
		{
			if ($list2 = qpl_ca_get_reviewers())
			{
				$q_count = qpl_ca_get_question_n($info['q_max_ca_tags']);
				$universe_n = ca_get_universe_n($info['q_where']);
				if ($q_form == FORM_CA_RECONCILE_REPORT_LIST_RESPONSES)
					$q_form = FORM_CA_RECONCILE_REPORT_SELECT_RESPONSES;
				else
					$q_form = FORM_CA_SUMMARY_REPORT_SELECT_RESPONSES;
				include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);	// this form does double-duty with assign select responses!
				exit;
			}
			else 
				$comment = $qpl_error_message;
		}
		else
			$comment = $qpl_error_message;
			
		break;


	case FORM_CA_SUMMARY_REPORT_SELECT_RESPONSES:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "No questions were selected for report.";
			$q_form = FORM_CA_SUMMARY_REPORT_LIST_QUESTION;
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num))
			{
				include (QPL_CA_ASSIGN_LIST_QUESTION_FORM);  // this for does double-duty for assign tags!
				exit;
			}
			else 
				$comment = $qpl_error_message;
		}
		else
		{
			// Build where clauses pieces..............................

			// $sql_reviewers_where..........................
			reset($_POST);
			$num = 0;
			$num_reviewers = 0;
			$name_reviewer = "";
			$sql_reviewers_where = "";
			$sql_comment_where = "";
			$comment = "Tags: $q_tag_names<BR>";
			if (isset($_POST['q_uname']))
			{
				$comment .= "Reviewers: ";
				$num = count($_POST['q_uname']);
				$for_ques = "";

				if ($num)
				{
					if ($_POST['q_uname'][0] == '[all]' || $_POST['q_uname'][0] == '[none]')
						$comment .= "All<br>" ;
					
					else
					{
						$sql_reviewers_where = "(";
						$num_reviewers = $num;
						
						if ($num == 1)
							$name_reviewer = $_POST['q_uname'][0];
						for ($i = 0; $i < $num; $i++)
						{
							$sql_reviewers_where .= ($i ? " OR " : "") . "ca_assign.q_uname='" . $_POST['q_uname'][$i] . "'";
							$comment .= ($i ? ", " : " ") . $_POST['q_uname'][$i];
						}
						$sql_reviewers_where .= ")";
						$comment .= "<br>";
					}
				}
			}
			
			// $sql_nonblankcases_where...................................... 
			$sql_nonblankcases_where = "(";
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql_nonblankcases_where .= ($i ? " OR " : "") . "ca_assign.t$i";
			}
			$sql_nonblankcases_where .= ")";
			
			
			// $sql_varname_where.................................
			$sql_varname_where = "ca_assign.q_varname='$q_varname'";
			
			// your_comment_where....................... 2012-07-30 kbd

			if (isset($q_your_comment) && mb_strlen(trim($q_your_comment)))
			{
				$sql_comment_where .= qpl_ca_make_like_clause($q_your_comment, "ca_assign.a_comment");
				$comment .= "Reviewer comment: " . htmlspecialchars($q_your_comment) . "<BR>";
			}
			
			// 1. get temp table sumarizing agreement satus
			
			$sql = "CREATE TEMPORARY TABLE tmp_assign_agree SELECT q_id, IF(";
			
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ($i ? " AND " : "") . "MIN(t$i)=MAX(t$i)";
			}
			$sql .= ", 1, 0) AS 'q_agree', COUNT(*) AS 'q_num_reviewers' ";
			
			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ", " . ($q_reconcile ? "BIT_OR" : "BIT_AND" ) . "(t$i) AS t$i";
			}

			$sql .= " FROM ca_assign WHERE $sql_nonblankcases_where" . 
				($sql_reviewers_where ? " AND $sql_reviewers_where" : "") . 
				($sql_varname_where ? " AND $sql_varname_where" : "") . 
				($sql_comment_where ? " AND $sql_comment_where" : "") . 
				" GROUP BY q_id";
			
			if ($q_reconcile)
				$comment .= "Reconcile: Union<br>";
			else
				$comment .= "Reconcile: Intersection<br>";
			
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);

//$comment .= "<BR>1. Reconcile: $sql<BR>";

			// 2. get temp table selecting responses based on reviewer constraints
			
			$sql = "CREATE TEMPORARY TABLE tmp_assign_select
				SELECT DISTINCT 
					ca_assign.q_id,
					tmp_assign_agree.q_agree,
					tmp_assign_agree.q_num_reviewers";

			for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
			{
				$sql .= ", tmp_assign_agree.t$i";
			}
			
			$sql .= " FROM ca_assign, tmp_assign_agree";
			
			$sql_where = " WHERE ca_assign.q_id = tmp_assign_agree.q_id
					AND $sql_varname_where";

			// match_tags_where.........................
			
			$sql_where2 = "";
			reset($_POST);
			$num = 0;
			if (isset($_POST['t_tag']))
			{
				$num = count($_POST['t_tag']);
				$for_ques = "";
				
				if ($num)
				{
					if ($_POST['t_tag'][0] == '[any]' || $_POST['t_tag'][0] == '[none]')
						/* do nothing */;

					else
					{
						$sql_where .=  (mb_strlen($sql_where) ? " AND " : "") . "(";
						for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
						{
							$sql_where2 .= (mb_strlen($sql_where2) ? " OR " : "") . "tmp_assign_agree.t$i & @t$i";
						}
						$sql_where .= $sql_where2 . ")";
					}
					
					if ($sql_where2) // set bit masks
					{
						// initialize sql variables
						$sql2 = "SET ";
						for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
						{
							$sql2 .= ($i ? ", " : "") . "@t$i = 0";
						}
						qpl_db_query($sql2) or
							qpl_db_log($qpl_error_message);

						// set tag bits on sql variables
						for ($i = 0; $i < $num; $i++)
						{
							qpl_ca_get_tag_mask($info['q_max_ca_tags'], $_POST['t_tag'][$i], $block, $mask);
							$sql2 =  "SET @$block = @$block | CONV('$mask', 2, 10)";
							qpl_db_query($sql2) or
								qpl_db_log($qpl_error_message);
//echo $sql2 . "<br><br>";
						}
					}
				}
			}
			

			$sql .= $sql_where;
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
//$comment .= "<BR>2. Temp table selecting responses based on reviewer constraints: $sql <br><br>";

			// 3. merge reviewer tag info and respondent comments...
				
			$sql = "SELECT 
				data.q_id,
				data.q_uname,
				data.$q_varname AS 'q_response', 
				data." . $info['q_select_case'] . " AS 'info_q_varname', 
				tmp_assign_select.q_agree,
				tmp_assign_select.q_num_reviewers, " .
				qpl_ca_tag_make_set($info['q_max_ca_tags'], "tmp_assign_select") . "
			FROM data LEFT JOIN tmp_assign_select ON data.q_id=tmp_assign_select.q_id ";
				
			$sql_where = "";

			
			if (isset($q_response) && mb_strlen(trim($q_response)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_response, "data.$q_varname");
				$comment .= "Words in response: " . htmlspecialchars($q_response) . "<BR>";
			}

			if (isset($r_uname) && mb_strlen(trim($r_uname)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "data.q_uname = '" . trim($r_uname) . "'";
				$comment .= "Respondent user name: " . htmlspecialchars($r_uname) . "<BR>";
			}

			if (isset($q_blanks))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "LENGTH(data.$q_varname)";
					$comment .= "Exclude blank responses<br>";
			}

			if ($_POST['t_tag'][0] == '[any]')
				/* do nothing */ ;
			elseif($_POST['t_tag'][0] == '[none]')
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "tmp_assign_select.t0 IS NULL";
			else 
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "tmp_assign_select.t0 IS NOT NULL";

			// select based on review comment 2012-07-31 kbd
			if(isset($q_your_comment) && mb_strlen($q_your_comment))
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "tmp_assign_select.q_id IS NOT NULL";
				
			// range of id numbers
			if (isset($q_id_low) && preg_match('/^[0-9]+$/', $q_id_low))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "data.q_id >=$q_id_low";
					$comment .= "Lowest case id: $q_id_low<br>";
			}

			if (isset($q_id_high) && preg_match('/^[0-9]+$/', $q_id_high))
			{
					$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "data.q_id <=$q_id_high";
					$comment .= "Highest case id: $q_id_high<br>";
			}

			if (isset($q_id_text) && mb_strlen(trim($q_id_text)))
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . qpl_ca_make_like_clause($q_id_text, "data." . $info['q_select_case']);
				$comment .= "Case id text includes: $q_id_text<br>";
			}

			// Add tabulation report and file export WHERE clause..
			if ($info['q_where'])
			{
				$sql_where .= (mb_strlen($sql_where) ? " AND " : "") . "(" . $info['q_where'] . ")";
			}
			
			$sql .= ($sql_where ? " WHERE $sql_where" : ""); 

			$sql .= " ORDER BY " . $q_sort;
			
			if (isset($q_limit) && $q_limit > 0)
				$sql .= " LIMIT $q_limit";
			else 
				$sql .= " LIMIT " . CA_MAX_LIST_RESPONSES;
				
			$comment .= "Maximum number of cases in report: $q_limit<br>";
//$comment .= "<BR> 3. Merge tag and respondent info: $sql<br>";
			
			if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
			{
				if ($list2 = qpl_db_query($sql))
				{
					if ($num)
					{
						include (QPL_CA_SUMMARY_REPORT_LIST_RESPONSES_FORM);
						exit;
					}
					else
					{
						$comment = "No cases were selected.<BR><STRONG>($sql_where)</STRONG>";
						if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num, $q_varname))
						{
							$q_form = FORM_CA_SUMMARY_REPORT_SELECT_RESPONSES;
							include (QPL_CA_ASSIGN_SELECT_RESPONSES_FORM);
							exit;
						}
						else
							$comment = $qpl_error_message;
					}
				}
				else
					$comment = $qpl_error_message;
			}
			else
				$comment = $qpl_error_message;
		}
		break;
		
	case FORM_CA_DELEGATE_ADMIN_PERMISSIONS:
		if ($q_submit == FRM_CANCEL)
			$comment = "No administrator permissions were changed.";
		else 
		{
			$comment = "All Administrator content analysis permissions removed.\n";
			$perm_label = array("Define topic tags", "Reconciliation report", "Summary report");
			// clear old permissions...
			
			$sql = "UPDATE user SET q_ca_permissions=0 WHERE q_user_status=" . USER_ADMIN ;
			qpl_db_query($sql) or
				qpl_db_log($qpl_error_message);
			
			reset($_POST);
			for ($perm = 0; $perm < 3; $perm++)
			{
				if (isset($_POST["perm$perm"]))
				{
					$num_reviewers = count($_POST["perm$perm"]);

					if ($num_reviewers)
					{
						$comment .= $perm_label[$perm] . " permission granted to:";
						$sql_where = "";
						for ($i = 0 ; $i < $num_reviewers; $i++)
						{
							$sql_where .= ($i ? " OR " : "") . "q_uname='" . $_POST["perm$perm"][$i] . "'";
							$comment .= " " . $_POST["perm$perm"][$i];
						}
						$comment .= ".\n";
						
						$mask = substr_replace(str_repeat("0", 8), "1", $perm, 1);
						
						$sql = "UPDATE user SET q_ca_permissions = q_ca_permissions | CONV('$mask', 2, 10) WHERE $sql_where";
						qpl_db_query($sql) or
							qpl_db_log($qpl_error_message);
					}
				}
			}
			qpl_db_log($comment, LOGIN_OK);
			$comment = nl2br($comment);
		}	
		break;
	
	case FORM_EXPORT_TAB_DATA:
		if ($q_submit == FRM_CANCEL)
			$comment = "";
		else 
		{
		
			if (!isset($qpl_from))
				$qpl_from = 'data';
				
			if ($q_select)
			{
				if ($qpl_from == 'data')
				{
					$q_sourcefile = $info['q_project'] . "-raw.prn";
					$q_where = $info['q_where'];
				}
				else if ($qpl_from == 'ddata')
				{
					$q_sourcefile = $info['q_project'] . "-dirty.prn";
					$q_where = $info['q_where'];
				}
				else
				{
					$q_sourcefile = $info['q_project'] . "-clean.prn";
					$q_where = str_replace("data.", "cdata.", $info['q_where']);
				}

				$rows = qpl_db_make_tab_file($q_sourcefile, $q_select, $q_where, $qpl_from);
				$comment = "";
				if ($rows > 0)
				{
					qpl_db_log("Exported tab delimited file: $q_sourcefile ($rows records)", LOGIN_OK);
					if (qpl_direct_download(DATA_PATH, $q_sourcefile))
						exit;
					else 
						$comment = $qpl_error_message;
				}
				else
					$comment = $qpl_error_message;
			}
			else 
				$comment = "No system variables or questions were selected for tab-delmited export file.";
			
		}
		break;

		
		
	case FORM_CA_COHENS_KAPPA:
	
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Action cancelled.";
		}
		else
		{
			$comment = "Calculated for reviewers ";
			reset($_POST);
			$num = 0;
			$num_reviewers = 0;
			$name_reviewer = array();
			$sql_where = "";
			
			$q_universe_n = ca_get_universe_n($info['q_where']);
			
			if (isset($_POST['q_uname']))
			{
				$num_reviewers = count($_POST['q_uname']);
				$for_ques = "";

				if ($num_reviewers == 2)
				{
					$sql_where = "(";
					for ($i = 0; $i < $num_reviewers; $i++)
					{
						$sql_where .= ($i ? " OR " : "") . "q_uname='" . $_POST['q_uname'][$i] . "'";
						$comment .= ($i ? " and " : " ") . $_POST['q_uname'][$i];
						$name_reviewer[$i] =  $_POST['q_uname'][$i];
					}
					$sql_where .= ")";
					$comment .= ".";
				
					$sql_where .= ($sql_where ? " AND (" : "(");
					for ($i = 0; $i < ($info['q_max_ca_tags'] / CA_BITS_PER_INT); $i++)
					{
						$sql_where .= ($i ? " OR " : "") . "t$i";
					}
					$sql_where .= ")";
			
					$sql = "SELECT q_id, q_varname, q_uname, " . qpl_ca_tag_make_set($info['q_max_ca_tags'], "ca_assign") .
						" FROM ca_assign WHERE $sql_where ORDER BY q_varname, q_id, q_uname";
// echo $sql . "<br><br>";
				
					if ($list = qpl_ca_get_question_list($info['q_max_ca_tags'], $num))	
					{
						if ($list2 = qpl_db_query($sql))
						{
							include(QPL_CA_STAT_COHENS_KAPPA);
							exit;
						}
						else
							$comment = $qpl_error_message;
					}
					else
						$comment = $qpl_error_message;
				}
				else 
					$comment = "Two reviewers must be selected for Cohen's Kappa calculation.";
			}
			else 
				$comment = "Two reviewers must be selected for Cohen's Kappa calculation.";
		}
		break;

	case FORM_CA_COHENS_KAPPA_SUMMARY:
		$comment = "Select two reviewers for reliability calculations.";
		$q_count = qpl_ca_get_question_n($info['q_max_ca_tags']);
		$universe_n = ca_get_universe_n($info['q_where']);
		$q_form = FORM_CA_COHENS_KAPPA;
		if ($list = qpl_ca_get_reviewers())
		{
			include (QPL_CA_REPORT_TABULATION_FORM);  // this form does double-duty for tabulation and export!
			exit;
		}
		else
			$comment = $qpl_error_message;
		break;
		
		
	case FORM_EXPORT_FIXED_DATA:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Action cancelled.";
		}
		else
		{
			if (!isset($qpl_from))
				$qpl_from = 'data';
				
			
			if ($qpl_from == 'data')
			{
				$q_sourcefile = $info['q_project'] . "-raw.dat";
				$q_where = $info['q_where'];
			}
			else if ($qpl_from == 'ddata')
			{
				$q_sourcefile = $info['q_project'] . "-dirty.dat";
				$q_where = $info['q_where'];
			}
			else
			{
				$q_sourcefile = $info['q_project'] . "-clean.dat";
				$q_where = str_replace("data.", "cdata.", $info['q_where']);
			}
			
			$rows = qpl_db_make_fixed_file($q_sourcefile, $q_where, $qpl_sys_vars, $qpl_from);
			$comment = "Fixed format";
			if ($rows)
			{
				qpl_db_log("Exported fixed-format file: $q_sourcefile ($rows records)", LOGIN_OK);
				if (qpl_direct_download(DATA_PATH, $q_sourcefile))
					exit;
				else 
					$comment = $qpl_error_message;
			}
			else
				$comment = $qpl_error_message;
		}
		break;


	case FORM_ADMIN_USER_VIEW_UPLOADS:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Action cancelled.";
			
			// restart user list page
			$find = qpl_find_user_query($q_uname)
				or qpl_db_log($qpl_error_message);
			$list = qpl_db_list_users($find['uf_sql'], "LIMIT " . $find['uf_limit'] . " ", $num_users);
			if ($list)
			{
				$comment .= "Total user accounts: $num_users";
				include (QPL_ADMIN_USER_FORM);
				exit;
			}
			else
			{
				$comment .= "No matching user accounts found.";
				include (QPL_ADMIN_USER_FIND_FORM);
				exit;
			}
		}
		else
		{
			$comment = "Downloading $q_select_outfilename";
			if ($q_select_q_up_file_to_db)
			{
				if (qpl_db_make_dumpfile($q_select_outfileid, $q_select_outfilename))
				{
					qpl_db_log("Downloading from fdata f_id $q_select_outfileid ($q_select_outfilename)", LOGIN_OK);
					
					if (qpl_direct_download(DATA_PATH, $q_select_outfilename))
						exit;
					else
					{
						$comment = $qpl_error_message;
						qpl_db_log($comment, LOGIN_OK);
					}
				}
				else
				{
					$comment = $qpl_error_message;
					qpl_db_log($comment, LOGIN_OK);
				}
			}
			else
			{
				qpl_db_log("Downloading from " . UPLOADED_FILE_PATH . $q_select_outfilename, LOGIN_OK);
				
				if (qpl_direct_download(UPLOADED_FILE_PATH, $q_select_outfilename))
					exit;
				else 
				{
					$comment = $qpl_error_message;
					qpl_db_log($comment, LOGIN_OK);
				}
			}
		}
		break;

	case FORM_REPORT_LIST:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Reports not changed.";
		}
		else
		{
			if ($r_id == 0)
			{
				$r_id = qpl_report_add_new($q_uname)
					or qpl_db_log($qpl_error_message);
				$comment = "Enter query for new report. (Do not include 'SELECT' at start of query.)";
			}
			else
				$comment = "Update query for existing report.";
				
			$report = qpl_report_get_report($r_id)
				or qpl_db_log($qpl_error_message);
			include (QPL_REPORT_EDIT_FORM);
			exit;
		}
		break;

	case QPL_REPORT_EDIT_FORM:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "Report not changed.";
		}
		else
		{
			$r_title = trim($r_title);
			$r_sql = trim($r_sql);
			if (substr_compare($r_sql, "SELECT", 0, 6, TRUE) == 0)
				$r_sql = trim(mb_substr($r_sql, 6));

			$sql = "UPDATE report SET 
				r_title ='" . qpl_addslashes($r_title ) . "', 
				r_sql='" . qpl_addslashes($r_sql) . "',
				r_set='" . qpl_addslashes(trim($r_set)) . "', 
				r_font='" . (isset($r_font) ? 1 : 0) . "', 
				r_html='" . (isset($r_html) ? 1 : 0) . "', 
				r_nl2br='" . (isset($r_nl2br) ? 1 : 0) . "', 
				r_layout='" . (isset($r_layout) ? 1 : 0) . "', 
				r_stat='" . (isset($r_stat) ? 1 : 0) . "', 
				q_user_status='$q_user_status' 
				WHERE r_id=$r_id";

			qpl_db_query($sql)
				or qpl_db_log($qpl_error_message);
			qpl_db_log("Report '$r_title' updated", LOGIN_OK);
		
			$comment .= "The <B>$r_title</B> report has been updated.";
			
			if (isset($r_stat) && mb_substr($r_sql, 0, 1) != '*')
				$comment .= "<BR><BR><B>Warning!</B> Queries using the statistical summary output option must start with * to select all columns.";
			
		}		

		if ($list = qpl_report_get_list())
		{
			include (QPL_REPORT_LIST_FORM);
			exit;
		}
		else
			$comment = $qpl_error_message;
		break;
		
	case FORM_MAIL_ADMINISTRATORS:
		if ($q_submit == FRM_CANCEL)
		{
			$comment = "No messages were sent to administrators.";
		}
		else
		{
			if (qpl_validate_email($q_from, false))
			{
				if (mb_strlen($q_select))
				{
					$q_comments = stripslashes($q_comments);
					$comment = qpl_send_mail_to_admins($q_select, $q_title, $q_from, $q_comments);
				}
				else
					$comment = "No administrators were selected for mailing.";
			}
			else
			{
				$comment = "From: email address is invalid or missing: $q_from";
			}
		}
		break;
		
		
	default:
		qpl_db_log("Unknown form submitted: " . $q_form);

		
}
$info = qpl_db_get_info(false)	// don't check http_referer
	or qpl_db_log($qpl_error_message);

$summary = qpl_db_project_summary()
	or qpl_db_log($qpl_error_message);
	
$reports = qpl_report_get_available_list($user['q_user_status'])
	or qpl_db_log($qpl_error_message);

$numreports = qpl_db_num_rows($reports);

include (QPL_ADMIN_MAIN_FORM);
exit;


?>
