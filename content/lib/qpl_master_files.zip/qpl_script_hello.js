/* qpl_script_hello.js
 * K. Dooley
 *
 * JavaScript routines for QPL hello.htm and index.htm pages.
 */
 
function forceLogin()
{
     if (document.QPL['q_forcelogin'].value == 0)
     {
          document.QPL['q_forcelogin'].value = 1;
          window.status = 'Force login...';
     }
     else
     {
          document.QPL['q_forcelogin'].value = 0;
          window.status = '';
     }
     return false;
}

/* PageToOpen= HTML -> main.htm, PHP -> qpl_loading_form.htm */

function openQplMainWin(PageToOpen, Width)
{
     var Options;
     var qplwinmain;
     Options  = 'dependent=no,resizable,scrollbars,status,';
     if (document.QPL.q_javascript.value >= 1.2)
     {
        Options += 'width='  + (screen.availWidth  <= 800 ? screen.width-10  : Width) + ',';
        Options += 'height=' + (screen.availHeight-60) + ',';
     }
     else
     {
        Options += 'width=' + Width + ',';
        Options += 'height=540,';
     }
     Options += 'left=0,top=0,screenX=0,screenY=0';
     qplwinmain = window.open(PageToOpen, 'QPLMAINWIN', Options);
     qplwinmain.focus();
     return qplwinmain;
}

/////////////////////////////////////////////////////////////////////
// Pop-Up window utility function
// Call from a .pgm file using an anchor tag...
//
// (See \<a href=\"javascript:PopUp('definitions.htm', 400, 300);\"\>definitions\</a\>.)
//
// Also need to escape all special HTML characters! and where the content
// is in a simple HTML file..
//

var popupWindow = null;
function PopUp(targetfile, height, width)
{
	if (popupWindow != null) 
		popupWindow.close();

	popupWindow = window.open(targetfile, 'QPLPOPUPWIN', 
		"width=" + (width < 100 ? 100 : width) + 
		",height=" + (height < 100 ? 100 : height) + 
		",scrollbars,left=10,top=10,screenX=10,screenY=10", true); 
	    
	popupWindow.focus();
}
