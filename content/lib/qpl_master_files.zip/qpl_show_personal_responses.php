<?php
// qpl_show_personal_responses.php
// K. Dooley
// Calls the job.inc file to generate a tabulation report for just this one respondent.
// get standard database functions. Must be called with GET q_sess_id argument
// set (use the JavaScript showPersonalResponses() function in qpl_script.js via a
// link in the .pgm file:
//
// Click \<a href=\"javascript:showPersonalResponses(width, language);\" title=\"View response summary\"\>here\</a\> to view a summary of your current responses.
//

include_once 'qpl_config.inc';
$q_language = "";
if (isset($_GET['q_language']))
{
	if (preg_match('/^\.[a-z]{2}(-[A-Za-z]+)?(-[A-Za-z]+)?$/', $_GET['q_language']))
	{
		$q_language = $_GET['q_language'];
	}
	elseif (mb_strlen($_GET['q_language']) > 0)
	{
		$q_comment .= "<BR>A system error has occured.";
		include(QPL_ERROR_FORM);
		exit;
	}
}
include_once QPL_JOB . $q_language;
include_once QPL_DB_FUNCS;


isset($_GET['q_sess_id']) or
	qpl_db_log("Cannot identify your session.  Please launch questionnaire from the project home page.");

qpl_db_connect($q_job)
	or qpl_db_log($qpl_error_message);

if (($session = qpl_db_get_sess($_GET['q_sess_id'], SESS_KEEP)) <= 0)
	qpl_db_log($qpl_error_message);

$info = qpl_db_get_info(false)	// don't check http_referer
	or qpl_db_log($qpl_error_message);

$q_uname = qpl_addslashes($session['q_uname']);
$q_javascript = $session['q_javascript'];
$q_id = $session['q_id'];

$user = qpl_db_get_user($q_uname)
	or qpl_db_log($qpl_error_message);
	
$sql = "SELECT * FROM data WHERE q_id=$q_id"; 
	
if (!($list = qpl_db_query($sql)))
{
	qpl_db_log("Cannot find your data.  Please launch questionnaire from the project home page.");
}
$num = qpl_db_num_rows($list);

if ($num == 0)
{
	qpl_db_log("Cannot find your data.  Please launch questionnaire from the project home page.");
}

qpl_db_log("View response summary", LOGIN_OK);

$comment = "<B>Summary of responses for " . $user['q_name'] . ".</B><BR>User: " . $user['q_uname'] . "<BR>Record: $q_id<BR>Date: "
	. date("l, F j, Y g:i a T");
$qpl_show_personal_responses = true;

if ($info['q_show_personal_response_method'] == 1)
{
	$response = qpl_db_fetch_array($list);
	include ($q_personal_summary_stats);
}
else
{
	include ($q_summary_stats);
}

?>
