<?php
// qpl_login.php
// K. Dooley
//
// Central login point for all types of logins. 
//

// Get configuation constants and standard functions
include_once 'qpl_config.inc';
$q_language = "";
if (isset($_POST['q_language']))
{
	if (preg_match('/^\.[a-z]{2}(-[A-Za-z]+)?(-[A-Za-z]+)?$/', $_POST['q_language']))
	{
		$q_language = $_POST['q_language'];
	}
	elseif (mb_strlen($_POST['q_language']) > 0)
	{
		$q_comment .= "<BR>A system error has occured.";
		include(QPL_ERROR_FORM);
		exit;
	}
}
include_once QPL_JOB . $q_language;
include_once QPL_DB_FUNCS;

// Check that system is enabled (setting from qpl_config.inc)

if ($DisableSystem)
{
	$q_comment = $DisableSystemComment;
	include(QPL_ERROR_FORM);
	exit;
}

// Check for GET variables
$q_form = "";
if (isset($_GET['u'])) // using URL GET login option, for example: http://localhost/~dooleyk/test31/qpl_login.php?u=test1&p=changeme
	$q_form = FORM_LOGIN_GET;

else if (isset($_GET['s']))
	$q_form = FORM_JUMP_GET;
	
else if (isset($_POST['q_form']))
	$q_form = $_POST['q_form'];

if( !($q_form == FORM_HELLO  || 
			$q_form == FORM_LOGIN || 
			$q_form == FORM_NEWUSER || 
			$q_form == FORM_SELECT || 
			$q_form == FORM_LOGIN_GET ||
			$q_form == FORM_JUMP_GET ) ) 
		qpl_db_log("You must log in before accessing your questionnaire.  Please start the questionnaire from the URL that was emailed to you. ");

$q_from_q_varname = "";
$q_from_q_id = 0;
$q_from_db = "";

// Capture respondent device dimensions on on qpl_login_form.inc for qpl_db_log() 
$q_width = 0;
$q_height = 0;
$q_colorDepth = 0;
$q_pixelDepth = 0;
$q_availWidth = 0;
$q_availHeight = 0;

if (isset($_POST['q_width']) && is_numeric($_POST['q_width']))
	$q_width = $_POST['q_width'];

if (isset($_POST['q_height']) && is_numeric($_POST['q_height']))
	$q_height = $_POST['q_height'];

if (isset($_POST['q_colorDepth']) && is_numeric($_POST['q_colorDepth']))
	$q_colorDepth = $_POST['q_colorDepth'];

if (isset($_POST['q_pixelDepth']) && is_numeric($_POST['q_pixelDepth']))
	$q_pixelDepth = $_POST['q_pixelDepth'];

if (isset($_POST['q_availWidth']) && is_numeric($_POST['q_availWidth']))
	$q_availWidth = $_POST['q_availWidth'];

if (isset($_POST['q_availHeight']) && is_numeric($_POST['q_availHeight']))
	$q_availHeight = $_POST['q_availHeight'];

if ($comment)	// can't find MySQL username and password in qpl_config.inc
	qpl_db_log($comment);

qpl_db_connect($q_job)
	or qpl_db_log($qpl_error_message);
	
$info = qpl_db_get_info()
	or qpl_db_log($qpl_error_message);

if (isset($_POST['q_sess_id']))
	$q_sess_id = $_POST['q_sess_id'];


$q_url = isset($info['q_url']) ? $info['q_url'] : ($_SERVER["SERVER_PORT"] == 80 ? "http://" : "https://") . $_SERVER["SERVER_NAME"] . rtrim(dirname($_SERVER['PHP_SELF']), '/\\') . "/" ;


$q_forcelogin = 0;
if( isset($_POST['q_forcelogin']) )
{
	if( $_POST['q_forcelogin'] == 0 || $_POST['q_forcelogin'] == 1)
		$q_forcelogin = $_POST['q_forcelogin'];
}

if (!isset($q_submit))
	$q_submit = "";

// check for JavaScript - just presuming at least 1.5 now... 
$q_javascript = 1.5;


// process each form
switch ($q_form)
{
	case FORM_HELLO:		// coming from hello screen, need to launch appropriate login screen
		if ($info["q_login_type"] == LOGIN_NAME_NONE && !$q_forcelogin)
		{
			if (isset($info['q_expire']))
			{
				if (date("Y-m-d") > $info['q_expire'] )
					qpl_db_log("Today is " . date("Y-m-d") . ". This project expired on " . $info['q_expire'] . ".");
			}

			$q_uname = USER_NONE;
			$q_group = GROUP_NONE;
			$q_id = qpl_db_add_new_record($q_uname,	$q_group)
				or qpl_db_log($qpl_error_message);
			qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);	
			$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, 0, 0)
				or qpl_db_log($qpl_error_message);
			qpl_db_syslog($info['q_project'], $q_uname, "Anonymous respondent logged in (h:$q_height w:$q_width)");
			include ($q_questionnaire);	// launch new questionnaire record; uses: q_job, q_sess_id, q_id (for display only)
			exit;
		}
		else
		{
			$comment = $ERTable[384]; // Please enter your user name and password.
			
			$q_uname = "";
			include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
			exit;
		}	
		break;
		
	case FORM_LOGIN:
		$q_uname = mb_strtolower(qpl_addslashes($_POST['q_uname']));
		$q_pswd = qpl_addslashes($_POST['q_pswd']);
		$q_group = GROUP_NONE;
		$q_new_account = 1;

		
		// lookup account
		if ($user = qpl_db_get_user($q_uname))
		{
			$q_new_account = 0;
			$q_name = $user['q_name'];
			$q_group = $user['q_group'];
			$q_user_status = $user['q_user_status'];
			$q_email = $user['q_email'];
			$q_phone = $user['q_phone'];
			$q_login_pswd_chng_count = (isset($user['q_login_pswd_chng_count']) ? $user['q_login_pswd_chng_count'] : 1);

			// clear any previous jumps to here from another questionnaire (that didn't get cleared with a proper exit) 
			if ($user['q_from_q_id'] > 0)
			{
				$sql = "UPDATE user SET q_from_q_id=0, q_from_url=NULL, q_from_db=NULL WHERE q_uname='$q_uname'";
				$result = qpl_db_query($sql)
					or qpl_db_log($qpl_error_message);
			}

			// account has expired?
			if (isset($user['q_expire']) && $q_user_status < USER_MANAGER)
			{
				if (date("Y-m-d") > $user['q_expire'] )
					qpl_db_log("Today is " . date("Y-m-d") . ". Your account '" . $q_uname . "' expired on " . $user['q_expire'] . ".");
			}

			// account closed due to excessive failed logins?
			if ($user['q_num_bad_logins'] > $info['q_max_bad_logins'])
				qpl_db_log("The account, '" . $q_uname . ",' has been closed due to an excessive number of failed login attempts (i.e., " . $user['q_num_bad_logins'] . ").");

			// check password

			if (mb_strlen($q_pswd) == 0)	// don't allow blank passwords...
			{
				qpl_db_log_password_error($q_uname)
					or qpl_db_log($qpl_error_message);
				qpl_db_log("Entered blank password", LOGIN_OK);	// log pswd error but don't exit
				$comment = $ERTable[385] . "<BR><BR>" . $ERTable[393]; // You must enter your password to log in.<BR><BR>Please try again.
				$q_uname = stripslashes($q_uname);
				include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
				exit;
			}


			if ($info['q_auth_type'] == AUTH_NORMAL || mb_strlen($user['q_pswd']))
			{
				if (mb_strtolower($q_pswd) == mb_strtolower(qpl_addslashes($user['q_pswd'])))
				{
					// reset bad login count to zero
					qpl_db_log_password_error($q_uname, false)
						or qpl_db_log($qpl_error_message);
						
					// check for password change, or force password change if required and it has not been changed
					if (isset($_POST['q_newpswd']) || 
						($info['q_login_pswd_chng_req'] && $q_login_pswd_chng_count == 0) &&
							($q_user_status == USER_NORMAL || $q_user_status == USER_SUPER) )
					{
						$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_PSWD, $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
							or qpl_db_log($qpl_error_message);
						
						qpl_db_updated_old_password_list($q_uname, $user['q_pswd']);
						
						$q_uname = stripslashes($q_uname);
						if (isset($q_name))
							$q_name = $user['q_name'];
						else
							$q_name = "";

						$comment = $ERTable[390]; // Please update your account information and then click on the &quot;Submit&quot; button.<br><br>Or, click on the &quot;Cancel&quot; button to leave the information unchanged.

						if ($info['q_login_pswd_chng_req'] && $q_login_pswd_chng_count == 0 &&
							($q_user_status == USER_NORMAL || $q_user_status == USER_SUPER) )
							$comment .= "<BR><BR><B>" . $ERTable[458] . "</B>";	// "You must enter a new password."

						include (QPL_PSWD_FORM);  // uses: q_new_account, comment, q_uname, q_name, q_javascript
						exit;
					}
				}
				else
				{
					// increment bad login count
					qpl_db_log_password_error($q_uname)
						or qpl_db_log($qpl_error_message);
						
					qpl_db_log("Incorrect password was entered.", LOGIN_OK);	// log pswd error but don't exit
					
					$comment = $ERTable[391] . "<BR><BR>"; // You did not enter a correct password for this account.<BR><BR>
					
					if (qpl_validate_email($info['q_from_address'], false) && qpl_validate_email($q_email, false))
					{       
						if (qpl_db_send_create_account_email($info, $q_uname, $q_name, $user['q_pswd'], $q_email, $q_phone, 2))
							$comment .= $ERTable[392] . "<BR><BR>"; // An email message will be sent shortly with your account information.<BR><BR>
					}
					
					$comment .= $ERTable[393]; // Please try again.
					$q_uname = stripslashes($q_uname);
					include (QPL_LOGIN_FORM);
					exit;
				}
			}
			else	// use ldap to check password
			{
				$result = qpl_auth_ldap($q_uname, $q_pswd, $info['q_auth_type']);

				switch($result)
				{
					case AUTH_STAT_OK:
						// reset bad login count to zero
						qpl_db_log_password_error($q_uname, false)
							or qpl_db_log($qpl_error_message);

						break;
					
					case AUTH_STAT_BAD_PSWD:
						qpl_db_log_password_error($q_uname)
							or qpl_db_log($qpl_error_message);
						qpl_db_log("Incorrect password was entered.", LOGIN_OK);	// log pswd error but don't exit
						$comment = $ERTable[391] . "<BR><BR>" .  $ERTable[393]; // You did not enter a correct password for this account.<BR><BR>Please try again.
						$q_uname = stripslashes($q_uname);
						include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
						exit;
						break;

					case AUTH_STAT_ACCESS_DENIED:
						qpl_db_log("RSA login not allowed.", LOGIN_OK);	// passcode was wrong OR not allowing re-use of good passcode
						$comment = $ERTable[454] . "<BR><BR>" . $ERTable[455]; // Your SecureID login was not allowed.<BR><BR>Wait for the next token number and then try again.
						$q_uname = stripslashes($q_uname);
						include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
						exit;
						break;
						
					default:
						qpl_db_log($qpl_error_message);
						break;
				}
			}

			// check user status
			switch ($user['q_user_status'])
			{
				case USER_NORMAL:
					switch ($info['q_entry_type'])
					{
						case EDIT_SINGLE:
							$q_id = qpl_db_lookup_single_rec($q_uname, $q_atq, $q_atsec, $q_group);
							if ($q_id < 0)
								qpl_db_log($qpl_error_message);
							elseif ($q_id == 0)
							{
								$q_id = qpl_db_add_new_record($q_uname,	$q_group)
									or qpl_db_log($qpl_error_message);
								qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);
							}
							else
								qpl_db_log("Recall existing questionnaire at section $q_atsec", LOGIN_OK, DATA_BEING_EDITED);
								
							$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
								or qpl_db_log($qpl_error_message);
								
							qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in to single case (h:$q_height w:$q_width)");	
							include ($q_questionnaire);	// launch old or new questionnaire record; uses: q_sess_id, q_id (only for display)
							exit;
							break;
						
						case EDIT_MULT:
							qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in to multiple cases (h:$q_height w:$q_width)");	
							include(QPL_SELECT_CODE);
							break;
							
						default:
							qpl_db_log("Unknown value in info.q_entry_type field: " . $info['q_entry_type']);
					}
					break;
					
				case USER_SUPER:
					qpl_db_syslog($info['q_project'], $q_uname, "Super-user logged in (h:$q_height w:$q_width)");	
					include(QPL_SELECT_CODE);
					break;
				
				case USER_MANAGER:	
				case USER_ADMIN:
				case USER_DATA_ADMIN:
				case USER_SYS_ADMIN:
				case USER_MASTER_ADMIN:
				
					$admin_ip_low = 0;
					$admin_ip_high = 0;
					$ipok = false;
					$iprangeset = false;

					if(filter_var(getenv('REMOTE_ADDR'), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) 
					{
						$q_remote_addr_ip = getenv('REMOTE_ADDR');
						$q_remote_addr = ip2long($q_remote_addr_ip);
						
						if ($q_remote_addr == -1 || $q_remote_addr === FALSE)		// first test ip conversion to int4
						{
							qpl_db_log($ERTable[453]);	// Could not identify your address.
						}
						else 
						{
							$q_remote_addr = sprintf("%u", ip2long($q_remote_addr_ip));		// needed to deal with PHP on 32 bit systems
							
							if ($q_remote_addr == ip2long('127.0.0.1'))	// allow localhost always
								$ipok = true;
							else 
							{
								if (isset($user['q_admin_ip_low']) && isset($user['q_admin_ip_high']))	// or allow if within user account range
								{
									if($user['q_admin_ip_low'] > 0 && $user['q_admin_ip_high'] > 0)
									{
										$iprangeset = true;
										$admin_ip_low = $user['q_admin_ip_low'];
										$admin_ip_high = $user['q_admin_ip_high'];
		
										if ($q_remote_addr >= $admin_ip_low && $q_remote_addr <= $admin_ip_high)
										{
											$ipok = true;
										}
									}
								}

								if (defined('ADMIN_IP_LOW') && defined('ADMIN_IP_HIGH') && !$iprangeset)	// or allow if within qpl_config.inc range
								{
									$admin_ip_low = ip2long(ADMIN_IP_LOW);
									$admin_ip_high = ip2long(ADMIN_IP_HIGH);

									if ($admin_ip_low == -1 || $admin_ip_low === FALSE || $admin_ip_high == -1 || $admin_ip_high === FALSE )
									{
										qpl_db_log($ERTable[452]);	// System configuration error.
									}
									else
									{
										$iprangeset = true;
										$admin_ip_low = sprintf("%u", ip2long(ADMIN_IP_LOW));
										$admin_ip_high = sprintf("%u", ip2long(ADMIN_IP_HIGH));
										
										if ($admin_ip_low > $admin_ip_high)							
											qpl_db_log($ERTable[452]);	// System configuration error.

										if ($q_remote_addr >= $admin_ip_low && $q_remote_addr <= $admin_ip_high)
										{
											$ipok = true;
										}
									}
								}
								
								if (!$iprangeset) // or allow if range not defined in user account or  in qpl_config.inc
								{
									$ipok = true;
								}
							}
						}
					}
					else if(filter_var(getenv('REMOTE_ADDR'), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false)
					{
						if(getenv('REMOTE_ADDR') == "::1")	// always allow IPv6 localhost login
							$ipok = true;
							
						// Not currently checking IPv6 ranges. Need to update for this sometime... kbd 2011-10-06
					}
					if (!$ipok)
						qpl_db_log($ERTable[450]);	// Remote access is not allowed.

					qpl_db_log("Administrator: Logging in", LOGIN_OK);
					$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_ADMIN, $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
						or qpl_db_log($qpl_error_message);
					$_POST["q_sess_id"] = $q_sess_id;
					$_POST["q_form"] = FORM_ADMIN_MAIN;
					$_POST["q_language"] = $q_language;
					qpl_db_syslog($info['q_project'], $q_uname, "Administrator ({$user['q_user_status']}) logged in (h:$q_height w:$q_width)");	
					include (QPL_ADMIN);
					exit;
					break;

				case USER_CLOSED:
					qpl_db_syslog($info['q_project'], $q_uname, "Account closed");	
					qpl_db_log($ERTable[451]);	// Your account has been closed.
					break;
					
				default:
					qpl_db_log("Unknown value in info 'q_user_status' field: " . $info['q_user_status']);
			}
		}
		elseif (qpl_db_check_sess(SESS_STAT_NEW_USER, $q_uname) > 0) // someone is trying to register this user name at the moment
		{
			$q_uname = stripslashes($q_uname);
			qpl_db_log("Conflict for user name:  $q_uname", LOGIN_OK); 
			$comment = $ERTable[394]; // Another user is registering this user name.<BR><BR>Please try a different user name.
			$q_uname = "";
			include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
			exit;
		}
		else		// no account found and no one is trying to register it at the moment...
		{
			// check session table to see if someone else is trying to register this user name...
			// otherwise, there could be problems!
			
			if ($info['q_login_type'] == LOGIN_NAME_ADD)	// let user create new account
			{
				if ($info['q_auth_type'] == AUTH_NORMAL)	// use normal method to add a new user
				{
					$comment = "";
					$i = 1;
					if (mb_strlen($q_uname) < $info['q_min_uname_chars'])
						//$comment .= $i++ . ". Your user account name must be at least " . $info['q_min_uname_chars'] . " characters long.<br><br>";
						$comment .= $i++ . ". " . $ERTable[395] . " " . $info['q_min_uname_chars'] . " " . $ERTable[396] . "<BR><BR>";
					if (preg_match("~[^a-z0-9]~", $q_uname))
						//$comment .= $i++ . ". Your user account name may only contain letters and numbers. No other characters may be used.<br><br>";
						$comment .= $i++ . ". " . $ERTable[397] . "<BR><BR>";
					if ($comment)
					{
						$comment .= $ERTable[393]; // Please try again.
						$q_uname = stripslashes($q_uname);
						include (QPL_LOGIN_FORM);	
						exit;
					}

					if (isset($info['q_expire']))
					{
						if (date("Y-m-d") > $info['q_expire'] )
							qpl_db_log($ERTable[398]);	//This project has expired. You may not create a new account.
					}

					$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_USER, $q_uname, $q_javascript, 5/60)
							or qpl_db_log($qpl_error_message);
				
					$q_uname = stripslashes($q_uname);
					if (isset($q_name))
						$q_name = stripslashes($q_name);
					else
						$q_name = "";
					$comment = $ERTable[399]; /* "You have not established an account yet. Please complete the information below and then click 
						on the &quot;Submit&quot; button to create a new account.<br><br>
						Or, if you have entered the wrong user name, please click on the &quot;Cancel&quot; button to back 
						up to the log in page." */
					include (QPL_PSWD_FORM);		

					exit;
				}
				else // add new user with info from ldap
				{
					$result = qpl_auth_ldap($q_uname, $q_pswd, $info['q_auth_type'], true);

					switch($result)
					{
						case AUTH_STAT_OK:
							qpl_db_log("New LDAP user added: " . $q_uname, LOGIN_OK);
							break;
						
						case AUTH_STAT_BAD_USERNAME:
							qpl_db_log("Unknown user name: " . $q_uname, LOGIN_OK);
							$comment = $ERTable[400] . "<BR><BR>" . $ERTable[393]; // You did not enter a valid user name for this system.<BR><BR>Please try again.
							$q_uname = stripslashes($q_uname);
							include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
							exit;
							break;

						case AUTH_STAT_BAD_PSWD:
							qpl_db_log_password_error($q_uname)
								or qpl_db_log($qpl_error_message);
							qpl_db_log("Incorrect password was entered.", LOGIN_OK);	// log pswd error but don't exit
							$comment = $ERTable[391] . "<BR><BR>" . $ERTable[393]; // You did not enter a correct password for this account.<BR><BR>Please try again.
							$q_uname = stripslashes($q_uname);
							include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
							exit;
							break;

						case AUTH_STAT_ACCESS_DENIED:
							qpl_db_log("RSA login not allowed.", LOGIN_OK);	// passcode was wrong OR not allowing re-use of good passcode
							$comment = $ERTable[454] . "<BR><BR>" . $ERTable[455]; // Your SecureID login was not allowed.<BR><BR>Wait for the next token number and then try again. If this problem persists, you should contact the Help Desk and ask to have your SecurID token cleared.
							$q_uname = stripslashes($q_uname);
							include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
							exit;
							break;

						default:
							qpl_db_log($qpl_error_message);
							break;
					}
				}

				// now ok to launch questionnaire with this new user...
				if ($user = qpl_db_get_user($q_uname))
				{
					$q_group = $user['q_group'];	// kbd 5/9/02 update
					$q_user_status = $user['q_user_status'];
					
					// check user status
					switch ($user['q_user_status'])
					{
						case USER_NORMAL:
							switch ($info['q_entry_type'])
							{
								case EDIT_SINGLE:
									$q_id = qpl_db_lookup_single_rec($q_uname, $q_atq, $q_atsec, $q_group);
									if ($q_id < 0)
										qpl_db_log($qpl_error_message);
									elseif ($q_id == 0)
									{
										$q_id = qpl_db_add_new_record($q_uname,	$q_group)
											or qpl_db_log($qpl_error_message);
										qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);
									}
									else
										qpl_db_log("Recall existing questionnaire at section $q_atsec", LOGIN_OK, DATA_BEING_EDITED);
										
									$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
										or qpl_db_log($qpl_error_message);
									
									qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in to single case (h:$q_height w:$q_width)");	
									include ($q_questionnaire);	// launch old or new questionnaire record; uses: q_sess_id, q_id (only for display)
									exit;
									break;

								case EDIT_MULT:
									qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in to multiple cases (h:$q_height w:$q_width)");	
									include(QPL_SELECT_CODE);
									break;
									
								default:
									qpl_db_log("Unknown value in info.q_entry_type field: " . $info['q_entry_type']);
							}
							break;

						case USER_SUPER:
							qpl_db_syslog($info['q_project'], $q_uname, "Super-user logged in (h:$q_height w:$q_width)");	
							include(QPL_SELECT_CODE);
							break;

						case USER_MANAGER:						
						case USER_ADMIN:
						case USER_DATA_ADMIN:
						case USER_SYS_ADMIN:
						case USER_MASTER_ADMIN:
							qpl_db_log("Administrator: Logging in", LOGIN_OK);
							$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_ADMIN, $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
								or qpl_db_log($qpl_error_message);
							$q_form = FORM_ADMIN_MAIN;
							$_POST["q_language"] = $q_language;
							qpl_db_syslog($info['q_project'], $q_uname, "Administrator ({$user['q_user_status']}) logged in (h:$q_height w:$q_width)");	
							include (QPL_ADMIN);
							exit;
							break;

						case USER_CLOSED:
							qpl_db_syslog($info['q_project'], $q_uname, "Account closed");	
							qpl_db_log($ERTable[401] . " " . $q_uname);	// This account has been closed: 
							break;

						default:
							qpl_db_log("Unknown value in info.'q_user_status' field: " . $info['q_user_status']);
					}
				}
				else
					qpl_db_log($qpl_error_message);
			}
			else
			{
				qpl_db_log("Unknown user name:  $q_uname", LOGIN_OK); 
				$comment = $ERTable[400] . "<BR><BR>" . $ERTable[393]; // You did not enter a correct user name for this project.<BR><BR>Please try again.";
				$q_uname = stripslashes($q_uname);
				include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
				exit;
			}
		}
		break;
	
	case FORM_JUMP_GET:

		if( !(isset($_GET['l']) 
			&& isset($_GET['s']) 
			&& isset($_GET['i'])
			&& isset($_GET['o'])) )
			qpl_db_log("Error occurred on jump login.");
			
		//set environment variables
		$q_from_sess_id = $_GET['s'];
		$q_from_q_varname = "";
		if (isset($_GET['v']))
		{
			if (qpl_valid_q_name($_GET['v']))
				$q_from_q_varname = $_GET['v'];
		}
		$q_from_db = qpl_addslashes($_GET['d']);
		$q_from_url = qpl_addslashes($_GET['l']);
		$q_from_other_id = qpl_addslashes($_GET['o']);
		$q_to_q_id = $_GET['i'];
		$q_atq = 0;
		$q_atsec = 0;
			
		//validate the session id against the 'from' survey.
		qpl_db_validate_other_questionnaire_sess($q_from_sess_id, $q_from_db, $q_uname, $q_from_q_id)
			or qpl_db_log($qpl_error_message);
		
		$user = qpl_db_get_user($q_uname)
			or qpl_db_log($ERTable[400]); // You did not enter a valid user name.		

		$q_group = $user['q_group']; 

			
		// keep track of how we got here! If id=zero, then returning from a jump, else is id where to return after visiting here 
		if ($q_from_q_id > 0)
		{
			$sql = "UPDATE user SET q_from_q_id=$q_from_q_id, q_from_url='$q_from_url', q_from_db='$q_from_db', q_from_q_varname='$q_from_q_varname' WHERE q_uname='$q_uname'";
			$result = qpl_db_query($sql)
				or qpl_db_log($qpl_error_message);

			qpl_db_log("Jumped here from: url=$q_from_url, db=$q_from_db, question=$q_from_q_varname id=$q_from_q_id", LOGIN_OK);
		}
		else
		{
			if (mb_strlen($q_from_q_varname))
			{
				$sql = "UPDATE data SET $q_from_q_varname=$q_from_other_id WHERE q_id=$q_to_q_id";
				$result = qpl_db_query($sql)
					or qpl_db_log($qpl_error_message);
			}
			qpl_db_log("Returned here from: url=$q_from_url, db=$q_from_db, id=$q_from_other_id, q=$q_from_q_varname", LOGIN_OK);
		}
		
		if ($q_to_q_id == 0)
		{
			$q_id = qpl_db_add_new_record($q_uname, $q_group, $q_from_q_varname, $q_from_q_id, $q_from_db)
				or qpl_db_log($qpl_error_message);
			qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);
		}
		else
		{
			$q_id = $q_to_q_id;
			qpl_db_get_q_at($q_id, $q_atq, $q_atsec)	// sets current values of $q_atq and $q_atsec
				or qpl_db_log($qpl_error_message);

			qpl_db_log("Recall existing questionnaire at section $q_atsec", LOGIN_OK, DATA_BEING_EDITED);
		}
										
		$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
			or qpl_db_log($qpl_error_message);

		qpl_db_syslog($info['q_project'], $q_uname, "Jumped from another questionnaire to login");	
		include ($q_questionnaire);	// launch old or new questionnaire record; uses: q_sess_id, q_id (only for display)
		exit;
		break;
		
		
		
		
	case FORM_LOGIN_GET:
					
		if (!$info['q_get_allowed'])
			qpl_db_log($ERTable[402]); // You must log in before accessing your questionnaire.  Please start the questionnaire from the URL that was emailed to you.
			
		elseif ($info["q_login_type"] == LOGIN_NAME_NONE)
		{
			if (isset($info['q_expire']))
			{
				if (date("Y-m-d") > $info['q_expire'] )
					qpl_db_log($ERTable[403] . " " . $info['q_expire'] . "."); // This project expired on...
			}

			$q_uname = USER_NONE;
			$q_group = GROUP_NONE;
			$q_id = qpl_db_add_new_record($q_uname,	$q_group)
				or qpl_db_log($qpl_error_message);
			qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);
			$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id)
				or qpl_db_log($qpl_error_message);
			qpl_db_syslog($info['q_project'], $q_uname, "Anonymous user logged in using GET command line options");	
			include ($q_questionnaire);	// launch new questionnaire record; uses: q_job, q_sess_id, q_id (for display only)
			exit;
		}
		else if (isset($_GET['u']))
			$q_uname=mb_strtolower(qpl_addslashes($_GET['u']));
		else 
			qpl_db_log($ERTable[400]); // You did not enter a valid user name.

		if(isset($_GET['p']))
			$q_pswd=mb_strtolower(qpl_addslashes($_GET['p']));
		else
			$q_pswd="";

		if(isset($_GET['l']))
			$q_language=mb_strtolower(qpl_addslashes($_GET['l']));
		else
			$q_language="";
			
		$q_group = GROUP_NONE;
		$q_new_account = 1;
		$comment = "";
		$q_atq = 0;
		$q_atsec = 0;

		// lookup account
		if ($user = qpl_db_get_user($q_uname))
		{
			$q_new_account = 0;
			$q_name = $user['q_name'];
			$q_group = $user['q_group'];
			$q_user_status = $user['q_user_status'];
			$q_email = $user['q_email'];
			$q_phone = $user['q_phone'];
			

			// account has expired?
			if (isset($user['q_expire']) && $q_user_status < USER_MANAGER)
			{
				if (date("Y-m-d") > $user['q_expire'] )
					qpl_db_log($ERTable[404] . " " . $user['q_expire'] . "."); // Your account expired on...
			}

			// account closed due to excessive failed logins?
			if ($user['q_num_bad_logins'] > $info['q_max_bad_logins'])
				qpl_db_log($ERTable[405]); // Your has been closed due to an excessive number of failed login attempts.


			// check password
			if (mb_strlen($q_pswd) > 0 && $q_pswd == mb_strtolower(qpl_addslashes($user['q_pswd'])))
			{
				// reset bad login count to zero
				qpl_db_log_password_error($q_uname, false)
					or qpl_db_log($qpl_error_message);
			}
			else 
			{
				qpl_db_log_password_error($q_uname)
					or qpl_db_log($qpl_error_message);
				qpl_db_log($ERTable[391]); // You did not enter a correct password for this account.
			}

			// check user status
			switch ($user['q_user_status'])
			{
				case USER_NORMAL:
					switch ($info['q_entry_type'])
					{
						case EDIT_SINGLE:
							$q_id = qpl_db_lookup_single_rec($q_uname, $q_atq, $q_atsec, $q_group);
							
							if ($q_id < 0)
								qpl_db_log($qpl_error_message);
							elseif ($q_id == 0)
							{
								$q_id = qpl_db_add_new_record($q_uname,	$q_group, $q_from_q_varname, $q_from_q_id, $q_from_db )
									or qpl_db_log($qpl_error_message);
								qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);
							}
							else
								qpl_db_log("Recall existing questionnaire at section $q_atsec", LOGIN_OK, DATA_BEING_EDITED);
								
							$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
								or qpl_db_log($qpl_error_message);
							
							qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in using GET command line options to single case");		
							include ($q_questionnaire);	// launch old or new questionnaire record; uses: q_sess_id, q_id (only for display)
							exit;
							break;
						
						case EDIT_MULT:
							qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in using GET command line options to multiple cases");	
							include(QPL_SELECT_CODE);
							break;
							
						default:
							qpl_db_log("Unknown value in info.q_entry_type field: " . $info['q_entry_type']);
					}
					break;
					
				case USER_SUPER:
				case USER_MANAGER:
				case USER_ADMIN:
				case USER_DATA_ADMIN:
				case USER_SYS_ADMIN:
				case USER_MASTER_ADMIN:
					qpl_db_log($ERTable[406]); // You must log in before you may access this system. Please launch questionnaire from the project home page.
					break;

				case USER_CLOSED:
					qpl_db_log($ERTable[401]); // This account has been closed.
					break;
					
				default:
					qpl_db_log("Unknown value in info 'q_user_status' field: " . $info['q_user_status']);
			}
		}
		else		// no account found...
		{
			if ($info['q_login_type'] == LOGIN_NAME_ADD)	// let user create new account
			{
				if (isset($info['q_expire']))
				{
					if (date("Y-m-d") > $info['q_expire'] )
						qpl_db_log($ERTable[403] . " " .  $info['q_expire'] . "."); // This project expired on...
				}
				
				$comment = "";
				if (mb_strlen($q_uname) < $info['q_min_uname_chars'])
					// $comment .= $i++ . ". Your user account name must be at least " . $info['q_min_uname_chars'] . " characters long.<br><br>";
					$comment .= $i++ . ". " . $ERTable[395] . " " . $info['q_min_uname_chars'] . " " . $ERTable[396] . "<BR><BR>";
				if (preg_match("~[^a-z0-9]~i", $q_uname))
					// $comment .= $i++ . ". Your user account name may only contain letters and numbers. No other characters may be used.<br><br>";
					$comment .= $i++ . ". " . $ERTable[397] . "<BR><BR>";
				if ($comment)
					qpl_db_log($comment);

				qpl_db_update_account($q_uname, "", ($q_pswd ? $q_pswd : rand(10000,99999)), "", "")
					or qpl_db_log($qpl_error_message);
				qpl_db_log("New GET user added: " . $q_uname, LOGIN_OK);
					

				// now ok to launch questionnaire with this new user...
				if ($user = qpl_db_get_user($q_uname))
				{
					$q_group = $user['q_group'];	// kbd 5/9/02 update
					$q_user_status = $user['q_user_status'];
					
					// check user status
					switch ($user['q_user_status'])
					{
						case USER_NORMAL:
							switch ($info['q_entry_type'])
							{
								case EDIT_SINGLE:
									$q_id = qpl_db_lookup_single_rec($q_uname, $q_atq, $q_atsec, $q_group);
									if ($q_id < 0)
										qpl_db_log($qpl_error_message);
									elseif ($q_id == 0)
									{
										$q_id = qpl_db_add_new_record($q_uname,	$q_group, $q_from_q_varname, $q_from_q_id, $q_from_q_db)
											or qpl_db_log($qpl_error_message);
										qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);
									}
									else
										qpl_db_log("Recall existing questionnaire at section $q_atsec", LOGIN_OK, DATA_BEING_EDITED);
										
									$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
										or qpl_db_log($qpl_error_message);

									qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in to single case after creating an account (h:$q_height w:$q_width)");	
									include ($q_questionnaire);	// launch old or new questionnaire record; uses: q_sess_id, q_id (only for display)
									exit;
									break;

								case EDIT_MULT:
									qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged in to multiple cases after creating an account (h:$q_height w:$q_width)");	
									include(QPL_SELECT_CODE);
									break;
									
								default:
									qpl_db_log("Unknown value in info.q_entry_type field: " . $info['q_entry_type']);
							}
							break;

						case USER_SUPER:
						case USER_MANAGER:
						case USER_ADMIN:
						case USER_DATA_ADMIN:
						case USER_SYS_ADMIN:
						case USER_MASTER_ADMIN:
							qpl_db_log($ERTable[406]); // You must log in before you may access this system. Please launch questionnaire from the project home page.
							break;

						case USER_CLOSED:
							qpl_db_log($ERTable[401]); // This account has been closed.
							break;

						default:
							qpl_db_log("Unknown value in info.'q_user_status' field: " . $info['q_user_status']);
					}
				}
				else
					qpl_db_log($qpl_error_message);
			}
			else
			{
				qpl_db_log($ERTable[400] . " " . $q_uname ); // You did not enter a valid user name for this system. 
			}
		}
		break;
		
		
	case FORM_NEWUSER:
		isset($q_sess_id)
			or qpl_db_log("Session information missing from new user form.");
			
		if (($session = qpl_db_get_sess($q_sess_id)) <= 0)
			qpl_db_log($qpl_error_message);

		$q_javascript = $session['q_javascript'];
		$q_uname = qpl_addslashes($session['q_uname']);
		if ($session['q_stat'] == SESS_STAT_NEW_USER)
			$q_new_account = 1;
		else
			$q_new_account = 0;
		
		if ($_POST['q_submit'] == $ERTable[465]) // FRM_CANCEL
			/* $comment = ($q_new_account ? "A new account was not created." : "Your account information was not changed.") .
				"<br><br>Please enter your user name and password."; */
			$comment = ($q_new_account ? $ERTable[407] : $ERTable[408]) .
				"<BR><BR>" . $ERTable[384];
		else
		{
			$q_name = qpl_addslashes($_POST['q_name']);
			$q_pswd = mb_strtolower(qpl_addslashes($_POST['q_pswd']));
			$q_pswd2 = mb_strtolower(qpl_addslashes($_POST['q_pswd2']));
			$q_email = mb_strtolower(qpl_addslashes($_POST['q_email']));
			$q_phone = mb_strtolower(qpl_addslashes($_POST['q_phone']));

			$comment = "";
			$i = 1;
			$error_count = 0;
		
			// check full name
			if (!mb_strlen($q_name))
				$comment .= $i++ . ". " . $ERTable[409] . "<BR><BR>"; // You must enter your full name.
			
			// check password
			$error_count = $i;
			if (mb_strlen($q_pswd) < $info['q_min_pswd_chars'])
			{
				// $comment .= $i++ . ". Your password must be at least " . $info['q_min_pswd_chars'] . " characters long.<BR><br>";
				$comment .= $i++ . ". " . $ERTable[410] . " " . $info['q_min_pswd_chars'] . " " . $ERTable[411] . "<BR><BR>";
			}
			else if ($q_pswd != $q_pswd2)
			{
				// $comment .= $i++ . ". You must type the same password in both fields.<BR><br>";
				$comment .= $i++ . ". " . $ERTable[412] . "<BR><BR>";
			}
			else if (preg_match("~[^a-z0-9]~", $q_pswd))
			{
				// $comment .= $i++ . ". Your password may only contain letters and numbers. No other punctuation characters may be used.<br><br>";
				$comment .= $i++ . ". " . $ERTable[459] . "<BR><BR>";
			} 
			else if (qpl_db_updated_old_password_list($q_uname, $q_pswd) > 0)
			{
				$comment .= $i++ . ". " . $ERTable[458] . "<BR><BR>";		//"You must enter a new password." 
			}
				
			if ($i > $error_count)
			{
				$q_pswd = "";
				$q_pswd2 = "";
			}
			
			// check email
			if ($info['q_login_email_req'])
			{
				if (mb_strlen($q_email) < 3)
					$comment .= $i++ . ". " . $ERTable[413] . "<BR><BR>";	// // An email address is required.
				elseif (!qpl_validate_email($q_email))
					$comment .= $i++ . ". " . $ERTable[414] . "<BR><BR>";	// You must enter a valid email address.
			}	

			if (mb_strlen($comment) > 0)
			{
				$comment .= $ERTable[393]; // Please try again.
				$q_sess_id = qpl_db_put_sess($session['q_stat'], $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
					or qpl_db_log($qpl_error_message);

				$q_uname = stripslashes($q_uname);
				$q_name = stripslashes($q_name);
				$q_pswd = stripslashes($q_pswd);
				$q_pswd2 = stripslashes($q_pswd2);
				$q_email = stripslashes($q_email);
				$q_phone = stripslashes($q_phone);
				include (QPL_PSWD_FORM);  // uses: q_new_account, comment, has_account, q_uname, q_javascript
				exit;
			}
			qpl_db_update_account($q_uname, $q_name, $q_pswd, $q_email, $q_phone)
				or qpl_db_log($qpl_error_message);
			qpl_db_log($q_new_account > 0 ? "Added new account" : "Updated account", LOGIN_OK);
			//$comment = "Thank you <b>" . htmlspecialchars(stripslashes($q_name)) . "</b>, your account has been " . ($q_new_account > 0 ? "created" : "updated") . ".<BR><BR>";
			$comment = $ERTable[415] . " <B>" . htmlspecialchars(stripslashes($q_name)) . "</B>, " . $ERTable[416] . " " . ($q_new_account > 0 ? $ERTable[417] : $ERTable[418]) . ".<BR><BR>";

			if (qpl_validate_email($info['q_from_address'], false) && mb_strlen($q_email))
			{
				if (qpl_db_send_create_account_email($info, $q_uname, $q_name, $q_pswd, $q_email, $q_phone, $q_new_account))
					$comment .= $ERTable[419] . ".<BR><BR>"; // An email message with your account information will be sent shortly... 
				else
					$comment .= $ERTable[420] . ".<BR><BR>"; // We were unable to send an email message to the address you entered... 
			}
			$comment .= $ERTable[421]; // Please enter your new password to log in to your questionnaire.
		}

		$q_uname = stripslashes($q_uname);
		include (QPL_LOGIN_FORM);	// launch login form; uses: q_job, q_javascript, comment, q_title, q_subtitle
		exit;
		break;
		
	case FORM_SELECT:
		isset($q_sess_id)
			or qpl_db_log("Session information missing from case selection form.");
			
		if (($session = qpl_db_get_sess($q_sess_id)) <= 0)
			qpl_db_log($qpl_error_message);
			
		$q_uname = qpl_addslashes($session['q_uname']);
		$q_javascript = $session['q_javascript'];

		$user = qpl_db_get_user($q_uname)
			or qpl_db_log($qpl_error_message);
		$q_group = $user['q_group'];
		$q_user_status = $user['q_user_status'];
		
		if ($_POST['q_id'] < 0)
		{
			qpl_db_syslog($info['q_project'], $q_uname, "Respondent logged out");	
			include (QPL_RESET_PAGE);
			exit;
		}
		else
		{
			if ( ctype_digit(strval($_POST['q_id'])) )
				$q_id = $_POST['q_id'];
			else
				qpl_db_log("Invalid case selected.");
			$q_atq = 1;
			$q_atsec = 0;
			
			if ($q_id == 0)
			{
				$q_id = qpl_db_add_new_record($q_uname,	$q_group)
					or qpl_db_log($qpl_error_message);
				qpl_db_log("Launch new questionnaire at section 0", LOGIN_OK, DATA_BEING_EDITED);
			}
			else
			{
				$result = qpl_db_validate_select_rec($q_uname, $q_group, $q_id, $q_atq, $q_atsec, $q_user_status);
				if ($result <= 0)	// data base error or case not found
					qpl_db_log($qpl_error_message);
				elseif($result == 2)	// selected is being edited by someone else--shouldn't get here due to check in select form
				{
					$list = qpl_db_lookup_mult_rec($q_uname, $q_group, $info['q_varname'], $q_user_status);
					if ($list < 0)
						qpl_db_log($qpl_error_message);

					qpl_db_log("Selected case is being edited. Select another case.", LOGIN_OK);
					$comment = $ERTable[422] . ".<BR><BR>";	// The case you selected is currently being edited by another user.
					$comment .= $ERTable[423];	// Please select one of the available cases or a new case.

					$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_SELECT, $q_uname, $q_javascript, $info['q_expire_sess_hrs'])
						or qpl_db_log($qpl_error_message);

					include (QPL_SELECT_FORM);  // uses: q_job, comment, q_sess_id
					exit;
				}
				else
					qpl_db_log("Recall existing questionnaire at section $q_atsec", LOGIN_OK, DATA_BEING_EDITED);
			}
			qpl_db_get_q_at($q_id, $q_atq, $q_atsec)
				or qpl_db_log($qpl_error_message);
				
			$q_sess_id = qpl_db_put_sess(SESS_STAT_NEW_QUEST, $q_uname, $q_javascript, $info['q_expire_sess_hrs'], $q_id, $q_atq, $q_atsec)
				or qpl_db_log($qpl_error_message);
			
			qpl_db_syslog($info['q_project'], $q_uname, "Respondent selected case");	
			include ($q_questionnaire);
			exit;
		}
		break;
		
	default:
		qpl_db_log("Unknown form submitted.");
}


?>
