<?php
// qpl_ca_show_tag_def.php
// K. Dooley


include_once 'qpl_config.inc';
$q_language = "";
if (isset($_GET['q_language']))
{
	if (preg_match('/^\.[a-z]{2}(-[A-Za-z]+)?(-[A-Za-z]+)?$/', $_GET['q_language']))
	{
		$q_language = $_GET['q_language'];
	}
	elseif (mb_strlen($_GET['q_language']) > 0)
	{
		$q_comment .= "<BR>A system error has occured.";
		include(QPL_ERROR_FORM);
		exit;
	}
}
include_once QPL_JOB . $q_language;
include_once QPL_DB_FUNCS;
include_once QPL_ADMIN_FUNCS;

// find project information

isset($_GET['t_id']) or
	qpl_db_log("Tag id information is missing.");

qpl_db_connect($q_job)
	or qpl_db_log($qpl_error_message);
	
$sql = "SELECT * FROM ca_tag_def WHERE t_id=" . $_GET['t_id'];
//echo $sql;
if (!($result = qpl_db_query($sql)))
{
	qpl_set_error("qpl_ca_show_tag_def.php", "Unable to query ca_tag_def table.<BR><BR>Query: " . $sql); 
	return 0;
}

$data = qpl_db_fetch_array($result);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- 
qpl_ca_show_tag_def.php
K. Dooley 
-->
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
<TITLE>Topic Tag Definition</TITLE>
<LINK REL="stylesheet" TYPE="text/css" HREF="qpl_style.css">
</HEAD>
<BODY ID="PopUp">
<DIV ID="PopUpBanner">
<P>&nbsp;<IMG SRC="qpl_button_printer.png" ALT="Print" WIDTH="20" HEIGHT="18" BORDER="0" onClick="window.print();">
&nbsp;<IMG SRC="qpl_button_close.png" ALT="Close" WIDTH="18" HEIGHT="18" BORDER="0" onClick="window.close();">
</P>
</DIV>
<DIV ID="PopUpText">
<H3>Tag</H3>
<P><?php echo htmlspecialchars($data['t_tag']); ?></P>
<H3>Definition</H3>
<P><?php echo nl2br(htmlspecialchars($data['t_def'])); ?></P>
</DIV>
</BODY>
</HTML>
