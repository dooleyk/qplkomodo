<?php
// qpl_catch_ajax.php
// K. Dooley
//
// General purpose program to handle XMLHttpRequests.
// At the moment it just handles LIVEUPDATE field updates.
//

$message = "";
$status = 0;

include_once 'qpl_config.inc';
$q_language = "";
if (isset($_POST['q_language']))
{
	if (preg_match('/^\.[a-z]{2}(-[A-Za-z]+)?(-[A-Za-z]+)?$/', $_POST['q_language']))
	{
		$q_language = $_POST['q_language'];
	}
	elseif (mb_strlen($_POST['q_language']) > 0)
	{
		$status = 11;
	}
}
include_once QPL_JOB . $q_language;
include_once QPL_DB_FUNCS;


if ($status > 0)
{
	$status = 11;
	$message = "*** ERROR - <BR>A system error has occured.";
}
elseif (!qpl_db_connect($q_job))
{
	$status = 1;
	$message = "*** ERROR - Could not connect to database.";
}
elseif ( !($info = qpl_db_get_info()) )
{
	$status = 2;
	$message = "*** ERROR - Could not read to database.";
}
elseif ( !(isset($_POST['q_sess_id'])) ) 
{
	$status = 3;
	$message = "*** ERROR - No session information received.";
}
elseif (($session = qpl_db_get_sess($_POST["q_sess_id"], SESS_KEEP)) <= 0)
{
	$status = 4;
	$message = "*** ERROR - Invalid session.";
}
elseif ( !(isset($_POST['q_task'])) )
{
	$status = 5;
	$message = "*** ERROR - No task requested.";
}
elseif ($_POST['q_task'] == 'updateq')
{
	$q_uname = qpl_addslashes($session['q_uname']);
	$q_id = $session['q_id'];

	if (!(isset($_POST['q_var_name']) && isset($_POST['q_var_value']) && qpl_valid_q_name($_POST['q_var_name'])) )
	{
		$status = 6;
		$message = "*** ERROR - Arguments are missing.";
	}
	else
	{
		// check that this field exists
		$sql = "SELECT q_varname FROM struct WHERE q_varname='" . qpl_addslashes($_POST['q_var_name']) . "'";
		if ( !($result = qpl_db_query($sql)) )
		{
			$status = 7;
			$message = "*** ERROR - Could not check question name.";
		}
		elseif ( ($num = qpl_db_num_rows($result)) == 0 )
		{
			$status = 8;		
			$message = "*** ERROR - $num Invalid question name.";
		}
		// finally update the field!
		else
		{
			if ($_POST['q_var_value'] == "NULL")
				$sql = "UPDATE data SET " . $_POST['q_var_name'] . "=NULL WHERE q_id=$q_id";
			else	
				$sql = "UPDATE data SET " . $_POST['q_var_name'] . "='" . qpl_addslashes($_POST['q_var_value']) . "' WHERE q_id=$q_id";
				
			if ( !($result = qpl_db_query($sql)) )
			{
				$status = 9;
				$message = "*** ERROR - $q_uname Update on record ($q_id) failed for question {$_POST['q_var_name']} SQL: $sql";
			}
			else
			{
				$status = 0;
				$message = "Update on record $q_id succeeded for question {$_POST['q_var_name']}.";
			}
		}
	}
}
elseif ($_POST['q_task'] == 'none')
{
	$status = 0;
	$message = "--None-- task requested.";
}	 
else
{
	$status = 10;
	$message = "*** ERROR - Unknown task requested.";
}

// Set up return message...
header('Content-type: text/xml');
echo "<"."?xml version=\"1.0\" encoding=\"UTF-8\"?".">\n<QPL>\n";
echo "<status>$status</status><message>$message</message>\n";
echo "</QPL>\n";
?>
